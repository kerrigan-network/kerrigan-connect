# Original development history

`kerrigan-connect-v0.4.0.bundle` preserves the complete original Git history through commit `ab958392a78f69c2f620a8843cf735c684bba0ad`.

The main branch was populated using the GitHub API after an interrupted browser upload. To restore the original development commits separately:

```sh
git clone archive/kerrigan-connect-v0.4.0.bundle kerrigan-connect-history
```

The runnable project source is in this repository's root. No credentials or live payment keys are included.
