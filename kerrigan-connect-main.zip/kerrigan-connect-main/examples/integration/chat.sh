#!/bin/sh
set -eu
: "${KCONNECT_API_KEY:?Set the gateway API key in the environment}"
: "${KCONNECT_INTENT_KEY:?Set a stable caller intent key; reuse after timeout}"
# This example deliberately targets loopback. Never follow redirects with credentials.
url=${KCONNECT_URL:-http://127.0.0.1:8787}
case "$url" in http://127.0.0.1:*|http://localhost:*) ;; *) echo 'Use a loopback gateway URL' >&2; exit 2;; esac
port=${url##*:}
case "$port" in *[!0-9]*|'') echo 'Invalid loopback port' >&2; exit 2;; esac
case "$KCONNECT_API_KEY" in *[!A-Za-z0-9._:-]*|'') echo 'Use an alphanumeric local API key' >&2; exit 2;; esac
case "$KCONNECT_INTENT_KEY" in *[!A-Za-z0-9._:-]*|'') echo 'Invalid intent key' >&2; exit 2;; esac
# Headers enter curl via stdin, not process arguments. HTTP errors are nonzero.
printf 'header = "Authorization: Bearer %s"\nheader = "Idempotency-Key: %s"\n' "$KCONNECT_API_KEY" "$KCONNECT_INTENT_KEY" |
  curl --config - --silent --show-error --fail --max-time 15 --max-filesize 2000000 \
    --noproxy '*' --proto '=http' --header 'Content-Type: application/json' \
    --data-binary @examples/integration/chat.json "$url/v1/chat/completions"
