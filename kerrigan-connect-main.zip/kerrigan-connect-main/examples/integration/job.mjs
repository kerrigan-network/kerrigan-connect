import { ConnectClient } from '../../src/client.js';
const client = new ConnectClient({ baseUrl: process.env.KCONNECT_URL, apiKey: process.env.KCONNECT_API_KEY });
const key = process.env.KCONNECT_INTENT_KEY;
if (!key) throw new Error('Set KCONNECT_INTENT_KEY once per intended job; reuse it after a timeout.');
const request = { model: process.env.KCONNECT_MODEL || 'demo/catalogue-v1', messages: [{ role: 'user', content: 'Hello' }], max_tokens: 128 };
const job = await client.submit(request, key);
const result = await client.wait(job.id);
console.log(JSON.stringify(result, null, 2));
if (result.status !== 'completed') process.exitCode = 1;
