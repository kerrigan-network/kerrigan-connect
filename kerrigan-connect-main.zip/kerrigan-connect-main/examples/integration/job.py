import json
import os
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "integrations" / "python"))
from kerrigan_connect import ConnectClient

client = ConnectClient(api_key=os.environ["KCONNECT_API_KEY"], base_url=os.environ.get("KCONNECT_URL", "http://127.0.0.1:8787"))
# The caller persists this key; this script never generates a replacement.
key = os.environ["KCONNECT_INTENT_KEY"]
request = {"model": os.environ.get("KCONNECT_MODEL", "demo/catalogue-v1"), "messages": [{"role": "user", "content": "Hello"}], "max_tokens": 128}
job = client.submit(request, key)
result = client.wait(job["id"])
print(json.dumps(result, indent=2))
sys.exit(0 if result["status"] == "completed" else 1)
