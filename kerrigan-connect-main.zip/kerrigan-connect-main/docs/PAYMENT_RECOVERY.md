# Prepared payment recovery (development integration)

Implemented 26 September 2026. This is an internal development backend exercised through the real Connect gateway and a loopback HTTP bridge. The CLI still accepts only demo/read-only modes. This is not a live wallet integration or independently verified payment evidence.

## Durable behaviour

1. The gateway reserves the invoice and fee ceiling and records payment intent.
2. `PreparedPaymentRecovery.pay` asks its injected preparation function for the maintained SDK output shape: `txid`, `tx_hex`, `fee`, `spent_utxos` (transaction ID/output-index pairs). It does not receive keys or implement signing.
3. The ledger stores those exact bytes, input reservations and request/invoice fingerprints in one SQLite transaction. Conflicting prepared transactions, excessive fees, malformed output and reuse of inputs by another job are rejected. Input reservations are conservative and are not automatically released.
4. A second atomic transaction records that broadcast is about to start. Only one database connection can acquire this attempt. Once set, neither retries nor restart can automatically broadcast again or prepare a replacement payment.
5. Immediately before preparation and again before broadcast, the backend obtains the current block and refuses an invoice at or beyond `expires_block`. Failure to obtain a valid tip is fail-closed. This is conservative client policy; the supplied Drone snapshot generates expiry metadata but its payment validator does not consume it.
6. The development bridge sends raw hex as `text/plain` to `/sendrawtransaction`, matching the maintained wallet's HTTP contract. It accepts only numeric HTTP loopback addresses, disallows redirects, bounds the response and checks the returned transaction ID against the saved value.
7. A transaction reader must return the exact saved raw bytes before payment can be recorded. On a lost response, explicit `reconcile(jobId)` uses lookup only. A missing, different or unavailable result preserves the reservation and unresolved state. After successful reconciliation, the gateway can resume inference using its existing job, invoice and transaction reference.

## Maintained SDK preparation adapter

`kerrigan-connect/integration` exports `MaintainedSdkPaymentPreparer` for the public Kerrigan webwallet wrapper pinned in `KERRIGAN_SDK_REVISION`. It maps Connect's `top_p` to the wrapper's `topP` without rounding, passes the saved invoice fields and exact sampling values to `buildInferencePaymentTx`, and feeds its output into the existing prepared-transaction journal.

The embedding wallet supplies `withSigningSession(callback)`. That boundary owns UTXO acquisition, seed custody and derivation selection; Connect does not derive a mnemonic, serialize a seed or retain signing material. The adapter initializes the injected SDK once, permits exactly one callback per preparation, validates bounded UTXOs and checks that every reported spent input came from that session. It also independently recomputes the transaction ID from the raw bytes and rejects inconsistent SDK output before anything is saved or broadcast. Wallet/SDK failures are sanitised.

This is an adapter contract, not executed WASM evidence. Tests use an instrumented SDK double and synthetic bytes so they can prove argument mapping, custody boundaries and recovery wiring without handling a real key. A maintained SDK build/import and real owner-controlled wallet session remain required before live use.

The ledger uses its existing WAL and FULL synchronous settings. New tables are additive to schema version 1. Transaction bytes remain in the private database and do not appear in public job views. They are retained for reconciliation; existing content purging does not delete them. No key material is stored by this backend.

A crash after the broadcast marker but before network I/O intentionally leaves an unresolved reservation. A negative lookup alone is insufficient to prove a transaction can never appear later. There is no automatic replacement payment, timeout-based release or administrative "mark paid" HTTP endpoint. An eventual authorised recovery policy may rebroadcast identical verified bytes, but this implementation does not do so.

## Source and trust boundaries

Pinned upstream revision: `ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29`, confirmed current on 26 September 2026.

- [SDK wrapper](https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/webwallet/src/sdk.js) supplies the preparation output shape. Actual cryptography must come from that maintained SDK.
- [Wallet network client](https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/webwallet/src/network.js) defines bridge broadcasting and `getRawTransaction(txid)` via ElectrumX `blockchain.transaction.get`. The new backend takes that reader as an injected function; it does not invent an HTTP lookup endpoint.
- [Wallet build instructions](https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/webwallet/README.md) require Rust and `wasm-pack`, using `wasm-pack build sdk --target web --out-dir ../pkg`. Neither command is installed in this execution environment. The inspected source tree contains no generated `pkg` artifacts. This is a local build prerequisite, not missing upstream functionality.

Byte equality establishes consistency with the configured reader only. It does not validate transaction signatures, the model/payment commitment, confirmations, finality, invoice expiry, provider acceptance, a refund or execution. The prepare and reader functions in tests are fixtures. The fixture hex is deliberately not a real signed transaction. Do not label supplied transaction IDs or these reader fixtures as independently verified live evidence.

Before enabling any live route, finish SDK build/loading and synthetic cryptographic execution tests, authoritative transaction identity/semantics checks, invoice/block expiry policy, maintained Drone validation/replay/refund inspection and a real transaction reader with defined trust/finality policy. Live spending and key access still require separate authority. Keep E1 open and advance independent E2–E4 work when a build prerequisite blocks it.

### Supplied Swarm snapshot

The owner-supplied `kerrigan-swarm-main.zip` was inspected locally. Its archive comment identifies commit `d0ff0fb425b5f234eb57b4678cc1596230b8d62c`; the ZIP SHA-256 is `d3fe7a5beb7f1b5459cd55e8aa1652c4d34af496555d80c19a2577d7560bfc7d`. Files are dated 16 June 2026. It is useful concrete evidence but is not asserted to be current private upstream.

That snapshot defines GET `/v1/block/current`, GET `/v1/tx/:txid` (verbose decoded transaction) and GET `/v1/inference/:txid` (indexed payment lifecycle). Connect now exposes strict readers for those shapes. The transaction reader requires the requested `txid`, bounded raw `hex` and non-negative confirmations; the lifecycle reader binds the payment reference, provider, model hash and token ceiling to the saved invoice and distinguishes a coordinator index observation from independent verification. Malformed references are rejected before HTTP. These methods can directly provide `getCurrentBlock` and `getRawTransaction` to `PreparedPaymentRecovery`; a real local-HTTP compatibility test exercises that route.

The snapshot's Drone validator checks transaction existence/confirmations, payment output, 0x02 provider/model/token/parameter binding and minimum output-token value. It caches the first successful response by payment reference in memory and SQLite; a retry while the original is still running may return `PaymentReplayed`, while a completed retry returns the cached response. Refunds are output-only, occur only when the unused output ratio exceeds the configured 10% margin and the amount is above dust, and are asynchronously emitted as 0x06 transactions. Coordinator lifecycle `change_txid` is therefore an indexed refund reference, not proof that Connect received value. Connect does not yet independently validate those transaction semantics or automatically credit a refund.

## Reproduction and evidence

Run `node --test test/sdk-payment.test.js test/payment-recovery.test.js test/ledger.test.js test/coordinator-evidence.test.js` for focused SDK, recovery, evidence and accounting checks, or `npm test` for the whole suite. All 128 tests passed on Node 24.19.0/Linux. Coverage includes:

- Gateway task completion with one actual loopback HTTP broadcast and repeated intent reuse.
- Lost acknowledgement, SQLite close/reopen and lookup-only recovery through inference completion.
- A separate child process exiting immediately after committing broadcast intent, followed by recovery in the parent.
- Two SQLite connections competing to broadcast, with only one HTTP request.
- Missing/different/unavailable lookup, changed prepared data, excessive fee and input conflicts.
- Expired invoice, unavailable/invalid tip and expiry reached while preparation is running.
- Exact maintained-wrapper argument mapping, one-shot owner-controlled signing sessions, spent-input binding and raw-byte/transaction-ID consistency.
- GET-only current-tip, exact transaction and invoice-bound lifecycle parsing, including malformed and mismatched responses.
- Unexpected acknowledgement, oversized response, redirect and non-loopback endpoint refusal.

No actual wallet/Drone, browser application, network payment, GPU execution or adoption was validated by these tests.

GitHub Actions run [36231803083](https://github.com/BoltBlew/kerrigan-connect/actions/runs/36231803083) on the prior implementation commit `dd0ff923` failed before execution (runner ID 0, no steps). Allocation cause remains unknown. No rerun or workflow change was made; this does not count as CI validation.
