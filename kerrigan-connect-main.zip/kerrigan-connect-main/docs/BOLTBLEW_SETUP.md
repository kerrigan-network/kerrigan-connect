# Temporary BoltBlew repository

Intended destination: **BoltBlew/kerrigan-connect**, private. This is an
independent integration prototype, not an official Kerrigan release.

As of this checkpoint the repository has **not** been created and no code
has been pushed. The connected GitHub account is BoltBlew, but the available
connector cannot create repositories. The browser sign-in was not completed.
No existing BoltBlew repository was changed.

## Publish with GitHub CLI

After extracting the release, restore the included Git history so publishing
preserves earlier milestones:

```
git clone kerrigan-connect.bundle kerrigan-connect-git
cd kerrigan-connect-git
git remote remove origin
```

The removed remote here is only the local bundle file used for the clone.
Install the official GitHub CLI (https://cli.github.com/), authenticate as
BoltBlew using `gh auth login`, then run:

```
bash scripts/publish-boltblew.sh
```

The script confirms the account, requires a clean checkout without any remote,
runs all tests, and creates a new **private** repository with the current
branch/history. It stops if the name already exists. It never force-pushes or
overwrites another repository. The default branch selected by GitHub CLI may
follow the account's configuration; inspect it after creation.

If repository creation succeeds but the upload fails, inspect the remote and
GitHub state before retrying. The script intentionally stops on subsequent
runs when an origin already exists; it does not delete partial remote state.
The script's shell syntax has been checked; authenticated publishing has not
been executed in this environment.

GitHub CLI reference: https://cli.github.com/manual/gh_repo_create

## Connect for continued agent work

If the repository is created manually on GitHub, select just this repository
in the existing GitHub integration's repository access. Then provide its URL
in the conversation. The current local history can be transferred without
copying daemon code or overwriting the Kerrigan organisation's repositories.
