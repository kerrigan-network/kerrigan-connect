# First-use guide

The first-use page is the local front door for Connect. It checks the running gateway before offering any workflow and keeps three states separate:

- **supplied demo** — the bundled deterministic model is available for a simulated, no-spend sample;
- **observed GET** — model availability came from the configured Coordinator in read-only mode, scoped to that response;
- **unknown/unavailable** — discovery or the local worker could not confirm readiness.

None of these states enables a wallet or proves GPU execution. Connect still has only demo and read-only modes.

## Run the guided sample

Use Node 24.14–24.x. From an installed or source package:

    export KCONNECT_API_KEY="$(node -e 'process.stdout.write(require("node:crypto").randomBytes(32).toString("hex"))')"
    npm start

Open `http://127.0.0.1:8787/start` on the same computer and enter the key. A ready demo shows:

- local gateway: available, demo mode;
- models: available from `supplied_demo`;
- processing: `available_simulated`;
- live spending: disabled.

Choose **Open Catalogue Studio**, enter the same key again, select the six-product sample, prepare the batch, save its checkpoint, process it, review the source and export only approved rows. Re-entering the key is intentional: neither page stores it in local/session storage, cookies or downloaded files.

In read-only mode the page can display current model discovery, but its processing status remains unavailable and Studio processing stays disabled.

## Recovery and safety

The status check is authenticated and GET-only. It never submits a job or invokes the payment adapter. A failed discovery remains `unknown`; it is not converted to zero models. Upstream error details are not returned to the browser.

The page is loopback-only, served with a restrictive content-security policy and uses only local assets. Its model list contains bounded public catalogue fields, not provider identifiers. The normal local SQLite retention and one-operator token boundaries still apply.

## Verification

- `npm run test:first-use`: five focused asset, authentication, demo/read-only, failure-redaction and source-safety checks.
- `npm run test:install`: packs and installs the project into a clean temporary application, then checks the installed page and authenticated status route before completing the existing task/restart/review/export workflow.
- `npm test`: all repository tests, including real loopback HTTP contracts.
- `scripts/verify-first-use-browser.mjs`: native Chromium navigation, credential clearing, responsive screenshots and actual handoff into Studio.

The native-browser verifier is committed to the opt-in browser workflow, but did not run in the current environment because its matching Chromium executable is absent and the managed cloud browser blocks loopback. HTTP, source and install checks are not presented as browser evidence.
