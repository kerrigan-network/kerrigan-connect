# GPU provider preflight

This local diagnostic helps a prospective operator collect a deliberately small GPU inventory and compare it with per-model VRAM values advertised by a saved Kerrigan model-catalogue snapshot. It installs nothing, escalates no privileges, opens no ports, configures no wallet and registers no provider.

## Run it

From a supplied, redacted inventory:

```sh
npm run gpu-preflight -- \
  --input examples/gpu-inventory.json \
  --models examples/gpu-model-snapshot.json \
  --output output/gpu-preflight.json
```

Or opt in to the one local command this release supports:

```sh
npm run gpu-preflight -- --local --output output/gpu-preflight-local.json
```

Local mode runs exactly:

```sh
nvidia-smi --query-gpu=index,name,memory.total,driver_version --format=csv,noheader,nounits
```

It uses no shell, has a five-second timeout and a 1 MB output limit. If `nvidia-smi` is absent, the result is **unknown**, not proof that the host has no GPU; an AMD, Intel or otherwise undiscovered device may exist. Use `--input` for those inventories. Supplying both modes or overwriting an input is rejected.

The command writes JSON plus a Markdown support report. Exit 0 means the diagnostic was generated. Exit 2 means a known local blocker, such as an explicitly empty supplied inventory or all models with known memory requirements exceeding every observed GPU. It never returns “ready”: operational requirements remain unknown until a maintained upstream provider guide is available.

## Evidence boundary

Sources reviewed on 25 September 2026:

- The pinned [public SDK model catalogue adapter](https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/webwallet/src/network.js) maps `vram_required_mb` from `/v1/models`. This project preserves that value as advertised metadata and compares it only with total GPU memory.
- The current [Kerrigan site](https://kerrigan.network/) describes future provider earnings and includes mining hardware guidance. Mining algorithm requirements are not encoded as inference-host requirements.
- The pinned [public core whitepaper](https://github.com/kerrigan-network/kerrigan/blob/7c4d3e5fa11525827f8152d168c6ca7a127e16bf/docs/whitepaper.md) discusses V2 provider registration, staking, hardware attestation and service endpoints conceptually. It is not treated as an operational install contract.

No maintained public inference-provider installation guide was accessible through the reviewed primary sources. That is a scoped observation, not a claim that private or forthcoming upstream instructions do not exist. Consequently, driver versions, CUDA/ROCm/runtime versions, container images, ports, health checks, registration, staking, wallet and payout requirements are all emitted as **unknown**. Obtain current upstream instructions before acting on them.

An advertised memory comparison is not proof that a model will load, that context/KV-cache allocations fit, that a runtime is compatible, that the provider will register, or that it will earn rewards. This diagnostic performs no inference and cannot establish confidentiality, compute correctness or availability.

## Inventory schema and redaction

The supplied inventory is strict: unknown fields fail rather than leaking into the report. It accepts only:

- OS family and architecture;
- `nvidia-smi` state (`present`, `absent`, `error`, or `not_checked`);
- GPU ordinal, vendor, product name, total memory in MB and optional driver version.

Do not add hostname, IP address, GPU UUID/serial, PCI bus ID, usernames, filesystem paths, environment variables or wallet data. Those fields are rejected and never appear in the support export. Local command stderr is also discarded.

The included inventory and model snapshot are explicitly synthetic. Replace them with operator-approved evidence; a saved `npm run probe -- --output ...` snapshot may be used when its models expose advertised `x_kerrigan.vram_required_mb` values.

## Tests

```sh
npm run test:gpu-preflight
npm test
```

Tests cover sourced memory fit, missing requirements, known absent GPUs, insufficient memory, absent tooling, malformed `nvidia-smi` output, secret-bearing fields, fixed no-shell execution and actual CLI JSON/Markdown output.
