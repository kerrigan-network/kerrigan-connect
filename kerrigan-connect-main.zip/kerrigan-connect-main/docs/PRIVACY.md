# Privacy and operating limits

This prototype does not claim cryptographically private inference.

## Data paths

- Demo mode performs deterministic processing in the local process; no prompts leave the machine through its provider.
- Read-only mode requests public model and chain metadata. No inference prompts are submitted.
- The future Coordinator adapter's quote/chat methods send messages over HTTPS to a Coordinator. HTTPS protects transit; it does not hide plaintext from the Coordinator or receiving GPU operator. These methods are not reachable through the read-only submission routes.
- The observed public SDK builds transparent inference payments. Sapling support elsewhere in Kerrigan must not be presented as proof that this flow is shielded.

## Local storage

The ledger retains input, output, invoice metadata, transaction IDs and job events to support restart recovery. It is not encrypted by this application. The CLI uses restrictive file creation permissions; local administrators and anyone with access to the files may still read them.

`purge --days N` logically removes old terminal inputs and outputs. It retains accounting and idempotency tombstones and leaves unresolved jobs untouched. SQLite pages, WAL files, operating-system snapshots and backups may still retain deleted content. No secure-erasure claim is made.

## Access

The gateway is for one operator and binds only to loopback. Every API request except health needs the operator Bearer token. This is not a multi-tenant identity system. The operator token can read all jobs and request supported actions.

No seed phrase or private key is accepted by the HTTP API. The future signing backend must remain local and separate from the gateway's client-facing surface. Local budgets must be backed by a wallet with limited funds and independent signing policies.

## Provider output

JSON and literal-attribute checks can identify malformed or unsupported output, but do not prove model correctness. Classification errors and misleading source descriptions still require human evaluation. CSV formula prefixes are neutralised on export. The catalogue workflow has no tool-execution capability.

The code has automated tests, not an independent security audit. Real funds, sensitive documents, public hosting and multiple users remain outside this milestone's supported scope.
