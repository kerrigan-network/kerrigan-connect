# B3 first-use increment — 26 September 2026

Built a loopback-only first-use guide at `/start`. Its authenticated GET status distinguishes the bundled simulated model from a current, scoped read-only Coordinator observation and preserves failed discovery as unknown. It never enables paid processing. A ready demo hands the operator into the existing Catalogue Studio sample, review and approved-only export workflow; credentials remain tab-memory-only and must be entered again in Studio.

Five focused first-use tests, the fresh-tarball install workflow and all **157 local tests** passed on Node 24.19.0/Linux. The installed package serves the guide and reports a ready supplied demo without creating a job or simulated payment. The optional Chromium verifier covers credential clearing, desktop/mobile screenshots and real navigation into Studio.

B3 remains `implemented_pending_browser`: the native Chromium verifier did not run because the matching executable is absent and the managed browser blocks loopback. GitHub CI, live inference, wallet/payment use, public deployment and publication are not claimed. Evidence: `docs/evidence/first-use-build-2026-09-26.json`. Implementation: `c28db6452ba537e551497194ad6859f54592ee4a`.

---

# End-to-end resumption — 26 September 2026

Reviewed current private `main` at `3f37d047` and the E1–E5 roadmap. The code is beyond the A1–A7 handoff: it already contains maintained-SDK adapter boundaries, durable payment recovery and review checkpoint race protection. The maintained public SDK head remains `ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29`. No maintained SDK/WASM execution or live inference is established by this review.

Removed a practical first-use blocker: support-triage and document-extraction endpoint inputs can omit known expected answers. Fixture runs still require valid labels for all cases; supplied malformed labels fail before requests. Labels remain local and do not change replay identity. New synthetic unlabelled support input and installed-package instructions walk through processing, review and approved-only export. Export provenance now preserves the simulation flag.

Fixed the fresh-install check's file-URL path handling and Windows command-shim launch assumptions. The installed CLI now has actual no-spend HTTP coverage through task execution, database restart, same-job replay with zero additional simulated payments, changed-intent rejection, pending-export refusal, explicit test approval/rejection and export. The original install test failed in a source path containing spaces/Unicode; the fix passed there. Windows itself remains untested.

Evidence: **140 baseline tests, 142 updated tests, 10 focused task-pack tests, one expanded fresh-install test, nine quickstart checks**, all passing locally on Node 24.19.0/Linux (Python 3.12.14, curl 8.5.0). Details and source hashes: `docs/evidence/installed-workflow-2026-09-26.json`. The install test was also run after restoring the hash-verified historical archive into the package source.

E1–E5 remain incomplete. In this workspace the native browser check cannot launch because the Playwright 1.62.1 Chromium binary is absent; no browser assertions ran. n8n was not installed/imported. Latest pre-change GitHub Actions run `36258123410` failed with zero steps and runner ID 0; the cause remains unknown. SDK/WASM execution, current Drone confirmation, real CI and browser/application evidence remain required. The bounded funded pilot remains separately authorised work. No live KRGN, wallet custody, public release, permission change, upstream merge or outreach occurred.

Implementation committed and remote hashes verified at `8a3d06d8`. Its Actions run `36263045546` / job `108462379397` failed before all steps, with runner ID/group 0 and an empty runner name. No repository test command executed in CI. Existing source and historical archive were preserved; the E3/E4 claim is cleared.

---

# Milestone 0.11 / historical component programme status — 26 September 2026

UPDATE 26 September 2026: owner reopened delivery under END_TO_END_ROADMAP.md. A1–A7 below are component milestones, not end-to-end product completion. E1 initial work adds actual loopback coordinator invoice/chat contract tests and rejects malformed transaction references before HTTP submission. All 103 local tests pass. The public wallet already contains invoice, inference, streaming, broadcast and lookup operations; maintained signing and reconciliation integration still need inspection and implementation. No live invoice, inference or spending was executed. Hourly E1–E5 work is enabled.

A7 is delivered: an explicit local opt-in event log now distinguishes first-run pass, first useful workflow, return workflow and supplied verified-live evidence. Simulation, local-only and live activity cannot be silently conflated. Exact duplicates are idempotent, changed reuse conflicts, privacy-bearing extra fields fail closed, and identifier-free JSON/Markdown/HTML aggregates make no user, conversion-lift or market-adoption claim. See `PILOT_MEASUREMENT.md`.

The final `PROGRAMME_HANDOFF.md` inventories A1–A7 with exact releases and delivery commits, compatibility limits, reproducible commands, maintainer order and the live/provider/release decisions still required. Local verification: **100 tests passed**, including nine A7 tests and actual CLI file/report execution; the same 100 tests passed from a clean source export. **Nine quickstart checks passed** on Node 24.19.0/Linux with Python 3.12.14 and curl 8.5.0 available. The committed A7 aggregate contains four explicitly synthetic records, two local journeys and zero live events. Receipt: `fixtures/adoption-v0.11.0/receipt.json`.

GitHub Actions run **36205562302** at A7 delivery commit `190077d` failed before any steps with runner ID 0. No unchanged blind rerun or weakened checks. Actual browser, third-party application, live inference and measured adoption validation are not claimed. No prompts, customer content, device fingerprints, invoices, wallet actions, public release or KRGN spending occurred.

All seven locally actionable adoption deliverables are complete, the delivery tree was verified on remote `main`, and the finite build automation was disabled. Live inference/payment, provider activation, a consenting funded pilot, public licensing/hosting and upstream integration remain separate dependencies recorded in the handoff.

---

# Milestone 0.10 status — 25 September 2026

A6 is delivered: bounded GET-only Coordinator snapshots now record source, observation time, freshness, endpoint states, advertised capabilities and redacted provider references. Stable diffs report genuine model/provider/capability changes only when observations are safely comparable; failures, stale evidence, empty advertised lists and zero connected providers remain separate. Each command writes JSON, Markdown and self-contained HTML. See `CAPABILITY_TRACKER.md`.

Local verification: **91 tests passed**, including eight focused tracker tests and actual offline CLI JSON/Markdown/HTML generation; **nine quickstart checks passed** on Node 24.19.0/Linux. A historical saved probe produced an expected stale report and exit 2 while preserving its successful endpoint observations. Clean-source installation and the complete test suite also passed. Receipt: `fixtures/capability-tracker-v0.10.0.json`.

GitHub Actions run **36202747134** at A6 delivery commit `af6f6a2` failed before any steps with runner ID 0. No unchanged blind rerun or weakened checks. A live tracker CLI capture was not executed in this build environment, and no uptime, whole-network capacity, actual browser or third-party validation is claimed. No prompts, invoices, wallet actions, inference or KRGN spending occurred. A1–A6 are complete. **A7 local opt-in pilot/adoption evidence and final reproducible handoff** is next; live/release dependencies remain separate.

This milestone also corrects A5's pinned SDK source URL to the current public repository/path (`kerrigan-network/kerrigan-sdk/webwallet/src/network.js`); the earlier link was broken.

---

# Milestone 0.9 status — 25 September 2026

A5 is delivered: a strict supplied-inventory parser and opt-in bounded local `nvidia-smi` query now produce redacted JSON and Markdown support diagnostics. Saved catalogue `vram_required_mb` values are preserved and compared as advertised metadata only. Missing tools are unknown, known absent GPUs and insufficient advertised memory are blockers, and unsupported identity/secret fields fail closed. Driver, runtime, service, registration, staking and wallet requirements remain unknown pending a maintained upstream inference-provider guide. See `GPU_PREFLIGHT.md`.

Local verification: **83 tests passed**, including eight focused A5 tests, a Coordinator metadata-boundary test and actual CLI JSON/Markdown generation; **nine quickstart checks passed** on Node 24.19.0/Linux. The opt-in local command ran in this build environment and correctly reported missing `nvidia-smi` as unknown rather than no GPU. Receipt: `fixtures/gpu-preflight-v0.9.0.json`.

GitHub Actions run **36192750211** at the A5 delivery commit failed before any steps; its job exposed no logs or step records. No unchanged blind rerun was requested and this is not a CI pass. Actual browser and third-party validation are not claimed. No software was installed, no provider was registered, no wallet was loaded, no inference ran and no KRGN was spent. A1–A5 are complete. **A6 GET-only capability and availability snapshots/diffs** is next; live/release dependencies remain separate.

---

# Milestone 0.8 status — 25 September 2026

A4 is delivered: reusable support-triage and document-extraction packs now have strict schemas, synthetic labelled datasets, injection-aware prompts, deterministic fixture runs and an explicit Connect endpoint runner. Stable caller intent IDs make batches resumable; exact replay does not create another simulated payment and changed source conflicts. Literal evidence validation, pending-by-default review, tamper-evident decisions and approved-only JSONL export keep model output behind a human gate. See `TASK_PACKS.md`.

Local verification: **74 tests passed**, including eight A4 tests and real authenticated loopback HTTP execution of both packs; **nine quickstart checks passed** on Node 24.19.0/Linux. Both three-case fixture datasets run from the CLI with all outputs accepted as labelled fixtures. Receipt: `fixtures/task-packs-v0.8.0/receipt.json`.

GitHub Actions run **36186165435** failed before any steps with runner ID 0. No blind rerun or weakened checks. Actual browser and third-party application validation are not claimed. No live inference, invoice, customer contact, ticket modification, external document acquisition or measured adoption occurred. A1–A4 are complete. **A5 GPU provider preflight** is next; live/release dependencies remain separate.

---

# Milestone 0.7 status — 25 September 2026

A3 is delivered: the offline model/workload/context planner accepts saved probe output and explicit token estimates, checks required advertised capabilities, and writes JSON plus Markdown cost scenarios using exact integer arithmetic. Missing rates, absent capability evidence, stale snapshots, fees and final invoices remain unknown. The discovery adapter no longer silently converts a missing input rate to zero. See `WORKLOAD_PLANNER.md`.

Local verification: **66 tests passed**, including nine planner tests with real CLI execution; **nine quickstart checks passed** on Node 24.19.0/Linux. The historical probe example produced both reports and expected exit 2 for stale evidence. Reproducible receipt: `fixtures/planner-v0.7.0.json`.

GitHub Actions run **36179888104** failed before any steps with runner ID 0. No blind rerun or weakened checks. Actual browser and third-party app validation are not claimed; no inference, KRGN spend or fresh network-availability observation was made. A1–A3 are complete. **A4 support-triage and document-extraction task packs** are next; live/release dependencies remain separate.

---

# Milestone 0.6 status — 25 September 2026

A2 is delivered: a standard-library Python client, bounded JavaScript client, runnable Python/JS/curl examples and an explicit compatibility matrix. Both clients require caller-owned intent keys and never automatically replace or retry them. Real loopback HTTP tests cover success, replay, conflict, authentication, deadlines, oversized/malformed responses, redirects and recovery after a delayed POST response without duplicate simulated payment.

Local verification: **57 tests passed**, **nine quickstart checks passed**, and all **three integration tests passed from a clean tracked-source export** after `npm ci`. Environment: Node 24.19.0, Python 3.12.14, curl 8.5.0, Linux x86_64. See `APP_INTEGRATION.md` and `fixtures/integration-v0.6.0.json`.

GitHub Actions run **36177088432** at the A2 claim commit again failed with `runner_id: 0` and no steps. Its cause remains unknown; no manual rerun was requested and no checks were weakened. This is not a CI pass. Actual browser and third-party app validation remain outstanding. No real GPU inference, KRGN spending, public deployment or adoption measurement occurred.

A1 and A2 are complete; **A3 model/workload/context/cost planner** is next. The finite hourly programme remains in progress, with live inference and release dependencies separate.

---

# Milestone 0.5 status — 25 September 2026

## Current delivery

The private GitHub repository `BoltBlew/kerrigan-connect` now contains the complete v0.4 source and original history bundle under `archive/`. The imported source was verified by all 63 Git blob hashes and file modes at commit `60a353eda4f76f81fbead3c9965344ad19ab3a24`.

v0.5 adds the one-command first-run toolkit, nine real local HTTP checks, an ephemeral key/database, restart/replay verification, a sanitised receipt and onboarding documentation. `npm test` passes **54 tests**; `npm run quickstart` passes all nine checks on Node v24.19.0/Linux. The receipt is `fixtures/quickstart-v0.5.0.json`. This remains simulated local execution.

The finite ranked adoption programme and hourly continuation rules are in `ADOPTION_ROADMAP.md`, `ADOPTION_STATE.json` and `AUTONOMOUS_RUNBOOK.md`.

GitHub Actions run 36172196596 for the original import failed before any steps and no job logs were available. Its cause is unconfirmed; do not equate local test success with GitHub CI success. Actual browser verification remains outstanding.

## Historical milestone notes (superseded by current delivery above)

# Milestone 0.4 status — 25 September 2026

## Added in 0.4

- Review checkpoint comparison with JSON and Markdown reports.
- Approval transition counts and warnings for edits retaining an old approval timestamp.
- Five additional automated tests, including CLI output and report escaping.
- Manual GitHub Actions browser verification workflow with pinned Playwright.
- Private BoltBlew publishing script and full-history restoration instructions.

At the original v0.4 packaging point, the BoltBlew account was confirmed, but no repository had been created: the current
connector cannot create repositories and browser sign-in was not completed.
The cloud browser also refused local-file navigation under its URL policy;
no workaround was attempted. Real-browser verification and GitHub workflow
execution remain unverified. The local automated suite passes.

## Added in 0.3

- Single-file offline catalogue review workspace with search and status filters.
- Editable categories and evidence-checked attributes, with explicit decisions.
- Approval reset on edits and CSV export of approved products only.
- Downloadable checkpoints and exact-batch restoration.
- CLI page generation and revalidated exports from saved decisions.
- Browser verification script; no external runtime dependencies added.
- Included six-product simulation ready to open without a server or account.

GitHub connection setup remains paused at the user's request. Work continues
on the local feature branch; no repository push or public deployment occurred.

## Added in 0.2

- Labelled 16-case synthetic catalogue regression set and evaluator.
- JSON, CSV and self-contained HTML reports with mismatch details and costs.
- Optional category accuracy gate with CI-friendly exit codes.
- GET-only readiness assessment with model selection and snapshot freshness.
- Tests for failed-job denominators, label isolation, escaping and readiness blockers.
- Version-aware release packaging.

Demo benchmark: schema 16/16; category 13/16; exact match 12/16. These
measure the local deterministic rules only. No new live inference claim.

## Delivered

- Standalone Node.js application with no external runtime dependencies.
- Local authenticated compatible chat gateway and buffered SSE responses.
- Persistent SQLite job ledger, atomic budget reservations and idempotency.
- Simulated payments/refunds with separate gross spend, fees and net cost.
- Restart recovery that does not automatically repay an ambiguous job.
- CSV catalogue processing, resume keys, output validation and formula-safe export.
- Small JavaScript client and an importable n8n demo workflow.
- Live read-only model, Drone and chain probe.
- Maintainer-facing upstream contract, wallet boundary, privacy notes, CI and merge plan.
- Local feature-branch history and a self-contained Git bundle in the handoff package.

## Verification completed

Tested with Node.js **v24.19.0** on Linux.

`npm test`: **52 passed, 0 failed**.

The tests exercise:

- Concurrent duplicate submissions and changed-request conflicts.
- Atomic reservation across separate SQLite connections and UTC midnight.
- Fees included in budgets; refunds do not refill the daily allowance.
- Unknown payment outcomes, failed inference, same-transaction retries and restart states.
- Duplicate/conflicting refund receipts and over-refund rejection.
- In-flight quote cancellation and old-content removal with accounting retained.
- Local HTTP authentication, configuration-secret exclusion, validation and SSE framing.
- Real HTTP catalogue processing, schema/evidence checks and idempotent replay.
- Actual CLI/server processes, a server restart, and no increase in simulated spending on catalogue or benchmark replay.
- n8n example request construction and response parsing against the HTTP gateway.
- Coordinator request contracts, response bounds and sanitised errors.
- Fail-closed network modes and one-worker ownership.

`npm run demo`: six sample products processed; all six passed structural/evidence checks. One remains `Uncategorised`, as its source description contains insufficient detail. Results are a deterministic simulation, not an AI accuracy result.

`node src/cli.js probe`: live GET calls succeeded. At the recorded observation, the configured Coordinator reported one connected Drone and one Llama 3.2 3B quantised model; the chain reported inactive Drone block payouts. Full timestamp and response subset: `fixtures/live-probe-2026-09-25.json`.

The v0.2 doctor also completed live GET discovery successfully at
2026-09-25 14:44:21 UTC. It continued to report live inference and spending
as disabled. See `fixtures/readiness-live-v0.2.json`; freshness expires after
five minutes. The snapshot example correctly reports the older observation
as stale.

The standalone page's actual JavaScript was also exercised in a minimal DOM
test harness: approval reset, evidence rejection, checkpoint and CSV bytes,
restore, cross-batch rejection and filtering. This is not a real browser test.
Chromium verification could not complete: no browser binary was installed and
the attempted browser download returned an invalid archive. Visual layout,
browser file downloads and browser CSP enforcement remain unverified here.
The reusable Playwright verification script is included for the next environment.

## Not yet verified or enabled

- No live KRGN was spent; no wallet secrets were created or loaded.
- No paid mainnet inference, real refund, compute proof or confidential-compute claim was validated.
- The n8n export was not imported into a running n8n installation.
- Open WebUI was not installed or exercised; compatibility was tested at the HTTP protocol boundary.
- At v0.4 packaging, CI had not run. Current CI status is recorded above.
- Native upstream streaming, real signing/reconciliation and a refund watcher remain integration work.
- No public deployment or upstream merge has taken place. The complete private repository import is recorded above.

## Next milestone

With repository access, confirm the maintained Swarm API and wallet interface, integrate signing without exposing keys to the HTTP API, and run a bounded end-to-end paid pilot. Preserve the demo suite as an offline regression harness. Review exact protocol guarantees before enabling retries, verification badges or confidentiality language for real users.
# B4 operator-console increment — 26 September 2026

Built a loopback-only, authenticated operator console for bounded local/supplied diagnostics. It reports gateway health, model observations, failed or reconciliation-required jobs and local-ledger utilisation without exposing prompts, outputs, upstream errors, shell execution, service mutation, wallets or provider registration. It explicitly prevents GPU mining from being treated as inference-service readiness.

Maintained-source review found a consequential compatibility condition: public Core `7c4d3e5` defines the v1.3.0 `CDroneRegTx` special transaction and states that maintained SDK `ae6ca83` plus the Coordinator scanner still use the replaced OP_RETURN registration. The console reports this as `known_mismatch`. The current maintained Drone runtime/installer source was not available through the authorised repository connection, so runtime version/install compatibility remains unknown.

Five focused tests, the fresh-package install workflow and all **162 local tests** passed on Node 24.19.0/Linux. Native Chromium did not run and no live inference, payment, wallet, registration, service change, publication or deployment occurred. Evidence: `docs/evidence/operator-console-build-2026-09-26.json`; implementation: `0f02b8c561d34a4945d54704e0f47ec4bfe272ca`.

---

