# Kerrigan adoption programme handoff

Status update, 26 September 2026: this is the historical A1–A7 component handoff. The owner reopened E1–E5 end-to-end delivery in END_TO_END_ROADMAP.md. Overall product readiness remains incomplete and hourly work has resumed.

## Outcome

The finite A1–A7 build programme is complete in the private `BoltBlew/kerrigan-connect` staging repository. It provides an independent local adoption layer around Kerrigan discovery and future inference: first-run proof, app clients, preflight planning, reviewed task packs, provider diagnostics, capability diffs and privacy-preserving pilot evidence.

This is a reproducible software handoff, not evidence of market adoption or production Kerrigan usage. No funded inference, payment-key custody, provider registration, public deployment, external outreach or upstream merge occurred in this programme.

## Delivered components

| Item | Release | Delivery commit | Maintainer entry point |
| --- | --- | --- | --- |
| A1 first-run developer toolkit | 0.5.0 | `78f7cfd1e751d469b400d9516529a196704a75b3` | `docs/QUICKSTART.md` |
| A2 app integration kit | 0.6.0 | `167499b2766e91dc327ecb09b885ecd9c5e657c2` | `docs/APP_INTEGRATION.md` |
| A3 workload/context/cost planner | 0.7.0 | `136cd58d04e2f5ab89b125599497da16704d8ed7` | `docs/WORKLOAD_PLANNER.md` |
| A4 reviewed business task packs | 0.8.0 | `8de0d59d9d632dc1e2ee8f69838c49f323756fb3` | `docs/TASK_PACKS.md` |
| A5 GPU provider preflight | 0.9.0 | `5634f54e7e9f814dba4d0f9c53a3f6d8a92ede93` | `docs/GPU_PREFLIGHT.md` |
| A6 capability/availability tracker | 0.10.0 | `af6f6a2859c1b5f034fa655c1b6bf5cbd971bbaa` | `docs/CAPABILITY_TRACKER.md` |
| A7 local pilot evidence kit | 0.11.0 | `190077d7ef9c093f39d1ab5a412333a592f0727f` | `docs/PILOT_MEASUREMENT.md` |

## Reproduce locally

Requirements:

- Node.js 24.14 or later in the 24.x line; final validation used Node 24.19.0 on Linux.
- Python 3.10+ and curl 8.5+ for the A2 cross-language HTTP checks; final validation used Python 3.12.14 and curl 8.5.0.
- No npm packages, GPU, wallet, API subscription or KRGN are required for the local suite.

```sh
npm ci --ignore-scripts
npm test
npm run quickstart
```

The package is private and unlicensed. Pin the runtime during a pilot: `node:sqlite` is experimental in some Node 24 releases. The gateway binds to loopback, uses a single operator token, stores unencrypted local SQLite content and supports only the documented OpenAI-compatible subset. Buffered SSE is not token streaming.

## Maintainer verification order

1. Confirm the checked-out commit against `docs/ADOPTION_STATE.json` and review every external dependency below.
2. Run the clean local suite and quickstart. Treat GitHub Actions as unresolved until a workflow actually receives a runner and executes steps.
3. Run `npm run doctor` and the capability snapshot against the intended Coordinator. A single Coordinator remains a scoped observation, not whole-network capacity or uptime.
4. Validate Python, JavaScript and curl clients in the intended third-party application. Existing loopback compatibility tests are not that validation.
5. Obtain maintained upstream contracts for signing, invoices, reconciliation, verification, refunds and inference-provider operation before implementing any live backend.
6. Define wallet/key custody, KRGN budget, pilot participants, opt-in evidence retention and incident response. Use a funded live request only with explicit owner authority.
7. Decide licence, upstream repository/merge route, hosting model and publication wording before releasing outside the private staging repository.

## Decisions that remain outside this build

| Dependency | Current state | Required decision/evidence |
| --- | --- | --- |
| Live inference and payment | Blocked | Maintained upstream protocol contracts, explicit key custody, budget and funded pilot authority |
| Provider activation | Blocked | Maintained inference-provider runtime/registration guide and an operator-approved host |
| Public release | Owner decision | Licence, branding/affiliation wording, security review, upstream merge route and hosting |
| Real adoption evidence | Not measured | Consenting pilot participants and locally supplied non-sensitive receipts through A7 |
| Third-party apps | Not validated | Execute the intended Open WebUI/n8n/other product workflow in its real environment |
| GitHub CI | Unverified | A runner must start and execute the unchanged workflow; current failures have zero steps |

Do not turn demo receipts, fixture accuracy, advertised prices, model/provider lists or local HTTP checks into claims of GPU execution, confidentiality, invoices, payments, earnings, users or conversion lift.

## Repository truth

`docs/ADOPTION_STATE.json` is the machine-readable final state. Milestone receipts under `fixtures/` preserve the local test boundaries, while `docs/STATUS.md` contains the chronological record. The original v0.4 history is retained under `archive/`; current work belongs on current `main`.

The finite build automation was disabled after the A7 delivery was verified. Further work requires a new explicit scope or one of the recorded owner/upstream decisions.
