# Kerrigan application build phase

Authorised by Peter on 26 September 2026. Build the four application pieces first; joining them to the operating network, publication and distribution will be discussed afterwards. This supersedes the older run order where E1 could block independent product work. A1–A7 and E1–E5 remain historical component and end-to-end records.

## Network context

Peter confirms Kerrigan's AI inference network is technically operational and has not yet been marketed. Treat that as owner-supplied context. Connect's uncompleted live route and our missing live evidence do not imply Kerrigan is non-operational. Reuse maintained SDK/Drone contracts and record which observations are independently verified.

## Build order and acceptance

| Item | Piece | Reviewable build gate |
| --- | --- | --- |
| B1 | Catalogue Studio | A local merchant interface imports and validates CSV; selects taxonomy/model; processes a batch with visible progress; preserves intent across restart/retry; shows simulated/known/unknown costs honestly; leads into source-based human review, approval/rejection, checkpoints and approved-only CSV export. Installed package and actual browser flow must be exercised where possible; missing native-browser evidence remains explicit. |
| B2 | Installable n8n integration | A package with credential setup, model discovery, submit/status/result/recovery operations, caller-owned stable intent keys, bounded failures and example workflows. Validate package installation and actual n8n import/execution, not only a mocked node or JSON export. No package publication in this phase. |
| B3 | First-use experience | A runnable local guided sample with explicit demo/live/unavailable status, actual/supplied service/model availability and a useful handoff into Studio. Prepare later public-site integration, but do not alter Kerrigan's public site or enable sponsored trials. |
| B4 | Operator console | A local console for bounded supplied/read-only health, versions, model availability, failed-job diagnosis and observed utilisation. Check version/install compatibility against maintained Drone sources; label absent evidence unknown. No inference-readiness claim based only on GPU/mining preflight. No browser-triggered shell or service mutation. |

Each item needs concrete source, focused failure/recovery tests, useful operating instructions and an evidence record. Existing working modules should be reused. Do not create parallel wallets, cryptography, billing, planners or trackers merely to fill a roadmap.

## Integration boundary

Internal component interfaces and local contract testing are part of this build. External live activation, funding, publication, marketing, recruitment and distribution remain for the subsequent discussion. Do not mark E1–E5 complete when B1–B4 are built. A polished UI and a passing simulated request do not verify GPU execution, payments, output quality or adoption.

No real KRGN spending, payment-key custody, paid services, new accounts, provider registration, public/non-loopback deployment, permission changes, upstream merges or outreach is authorised. GET-only discovery and authorised source inspection may continue; synthetic POST tests remain on loopback.

## Scheduled delivery

Use the existing automation `6ab7eb2062d08191bc0e0f1e1c0240d3`, enabled hourly from 21:00 Europe/London on 26 September. Its duplicate remains paused. Start from current main and `PRODUCT_BUILD_STATE.json`; coordinate via expiring claims in `ADOPTION_STATE.json`. Reconcile new commits, preserve other work, use non-force updates and verify remote file hashes. The source of truth for actual schedule state is the automation service.

Deliver bounded useful increments. If one item is externally blocked, advance another. Notify for meaningful milestones, consequential defects or a precise owner action; keep unchanged runs quiet. Once all pieces reach their documented build gates, commit a handoff and pause for Peter's integration/distribution discussion. If only external acceptance remains, pause with an explicitly incomplete handoff, not a completion claim.
