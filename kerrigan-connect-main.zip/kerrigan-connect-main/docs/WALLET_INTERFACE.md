# Payment backend boundary

The current runtime only accepts `demo` or `read-only`. There is no mainnet wallet backend and no environment flag that enables spending. Changing that must be a reviewed code change with real integration tests.

`DemoPayments` exercises the internal interface:

```js
await payments.pay({
  jobId,       // stable payment intent / backend idempotency key
  invoice,     // persisted before calling the backend
  request,     // exact canonical sampling parameters and token limit
  maxFeeSats,  // hard fee ceiling, included in the reservation
});
// => { txid, amount_sats, fee_sats, simulated: true }
```

The gateway records `payment_pending` before this call. If the call fails or a process dies before storing the receipt, the job remains unresolved and its reservation is retained. The public API cannot resolve this by trusting a caller-supplied transaction ID.

## Required live implementation

The backend should wrap the maintained Kerrigan Rust/WASM SDK rather than create new signing cryptography. Prefer an isolated local process with a dedicated limited-balance wallet; no spending secrets belong in HTTP requests, n8n exports or the gateway repository.

Before signing, it must:

- Verify invoice authenticity and expiry against current chain state.
- Validate address checksums and bind provider identity, model hash, token ceiling, amount and recipient to the user's request.
- Compute `params_hash` with the SDK from exactly the temperature, top-p, seed and `k` sent to inference; avoid independent float serialisation.
- Check available UTXOs, change destination, dust policy, total spend and the hard network-fee ceiling.
- Persist the signed raw transaction and its deterministically computed ID keyed by `jobId` **before** network broadcast.
- On retry, return or rebroadcast the same signed transaction; never create a different payment under the same intent.

A companion `lookup(jobId)`/reconciliation contract is still to be implemented. It must distinguish definitely-not-submitted, signed-but-unbroadcast, broadcast, confirmed, rejected and unknown states with durable evidence. Only a verified outcome may release an ambiguous reservation.

## Refunds

The demo implements `refund({jobId, invoice, result, paymentTxid})` to exercise accounting. A future live adapter must not equate a provider promise with a confirmed refund. It must inspect on-chain outputs, the original payment reference, amount, destination and confirmation/finality policy.

Refund transaction IDs are unique. Replaying an identical receipt has no effect; changing its job or amount is a conflict. Total recorded refunds cannot exceed the original provider payment. Network fees are tracked separately.

In v0.1 a refund-backend failure retains successful output with `refund_pending_review`. A background chain watcher and operator reconciliation interface are future work.

## Activation test

Before enabling live mode, complete a bounded test using explicit pilot funds:

1. Discover an actual supported model/provider and obtain a bound invoice.
2. Persist/sign/broadcast one payment through the maintained SDK.
3. Obtain and validate output with the original transaction ID.
4. Repeat the request and prove no second payment occurs.
5. Interrupt the process at signing, broadcasting and inference boundaries and reconcile each state.
6. Observe a genuine unused-token refund and verify its destination and amount.
7. Confirm operator/prompt visibility and report verification status accurately.

No such paid test has been performed in this milestone.
