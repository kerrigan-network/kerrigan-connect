# E3 release-quality audit

Reviewed 26 September 2026 against current private `main`.

## Runtime/install boundary

The supported runtime is Node 24.14+ in the 24.x line. `package.json` already declared that engine range, but npm does not normally make `engines` a hard runtime gate. A developer could therefore start the CLI on an unsupported Node release and reach SQLite/network code before getting a useful compatibility error.

Connect now calls `assertSupportedRuntime()` at CLI startup. Node 23.x, Node <24.14, Node 25+ and malformed version strings fail with `unsupported_runtime` before configuration, database or network work begins. The guard is deliberately small and does not install or select Node for the user.

Regression coverage lives in `test/runtime.test.js`. An isolated copy of the exact runtime guard and test was executed in the build tool environment on Node 22.16.0: **2 tests passed** using supplied version strings. This is useful logic verification, not a substitute for the repository's required Node 24.19.0 `npm test` run.

## Concurrency/recovery boundaries reviewed

- Persistent gateway operation uses an exclusive `gateway.lock`; an existing or unreadable lock fails closed and stale-lock removal remains an explicit operator action rather than an automatic check/unlink race.
- SQLite uses WAL, `synchronous=FULL`, `BEGIN IMMEDIATE` atomic sections, unique idempotency/payment constraints and prepared-input reservations. Existing tests cover concurrent duplicate submission and budget reservation across separate database connections.
- Prepared payment state is persisted before broadcast, broadcast start is durable, and an ambiguous broadcast cannot automatically create a replacement payment.
- CLI generated-file writes use same-directory temporary files plus rename. Separate CLI processes are not coordinated for arbitrary output paths, so operators should not target the same output file from simultaneous commands. The persistent gateway data directory is the stronger protected boundary.

This audit does not claim multi-host/database-filesystem safety outside the documented local single-operator model.

## GitHub CI allocation evidence

Two observed GitHub Actions jobs failed before executing any workflow step:

- run `36234796124`, job `108384500102`
- run `36237819345`, job `108392711541`
- run `36254932107`, job `108439796210` (fresh-install/onboarding change)

For all listed jobs the Actions API reports an empty step list. Job-log retrieval returns no stored log blob. Earlier job metadata also recorded runner ID/group 0 and a blank runner name. That is evidence of a pre-step allocation/execution failure, not a failing repository command, but the exact GitHub platform cause is still unknown.

No unchanged blind rerun, weakened workflow, larger timeout or unverified self-hosted runner has been used. E3 cannot close until a real GitHub-hosted CI job executes the workflow checks.

## Still required for E3

1. Keep the complete suite and fresh-package workflow passing on the pinned runtime. This local requirement was executed in the resumption below; Windows execution is still unverified.
2. Obtain real GitHub CI execution and retain step/job evidence.
3. Continue fresh-install and recovery validation on the supported platform(s), including the E2 reviewed workflow.
4. Fix any defects found without weakening the gates.

## Supported-runtime resumption, 26 September 2026

Current `main` at `3f37d047` was reconstructed through authorised GitHub access. All 134 text-file blob hashes matched, and the historical binary bundle was separately restored with its matching Git blob hash. The exact text source passed **140 tests on Node 24.19.0/Linux** before changes, including the formerly unexecuted package install boundary.

The resumed implementation removes the known-answer requirement for real task inputs: endpoint cases may omit `expected`, while fixtures still require valid labels for every case. Exports retain the simulation flag. Both packs are covered by actual loopback requests, label-independent replay and validation before submission. The full updated suite passed **142 tests**, and the focused task-pack suite passed **10 tests**.

`test/install.test.js` now tests the installed package through unlabelled support input, a real local HTTP endpoint, persistent restart/replay, changed-intent rejection, pending-export refusal, test approval/rejection and approved-only export. It uses `fileURLToPath`, the current Node executable plus npm's JS entry point, and `npm exec --offline` to handle generated command shims. An original-test run from a checkout with spaces and an accented character failed because URL-encoded pathname text reached npm. The corrected test passed from the same checkout. This proves the path correction on Linux; it does not prove Windows support.

Node's documented boundaries: [fileURLToPath](https://nodejs.org/api/url.html#urlfileurltopathurl-options) converts file URLs to native paths, and [.cmd launching](https://nodejs.org/api/child_process.html#spawning-bat-and-cmd-files-on-windows) requires platform shell handling. The test delegates the latter to npm and keeps runtime dependencies unchanged.

The native verifier was attempted with Playwright 1.62.1. After directing temporary artifacts to the writable workspace, launch reported that the matching Chromium headless executable is absent. No native browser assertions ran, no policy was changed, and no browser pass is claimed. GitHub run `36258123410` still had zero steps and runner ID 0 before this change; a successful local suite does not close CI. Current structured evidence is in `docs/evidence/installed-workflow-2026-09-26.json`.
