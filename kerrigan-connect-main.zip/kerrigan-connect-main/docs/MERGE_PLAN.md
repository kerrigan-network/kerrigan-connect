# Bringing the project into Kerrigan GitHub

Current branch: `feat/kerrigan-connect`. There is no configured remote, and nothing has been pushed or published. The distribution includes complete source and a Git bundle so history can be moved once the destination and access are confirmed.

## Recommended location

Use a separate `kerrigan-connect` application repository, or an agreed companion directory in the Swarm repository. Keep this JavaScript service out of daemon consensus code. The maintainer's build system, licence and contribution guidelines take precedence when access is available.

## Recover the history

From the extracted distribution directory:

```bash
git clone kerrigan-connect.bundle kerrigan-connect-git
cd kerrigan-connect-git
git switch feat/kerrigan-connect
npm test
```

The bundle is self-contained. The source directory alongside it is also directly runnable, but Git history lives in the bundle.

## When creating a dedicated repository

After the exact destination is approved and accessible, add that remote and push this feature branch, then create a draft pull request using `docs/PR_DRAFT.md`. Do not blindly push into the existing daemon repository or overwrite its root files.

## When importing into an existing repository

Create an integration branch from the destination's current default branch. Import the source under the agreed prefix, preserve this project's attribution and tests, and adapt its CI invocation to that prefix. A local Git subtree import can preserve an audit trail:

```bash
# Run in a clean destination checkout; replace both paths with agreed values.
git subtree add --prefix=contrib/kerrigan-connect \
  /absolute/path/to/kerrigan-connect-git feat/kerrigan-connect --squash
```

The `contrib/kerrigan-connect` prefix is an example, not a decision made for the maintainers. An existing repository's root workflow will not automatically run a workflow nested under that prefix; add an explicit job calling `npm test` there.

## Work after access arrives

1. Read the destination's `AGENTS.md`, contribution rules and Swarm documentation.
2. Replace provisional invoice/model contracts with the maintained schema and test fixtures.
3. Integrate the real local wallet backend and reconciliation lookup.
4. Run the bounded paid test defined in `WALLET_INTERFACE.md`.
5. Add actual verification/refund support and native streaming where the protocol supports them.
6. Review licence, security, retention and operational ownership before a wider pilot.

Provider registration compatibility is a separate upstream change. This prototype does not register Drones and does not silently modify the existing SDK or daemon.
