# Observed Kerrigan contract

Observation date: 25 September 2026. This document distinguishes public source observations, live GET responses and assumptions that still require maintainer confirmation.

## Source provenance

| Source | Observation |
| --- | --- |
| [Wallet networking](https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/webwallet/src/network.js) | Coordinator URLs, model discovery, invoice and chat request shapes |
| [Wallet AI view](https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/webwallet/src/views/ai.js) | Model-aware Drone pinning, sampling defaults, paid request flow and streaming metadata |
| [Wallet signing bridge](https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/webwallet/src/sdk.js) | Inference signing arguments and exact sampling-parameter binding |
| [Inference payment builder](https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/sdk/src/inference/payment_tx.rs) | Transparent P2PKH payment plus OP_RETURN metadata |
| [Refund builder](https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/sdk/src/inference/change_tx.rs) | Provider-issued refund linked to the original payment |
| [Daemon registration format](https://github.com/kerrigan-network/kerrigan/blob/7c4d3e5fa11525827f8152d168c6ca7a127e16bf/src/evo/inference_wire.h) | New special-transaction Drone registration and golden vectors; older SDK OP_RETURN registration needs follow-up |
| [Official Swarm overview](https://kerrigan.network/guides/what-is-kerrigan.html) | Drone/Coordinator roles and intended output-sampling verification |

No upstream code or private repositories were copied into this project. The links record the source used to design a separate application adapter. The official guide's `kerrigan-swarm` repository link returned 404 through the available GitHub reader; its runtime implementation was not reviewed.

## Live read-only observation

The exact sanitised report is in `fixtures/live-probe-2026-09-25.json`.

- Coordinator: `https://coordinator.jskitty.com` (configured in the public wallet).
- One connected Drone reported by `/v1/node-id`.
- One model advertised: `Llama-3.2-3B-Instruct_IQ4_XS`, 16384-token context.
- Explorer reported Core v1.3.2 and `drone_payout_active: false`.

This is a snapshot from one Coordinator and must not be hardcoded as current network capacity. Run `npm run probe` for a fresh observation. No paid inference was run.

## Discovery and request mapping

| Upstream endpoint | Observed shape | Connect treatment |
| --- | --- | --- |
| GET `/v1/models` | `{models:[{id, context_length, drones, rate_sat_per_token, in_rate_sat_per_token, ...}]}` | Normalise model catalogue; accept documented `providers` alias too |
| GET `/v1/node-id` | `connected_drones` and relay metadata | Expose only connected count in probe |
| POST `/v1/invoice` | Request: `model`, `messages`, `max_tokens`, `drone_pubkey_hash` | Pin a provider advertised for the selected model |
| Invoice response | `amount_sat`, `pay_to_address`, `drone_pubkey_hash`, `model_hash`, `max_tokens`, `expires_block` | Validate integer amount, provider match, token-limit match and required payment fields |
| POST `/v1/chat` | `drone_pubkey_hash`, `payment_txid`, messages/model/token limit and sampling parameters | Reuse the stored payment transaction on retry |

The invoice and chat methods have fixture-based contract tests but are **not enabled for paid live use**. Current read-only mode only calls GET endpoints. The gateway advertises the features it supports; it does not infer all underlying model capabilities from their names.

## Must resolve with upstream before funding a pilot

1. Versioned API contract, authentication and supported model/provider discovery rules.
2. Invoice expiry and payment acceptance rules, including zero-confirmation/InstantSend behaviour.
3. Canonical model hash, provider key binding, invoice authenticity and exact sampling hash vectors.
4. SDK signing interface, transaction broadcasting and idempotent wallet lookup by job intent.
5. Refund amount calculation, deadlines, on-chain proof and dispute handling.
6. Retry guarantees across Drone/Coordinator restarts; provider affinity and result retention.
7. Actual compute-verification client flow and its effect on latency/cost.
8. Prompt visibility, retention, transport and any attested confidential-compute capabilities.

These are integration dependencies, not claims that the upstream has no implementation.
