# Install and first reviewed workflow

This is the installation target for the private staging programme. Linux with Node 24.19.0 has passed the fresh-package workflow described below. Windows instructions and portability fixes are provided, but Windows execution is still unverified. This does not publish Connect, enable a wallet or spend KRGN.

## Supported runtime

Use Node.js 24.14 or later in the 24.x line. The CLI rejects older Node releases and Node 25+ before opening the database or making network requests.

## Source checkout

From an authorised checkout of this private repository:

```sh
npm ci --ignore-scripts --no-audit --no-fund
npm test
npm run quickstart
```

`npm run quickstart` creates a disposable loopback gateway, exercises authentication, a simulated completion, idempotent replay, changed-intent rejection, buffered SSE and restart recovery, then removes its temporary key and database. Its receipt must say `passed: true`, `mode: "demo"`, `simulated: true` and `real_krgn_spent: 0`.

## Install the package artifact

Connect now declares the `kerrigan-connect` CLI in `package.json`. A private tarball produced from an authorised checkout can therefore be installed into a clean project without publishing it:

```sh
npm pack --json
mkdir /tmp/kconnect-app && cd /tmp/kconnect-app
npm init -y
npm install --ignore-scripts --no-audit --no-fund /path/to/kerrigan-connect-0.11.0.tgz
./node_modules/.bin/kerrigan-connect quickstart
```

PowerShell equivalent (start in the authorised source checkout):

```powershell
$connectPackage = npm pack --ignore-scripts --json | ConvertFrom-Json
$connectTarball = (Resolve-Path $connectPackage[0].filename).Path
$connectApp = Join-Path $env:TEMP ('kconnect-app-' + [guid]::NewGuid())
New-Item -ItemType Directory -Path $connectApp | Out-Null
Set-Location $connectApp
npm init -y
npm install --offline --ignore-scripts --no-audit --no-fund $connectTarball
npm exec --offline -- kerrigan-connect quickstart
```

`npm run test:install` packs the current source, installs the artifact offline in a fresh project with spaces and Unicode in its path, and invokes the generated CLI through `npm exec --offline`. It checks quickstart, then runs an unlabelled support batch against the installed local demo gateway. It restarts that gateway on the same SQLite database, verifies the same jobs replay without additional simulated payments, refuses changed intent, checks pending-export refusal, records test approval/rejection and exports only the approved result with simulation provenance. All subprocesses have finite timeouts; no registry package is fetched and nothing is published. Run this test through npm, which supplies the npm JavaScript entry point needed for portable subprocess invocation.

The check exercises installed application code and real loopback HTTP. Its approval is an automated test decision, not a human assessment of model quality or an E2 browser/third-party application acceptance.

## Try a new support input

An endpoint input needs only `id` and `source` for each case. The optional `expected` field is for labelled evaluations. Use the synthetic starter input installed with the package:

```sh
# Terminal 1, from the installed app directory. Use a local, generated token.
export KCONNECT_API_KEY="$(node -e 'process.stdout.write(require("node:crypto").randomBytes(24).toString("hex"))')"
export KCONNECT_MODE=demo
npm exec --offline -- kerrigan-connect serve
```

In a second terminal, set `KCONNECT_API_KEY` to the same local token and run from that app directory:

```sh
npm exec --offline -- kerrigan-connect task-run --input node_modules/kerrigan-connect/examples/task-packs/support-input.json --output support.result.json --run-id first-support-001 --url http://127.0.0.1:8787 --model demo/catalogue-v1
npm exec --offline -- kerrigan-connect task-review --input support.result.json --output support.review.json
```

Read `support.review.json` and compare each output with its source. Only after review, record the appropriate decision; replace the reviewer placeholder with your name:

```sh
npm exec --offline -- kerrigan-connect task-decide --input support.review.json --output support.reviewed.json --case-id support-new-001 --decision approved --reviewer "Your Name" --notes "Evidence and suggested action checked."
npm exec --offline -- kerrigan-connect task-export --input support.reviewed.json --output support.approved.jsonl
```

Use `--decision rejected` for a result you do not approve. Unreviewed and rejected results are excluded. For further decisions, use the preceding decision file as input and a new output file. Repeat the same `task-run` command/run ID after a restart to recover existing jobs; changing the source under the same ID must produce `idempotency_conflict`. The demo outputs and payment entries remain simulated. See [TASK_PACKS.md](TASK_PACKS.md) for document extraction and label rules.

## Complete a useful reviewed task

For the current supported local workflow, keep inference explicitly simulated:

1. Start the source checkout with a generated `KCONNECT_API_KEY` and `npm start`.
2. Run the catalogue command from the source checkout against `examples/catalogue.csv`, or import `integrations/n8n/catalogue-demo.json` into a local n8n instance as documented there.
3. Open the generated `.review.html` file in a browser. Inspect the original description and proposed fields. Correct unsupported values, then explicitly approve or reject each row.
4. Download a checkpoint before closing the page. Export approved rows only. Reopening/restoring the checkpoint must retain decisions for the exact source batch; a changed batch must be rejected.
5. Repeat the same intent with the same run/idempotency key when recovering from an uncertain response. Do not generate a replacement key merely because the caller lost an acknowledgement.

The included review page and n8n export are application surfaces, but E2 is not complete until the selected application is actually installed/imported and exercised through its real interface with recorded application/browser versions. The fresh-package test likewise does not substitute for browser validation or GitHub CI.

## Diagnose

- `unsupported_runtime`: install a supported Node 24.x release; do not bypass the guard.
- `ledger_locked`: another gateway may own the data directory. Stop it first. If a process crashed, confirm no worker remains before manually removing `gateway.lock`; Connect intentionally does not auto-delete stale locks.
- `idempotency_conflict`: the key already belongs to different request content. Recover the original intent or deliberately start a new business intent.
- `needs_reconciliation`: payment/execution outcome is ambiguous. Do not create a replacement payment. Live reconciliation remains an E1/E5 prerequisite.
- n8n cannot reach `127.0.0.1:8787`: an isolated container or n8n Cloud does not share the host loopback. Do not expose Connect through an ad-hoc public tunnel.
- review export is disabled: at least one row must be explicitly approved and all approved values must pass the review evidence checks.

`npm run doctor` performs bounded GET-only discovery. It can diagnose current upstream visibility but never enables payment.

## Stop and clean up

Stop the gateway with Ctrl-C. Keep the gateway stopped before retention cleanup:

```sh
node src/cli.js purge --days 7
```

Quickstart data is disposable and removes itself. Persistent catalogue/review outputs and the SQLite data directory are operator files; retain or delete them according to the data-handling policy in `docs/PRIVACY.md`.

## Evidence boundary

Passing local tests means only that local software checks passed in that environment. A real browser run, GitHub-hosted CI execution, maintained SDK/WASM execution, live Drone/GPU inference, real payment/charging and measured opt-in adoption are separate evidence classes and must be recorded separately.
