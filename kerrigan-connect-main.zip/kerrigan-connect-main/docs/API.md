# HTTP API — v0.1

Base URL: `http://127.0.0.1:8787`. Bearer authentication is required except for `/healthz`. Responses are marked `Cache-Control: no-store`. Requests cannot select arbitrary upstream URLs.

## Routes

| Method | Route | Behaviour |
| --- | --- | --- |
| GET | `/healthz` | Process health, mode and disabled live-spending flag |
| GET | `/v1/models` | Compatible model list; demo or observed live catalogue |
| POST | `/v1/chat/completions` | Submit and wait for a job; JSON or buffered SSE |
| POST | `/connect/jobs` | Durable async submission; requires `Idempotency-Key` |
| GET | `/connect/jobs` | Latest 50 jobs, including retained results |
| GET | `/connect/jobs/{id}` | State, accounting, result and events |
| POST | `/connect/jobs/{id}/retry` | Retry inference only when a payment ID is recorded |
| POST | `/connect/jobs/{id}/cancel` | Cancel an unpaid queued job |
| GET | `/connect/status` | Mode, budget use, limits and retention disclosure |

No route accepts private keys, raw payment transactions, user-asserted refunds or an instruction to enable mainnet spending.

## Submission

```json
{
  "model": "demo/catalogue-v1",
  "messages": [{"role": "user", "content": "Hello"}],
  "max_tokens": 128,
  "temperature": 0.7,
  "top_p": 0.9,
  "seed": 42,
  "budget_sats": 100000,
  "stream": false
}
```

Use a stable `Idempotency-Key` of 8–160 letters, digits, dots, colons, underscores or hyphens. Async submissions return 202 when created and 200 on replay. `Location` and `X-Kerrigan-Job-Id` identify the job.

Messages must be text with roles `system`, `user` or `assistant`; at least one user message is required. Limits: 64 messages, 100 KB of message data, 200 KB request body and 16384 output tokens. `max_completion_tokens` is accepted as an alternative to `max_tokens`, not alongside it.

Defaults match the observed wallet sampling parameters where applicable: temperature 0.7, top-p 0.9, seed 42 and internal `k=16`. This version rejects tools, embeddings, multimodal data, `response_format` and unknown parameters instead of silently dropping them.

For generic chat clients that omit the key, the server returns a generated `Idempotency-Key`. Durable clients should always supply their own before the first call.

## Completed responses

Chat completions include the usual `id`, `object`, `created`, `model`, `choices` and, where available, `usage` fields. The `x_kerrigan` extension includes:

```json
{
  "job_id": "job_<uuid>",
  "simulated": true,
  "verification": "not_performed",
  "payment_txid": "<64-character simulated hash>",
  "paid_sats": 1282,
  "network_fee_sats": 100,
  "refunded_sats": 890,
  "net_cost_sats": 492,
  "usage_estimated": true
}
```

Illustrative amounts only. Demo IDs are deterministic hashes, not broadcast transactions.

`stream: true` returns valid chat-completion SSE chunks followed by `data: [DONE]`. The entire output is obtained before these chunks are sent, and `X-Kerrigan-Stream-Mode: buffered` makes that distinction explicit. Native upstream token streaming is future work.

## Errors and recovery

Errors use `{ "error": { "code", "message", "type", "job_id"? } }`. Common codes:

| Code | Meaning |
| --- | --- |
| `live_spending_disabled` | Read-only mode cannot submit or pay |
| `idempotency_conflict` | Existing key with changed request |
| `job_budget_exceeded` / `daily_budget_exceeded` | No payment was authorised |
| `job_still_running` | Request wait timed out; poll the existing job |
| `reconciliation_required` | Payment outcome is unknown; no repayment permitted |
| `unsupported_parameter` | Feature not implemented by this compatible subset |

Submission errors use 400/401/402/409/413/415/503 as appropriate. The synchronous chat route returns 422 for an ordinary failed job and 409 for unresolved paid work, with the job ID attached. A wait timeout returns 504 and does not cancel a job.

No automatic cross-provider failover occurs after payment. Such a change would require refund/reconciliation and a new explicitly authorised job.
