# Reusable business task packs (A4)

Two bounded workflows turn a generic chat gateway into reviewable business jobs:

- `support-triage`: proposes priority, category, a one-sentence summary, exact supporting quote and an internal next action.
- `document-extraction`: extracts five literal fields from supplied text, with exact evidence and explicit missing fields.

They do **not** send email, update tickets, issue refunds, contact customers, fetch documents or acquire files. Outputs stay local until a human explicitly approves each case. The endpoint runner is compatible with the Connect gateway delivered in A2; live paid inference remains disabled in this repository.

## First run: labelled fixtures

From a clean checkout:

```sh
npm ci --ignore-scripts --no-audit --no-fund
npm run task:fixture -- --input examples/task-packs/support-triage.json --output output/support.fixture.json --run-id fixture-support-v1
npm run task:fixture -- --input examples/task-packs/document-extraction.json --output output/documents.fixture.json --run-id fixture-documents-v1
```

Fixture mode copies the dataset's labelled expected answers. It uses no model, HTTP endpoint, GPU or payment, and marks every row `execution.kind: fixture` and `labelled_expected_output: true`. Committed examples are under `fixtures/task-packs-v0.8.0/`. They prove schemas and workflow plumbing, not AI quality.

## Endpoint mode

Endpoint cases can contain just `id` and `source`; you do not need to know the answer before submitting a task. `expected` remains optional for a labelled evaluation, is validated when supplied, and never goes to the endpoint. Fixture mode still requires a valid expected answer for **every** case and refuses unlabelled batches before processing anything.

`examples/task-packs/support-input.json` contains three synthetic, unlabelled inputs for a first run. Start a gateway separately, set its API key only in the environment, and use an explicit model:

```sh
export KCONNECT_API_KEY='your-local-gateway-key'
node src/cli.js task-run \
  --input examples/task-packs/support-input.json \
  --output output/support.endpoint.json \
  --run-id pilot-support-001 \
  --url http://127.0.0.1:8787 \
  --model demo/catalogue-v1
```

Use the same persistent `--run-id` to resume an interrupted batch. Each intent key combines run, pack and a hash of the case ID. Replaying the exact request returns the existing job; changing a case while retaining its ID/run causes an idempotency conflict. The runner never invents a replacement key or automatically retries. Expected labels remain in the local result for comparison but are not placed in the request. Exit 0 means every response passed structural and literal-evidence validation; exit 2 means review is required. A valid structure is not proof that triage is correct.

Endpoint input is limited to 1,000 cases, each with a unique safe ID and at most 50 KB of source text. Files are bounded by the shared 2 MB JSON reader. Prompts say source text is untrusted data. Unknown pack fields, extra output fields, invented evidence and contradictory missing-field claims fail closed. Only supplied text is processed—PDF/OCR/download handling is deliberately outside this pack.

The bundled demo provider now produces deterministic simulated outputs for both packs. It uses no GPU and no KRGN. A real configured endpoint may produce different outputs; the receipt records `fixture` versus `endpoint` and preserves the job ID and simulation flag. No confidentiality guarantee follows from using the gateway.

## Human review and approved-only export

Review is intentionally explicit and file-based:

```sh
node src/cli.js task-review --input output/support.endpoint.json --output output/support.review.json

node src/cli.js task-decide \
  --input output/support.review.json \
  --output output/support.reviewed.json \
  --case-id support-new-001 \
  --decision approved \
  --reviewer 'Reviewer Name' \
  --notes 'Evidence and action checked.'

node src/cli.js task-export \
  --input output/support.reviewed.json \
  --output output/support.approved.jsonl
```

`task-review` starts every decision as pending—nothing is auto-approved. Repeat `task-decide`, using each new output as the next input, for other cases. Decisions are `approved` or `rejected`; an approval requires valid evidence, reviewer and timestamp. Source/output and decision fingerprints make edited results or hand-edited approval metadata invalidate the checkpoint. Export fails if nothing is approved, emits JSON Lines for approved cases only, and excludes source text, expected labels, pending and rejected rows. The export retains reviewer details, execution kind, simulation flag, job ID and source fingerprint for audit. A null simulation flag means unknown, never verified live execution. JSON encoding prevents spreadsheet formula execution; downstream systems must still treat all text as untrusted.

## Schemas

Support output:

```json
{
  "priority": "low | medium | high | urgent",
  "category": "billing | account | technical | shipping | other",
  "summary": "one sentence",
  "evidence": "exact source quote",
  "next_action": "proposed internal action",
  "needs_human": true
}
```

Document output has `document_type` (`invoice`, `purchase_order`, `receipt`, `unknown`), exact-string-or-null fields for `document_number`, `date`, `total`, `currency`, `supplier`, matching evidence fields, and a unique `missing_fields` list. Non-null values and evidence must be literal source substrings; null fields require null evidence and inclusion in `missing_fields`. Values are not normalised or calculated.

Datasets have `format_version: 1`, the pack name, and 1–1,000 cases containing `id` and `source`, with an optional valid `expected` label. No other case fields are accepted. An omitted label becomes `expected: null` in the result; an explicitly supplied null or malformed label is rejected. Mixed labelled/unlabelled batches are allowed in endpoint mode. Unlabelled results can be structurally validated and reviewed but have no measured answer accuracy. Synthetic samples include prompt-injection-like text to verify it stays data. Do not place real personal, payment-card, authentication or confidential data in the examples or repository.

## Verification boundary

```sh
npm run test:task-packs
npm test
npm run quickstart
```

Automated tests run both packs in fixture mode and through a real disposable loopback HTTP gateway. They cover authenticated requests, label omission, deterministic intent keys, replay without duplicate simulated payment, changed-source conflict, evidence failures, review tamper detection, approved-only export and actual CLI processes. These are local Node tests—not actual browser testing, third-party workflow validation, real Kerrigan inference, invoices, confidentiality proof or measured adoption. GitHub CI status is tracked separately.
