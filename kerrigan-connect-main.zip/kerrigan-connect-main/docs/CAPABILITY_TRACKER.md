# Capability and availability tracker

This tracker turns the existing GET-only discovery probe into timestamped evidence that developers and operators can compare. It writes machine-readable JSON plus small Markdown and self-contained HTML reports. It never sends a prompt, calls a submission endpoint, requests an invoice, uses a wallet or spends KRGN.

## Capture and compare

Capture one configured Coordinator view:

```sh
NODE_USE_ENV_PROXY=1 npm run snapshot -- \
  --output output/capability-snapshot.json \
  --attempts 2
```

`--attempts` is restricted to 1–3. Retries happen only when one of the bounded GET observations fails. The command writes the named JSON file, `.md` and `.html` companions. Exit 0 means all three endpoints returned a fresh observed value. Exit 2 deliberately preserves a stale, empty, zero or failed observation for diagnosis. Malformed evidence exits 1.

A saved `npm run probe -- --output probe.json` result can be normalised without network access:

```sh
npm run snapshot -- \
  --input probe.json \
  --output output/capability-snapshot.json
```

Compare two tracker snapshots:

```sh
npm run snapshot-diff -- \
  --baseline previous.json \
  --input current.json \
  --output output/capability-diff.json
```

This also writes Markdown and HTML. Inputs are never overwritten. Model order, provider references, capability fingerprints and change lists are stable, so the same evidence produces the same substantive diff. Report-generation timestamps can differ.

## What each state means

| State | Meaning | Removal events |
| --- | --- | --- |
| `comparable` | Both model observations are fresh and successful | Reported |
| `unknown_current_endpoint_failure` | The current models GET failed | Suppressed |
| `unknown_current_stale_or_invalid` | The current observation is older than five minutes, future-dated or invalid | Suppressed |
| `empty_current_advertised_list` | The endpoint succeeded and advertised an empty list | Suppressed; emptiness is not called a removal |
| `unknown_baseline` | The baseline failed or is not fresh | Suppressed |
| `recovered_from_empty_advertised_list` | A fresh list followed an explicitly empty fresh baseline | Additions reported; removals suppressed |

The connected-Drone observation separately distinguishes `zero_connected_reported` from `endpoint_failure`. An actual model or provider removal is emitted only between fresh, successful, non-empty model observations. A removal means the advertisement disappeared between those two observations; it does not establish why.

## Source and privacy boundary

Primary sources reviewed on 25 September 2026:

- The pinned [public Kerrigan SDK adapter](https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/webwallet/src/network.js) shows that `/v1/models` aggregates models advertised by providers connected to one Coordinator, and exposes a current connected-Drone count.
- The [Kerrigan site](https://kerrigan.network/) describes the evolving GPU-compute marketplace, but does not turn one Coordinator response into a network-wide census or service-level measurement.

Every report includes its Coordinator source, observation/capture dates and the one-Coordinator scope. Raw provider identifiers are not exported: stable shortened SHA-256 references allow change detection without copying the upstream identifier. Models and providers are capped at 1,000 per observation. The source must be an HTTPS origin and inputs are subject to the CLI's 2 MB JSON limit.

A snapshot is an observation of advertisements, not proof of whole-network capacity, availability percentage, successful inference, GPU ownership, model quality, confidentiality, invoice correctness or payment. Hosting and recurring collection are separate release/operations choices; this repository neither deploys the report nor runs a public monitor.

## Tests and validation boundary

```sh
npm run test:tracker
npm test
```

Fixture tests cover bounded retry recovery, endpoint failure, zero providers, empty lists, stale evidence, model/provider/capability changes, safe removal suppression, recovery from empty, identifier redaction, malformed inputs and actual CLI JSON/Markdown/HTML output. They are local automated tests, not browser testing, third-party application validation, live GPU use, uptime measurement or adoption evidence.
