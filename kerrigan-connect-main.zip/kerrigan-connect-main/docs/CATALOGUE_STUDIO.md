# Catalogue Studio

Studio adds a local merchant workflow to the existing gateway. It reuses catalogue validation, durable job identities, the job ledger and the human-review engine. No additional npm dependencies are required.

## Start and use

Use Node 24.14+ in the 24.x line and follow the gateway startup instructions in the README. Keep the terminal running. Open `http://127.0.0.1:8787/studio` on the same computer and enter the `KCONNECT_API_KEY` configured for that gateway. The key is retained in tab memory only, cleared from the input after connection, and excluded from downloaded files.

1. Choose a CSV with unique `id` and `description` columns, or use the six sample products. The existing parser accepts quoted commas/newlines, up to 1,000 products and 2 MB. Duplicate IDs, missing fields and malformed CSV are rejected before submission.
2. Select an advertised model and a category list containing `Uncategorised`. Prepare the batch to fix its source and intent identities.
3. Save the batch checkpoint before processing. The browser starts a download; keep the resulting file. Click **Process batch**. Progress includes each job's status and recorded cost. Pause takes effect after the current product; it does not cancel a submitted job.
4. Open review after every product has a terminal receipt. Check the source description, correct fields, approve or reject. An accepted schema is still pending human review. Editing an approved product resets approval.
5. Download a **review checkpoint** to preserve decisions and export approved rows. Pending and rejected products are excluded. The CSV retains simulation and job provenance and neutralises spreadsheet formulas.

To start a different batch, save current decisions and reload the page. One batch is mounted per tab to avoid replacing unsaved review work.

## Recovery and the two checkpoints

The **batch checkpoint** stores original CSV, categories, model and stable run ID. Reconnect to the same gateway/data directory after a tab or server restart, select **resume a saved batch**, then Resume. Existing jobs are replayed with the same keys. An uncertain network response does not cause an automatic new submission identity. Changed input under the same identity conflicts instead of creating another job.

The **review checkpoint** stores the original validated source and decisions. After restoring the batch and opening review, restore this file inside the review workspace. Restore requires the exact original review source; edits during an in-flight restore prevent stale decisions replacing newer work. A batch checkpoint alone does not save approval decisions.

Keep the original gateway database. A batch checkpoint cannot prove that a job already executed if that ledger is deleted or a different gateway is used. Studio does not enable a live-spending route. Review requires receipts whose stored request fingerprint and idempotency key both match the batch; arbitrary job IDs or browser-supplied model output are not trusted.

## Status and costs

The owner confirms Kerrigan inference is operational. This application currently processes via **Connect demo mode**, with deterministic simulated outputs and accounting; it has no real KRGN spend. Connect read-only mode advertises discovery but does not enable processing. Live activation and distribution are later milestones, not part of this product build.

Rows awaiting work or requiring reconciliation show unknown final cost. The batch total reports recorded sats separately from unknown rows; demo totals are labelled simulated. This does not establish real network charges, model quality or verification of GPU execution.

The static assets contain no credentials or product data. Data endpoints require the gateway's bearer key and its loopback host/origin restrictions. The page loads only local scripts/styles; product text is inserted as text, not HTML. Source products and results are retained in the unencrypted local SQLite database. Downloaded batch/review files contain product data.

## Verification

`node --test test/studio.test.js` exercises the real loopback API, authentication, bounded inputs, receipt/source binding, uncertain costs, replay, lost-response recovery and approval-only export. Its DOM harness checks event wiring and file bytes; it does **not** prove browser rendering or CSP enforcement.

`npm run test:install` installs a tarball into a clean temporary project and exercises the installed assets, preparation, submission, restart replay and review export. `npm test` includes both suites and the existing standalone review runtime checks.

`node scripts/verify-studio-browser.mjs` is the native Chromium flow when separately installed Playwright/Chromium are available. `KCONNECT_PLAYWRIGHT_MODULE` and optional `KCONNECT_CHROMIUM_EXECUTABLE` follow the standalone review verifier. It uses synthetic products on loopback, records a receipt and screenshots under `output/studio-browser`, and cleans up its temporary database. The optional browser workflow runs both verifiers. Browser evidence must be recorded separately from HTTP and DOM-harness results.
