# Integration route: maintained wallet and Connect boundaries

Reviewed 26 September 2026. Current public SDK master is `ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29`.

Source: https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/webwallet/src/network.js

The public wallet already implements discovery, invoice relay, inference submission, streaming, raw transaction broadcast and ElectrumX transaction lookup. These are not missing upstream features. Connect now has a custody-neutral adapter to the maintained signer plus durable reconciliation; the compiled SDK still has not been executed in this environment. The wallet caller, JS wrapper and Rust/WASM payment builder were inspected on 26 September 2026; source inspection is not executed integration evidence.

| Boundary | Public adapter | Connect position |
| --- | --- | --- |
| Discovery | GET /v1/models; per-model providers, ID, name and GGUF hash | Connect exposes ID to clients and retains advertised name for the wire; missing name blocks quoting |
| Invoice | POST /v1/invoice; model, messages, max_tokens, pinned drone hash; HTTP 200 may contain error | Local real-HTTP contract now exercised; no live invoice request |
| Inference | POST /v1/chat; original sampling fields and payment_txid; upstream documents replay caching | Local wire replay tested; no claim that a real Drone cache or charging has been verified |
| Streaming | Public wallet supports SSE | Connect currently buffers; not equivalent |
| Broadcast/lookup | Bridge POST sendrawtransaction; ElectrumX blockchain.transaction.get; supplied Swarm snapshot also exposes coordinator GET `/v1/tx/:txid` | Maintained-wrapper adapter, prepared journal, loopback broadcast and strict GET reader are locally compatible; actual WASM execution and a live reader remain open |
| Refund/verification | Supplied snapshot indexes lifecycle and provider-emitted 0x06 refund reference | Invoice-bound lifecycle reader implemented; indexed fields are observations, not independent verification or credit |

Initial implementation adds transaction-reference format validation before any inference request and actual loopback relay tests for invoice/provider binding, unchanged replay payloads and HTTP-200 provider rejection. Format validation does not prove a payment exists. All test content and references are synthetic. E1 remains in progress.

## Model selection and replay fix

The maintained [AI caller](https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/webwallet/src/views/ai.js) selects by `gguf_hash` and passes `activeModel().name` to both invoice and inference calls. Connect previously sent the public catalogue ID directly. These fields need not be identical.

Connect now snapshots the normalised request before asynchronous discovery, uses the advertised name for both wire calls and saves it in `x_connect_binding` on the returned quote. Request and invoice fingerprints catch accidental changes to messages, model ID, sampling settings, provider, amount, address, expiry or token limit before inference is sent. The name remains pinned after saving/loading the quote and after a catalogue rename; replay does not rediscover a different model. Binding metadata is local and never sent to the coordinator. Missing/invalid names stop before an invoice POST rather than guessing a name from the ID.

The fingerprints are unkeyed local consistency checks, not authenticated receipts or protection from a party rewriting both data and fingerprints. They do not establish a relationship between GGUF hash and the invoice's eight-byte model hash. That relationship, provider-side validation and real transaction reconciliation remain to be established against maintained Drone sources. Old experimental quotes without binding metadata cannot be submitted through this adapter. A future live adapter must reconcile any payment already made before considering a replacement quote; it must never automatically repay because a binding is missing.

## Maintained signing route inspected

- [Wallet SDK wrapper](https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/webwallet/src/sdk.js): `buildInferencePaymentTx(utxos, invoice, params, seed, account, index)` calls the maintained `inferParamsHash`, derives change address and invokes WASM. Its `topP` input must be mapped from Connect's `top_p` without changing values.
- [WASM interface](https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/sdk/src/wasm.rs): `build_inference_payment_tx` consumes UTXOs, payment/change addresses, integer amount, provider/model/parameter hashes, max tokens and derivation inputs. It returns `tx_hex`, `txid`, `fee`, `spent_utxos`.
- [Rust payment builder](https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/sdk/src/inference/payment_tx.rs): builds provider payment at output 0, inference OP_RETURN at output 1 and optional change, using maintained transaction signing primitives. Connect must reuse this implementation, not reproduce cryptography.
- [Inference module](https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/sdk/src/inference/mod.rs): includes payment and change/refund wire builders. BLS fields being carried by these formats do not mean the wallet layer verifies them.

Connect now exposes `kerrigan-connect/integration`. `MaintainedSdkPaymentPreparer` accepts the maintained webwallet wrapper plus an owner-controlled `withSigningSession` boundary. It maps `top_p` to `topP`, passes the exact saved invoice/sampling fields to `buildInferencePaymentTx`, binds spent inputs to the supplied UTXO set and independently checks the transaction ID against the returned raw bytes. It does not implement signing, derive or retain a mnemonic, persist seed bytes, or make live mode reachable from the CLI. Instrumented SDK tests exercise the adapter through durable preparation and real loopback HTTP broadcast; they do not execute the WASM module.

Remaining E1 work: establish and execute a reproducible SDK/WASM load/build path; confirm the supplied Swarm snapshot against current private upstream; exercise the transaction reader against the maintained service; and add independent transaction/refund semantic verification. Keep any real signing key under owner custody. E2 application/browser validation, E3 install/recovery and E4 onboarding can advance independently where appropriate. E5 still requires a concrete pilot proposal and separate authority.

## Prepared payment recovery increment

[PAYMENT_RECOVERY.md](PAYMENT_RECOVERY.md) describes the implemented SQLite prepared-transaction journal, exclusive broadcast attempt, input reservations, loopback wallet-compatible transport and lookup-only recovery. It is exercised through the real Connect demo gateway, including lost acknowledgements and restart. The maintained-wrapper adapter is connected to that boundary, but signing and lookup evidence in these tests remain synthetic; the compiled SDK/WASM and ElectrumX reader have not been executed. Rust and wasm-pack are absent from the current execution environment. E1 remains in progress.

The owner-supplied Swarm archive (commit marker `d0ff0fb425b5f234eb57b4678cc1596230b8d62c`, dated 16 June 2026) was inspected for Drone and coordinator semantics. It documents exact payment checks, durable served-response replay, output-only refund rules and GET-only chain/lifecycle routes. Because this snapshot may predate private upstream, findings are scoped and current confirmation remains open. Connect now implements the GET readers and an invoice-expiry safety gate without enabling live mode.

## Validation on 26 September 2026

`node --test test/sdk-payment.test.js test/payment-recovery.test.js`: 16 passed. `npm test`: 128 passed on Node 24.19.0/Linux with Python 3.12.14. The SDK cases cover exact wrapper arguments, single initialization, pre-session invoice rejection, one-shot wallet sessions, input/output integrity and durable loopback broadcast. Existing coordinator cases cover distinct ID/name fields, persisted quote replay, catalogue rename, mutated request/invoice, missing/invalid name and caller mutation during discovery. These use synthetic transactions and an instrumented SDK, not a compiled WASM module, real Drone, wallet, supported third-party app or GPU/payment. No browser validation was performed for this change.

GitHub Actions run [36237819345](https://github.com/BoltBlew/kerrigan-connect/actions/runs/36237819345), on the prior implementation commit, failed before any steps. Its job had the `ubuntu-latest` label, runner ID/group 0 and no runner name. Cause remains unknown; no unchanged rerun or workflow weakening was attempted. CI execution remains an open E3 gate.
