# Offline catalogue review

The review workspace makes the catalogue workflow usable before wallet and
repository integration. It lets a person correct suggested classifications,
approve individual products, and export a reviewed CSV for a later import.
It does not publish to a shop or send anything to Kerrigan.

## Open the included example

Download and open `examples/catalogue-demo.review.html` in a browser. It is a
single file with its data and code included. No Node install, account, server,
API key or internet connection is required to use the included example.
The six example results come from the deterministic simulation, not a GPU.

To generate it again from source:

```
npm run review-demo
```

Open `output/catalogue.review.html`. The companion `.review.json` contains the
source batch and initial pending decisions.

## Review a batch

1. Select a product or search by its ID or description.
2. Read the original description and, if useful, expand the proposed result
   and job receipt.
3. Correct the category or attributes. Leave an attribute blank when unknown.
   Non-empty attributes must occur literally in the source description.
4. Approve or reject that product. Nothing starts pre-approved, including
   results that passed schema validation. Editing any field or note resets
   the decision to pending.
5. Download a checkpoint to save the current source and decisions. Restore
   that JSON file into the same review page to continue later.
6. Export approved rows. Pending and rejected rows are excluded. CSV cells
   that could be spreadsheet formulas are escaped.

Decisions exist in the current tab until downloaded. There is no localStorage
or background autosave. Closing the page can lose unsaved changes; the page
requests a browser leave warning, but browsers control whether it appears.
A download starting is not proof that the file has been saved by the browser.
The restore control explicitly replaces this tab's decisions. Keep a checkpoint
first if you want to retain the previous version.

The displayed schema result is not an accuracy claim. Literal evidence cannot
detect every semantic error, such as a colour appearing only in a distractor.
The reviewer must check the meaning of the source description.

## Use results from the gateway or benchmark

Both commands now emit additional `.review.json` and `.review.html` files:

```
node src/cli.js catalogue --input examples/catalogue.csv --output output/products.csv
npm run benchmark -- --output output/benchmark.json
```

The catalogue command requires the local gateway and API key described in the
README. The default benchmark stays offline. Review files are created after
the batch completes; the original resumable jobs and intermediate CSV remain
available if the batch is interrupted.

Reopen a saved checkpoint as a new review page, or export it on the command line:

```
node src/cli.js review --input kerrigan-review-decisions.json --output output/review.html
node src/cli.js export-reviewed --input kerrigan-review-decisions.json --output output/approved.csv
```

The CLI revalidates approved values and the source fingerprint. An export with
zero approved rows exits 1 and does not write a CSV. The approved CSV carries
source descriptions, corrected values, notes, decision timestamps, original
job IDs, recorded costs, simulation labels and a source fingerprint.
Costs belong to the original jobs and are not new spending by the reviewer.

## Provenance and boundaries

- A checkpoint stores the **latest decision** for each row; it is not an
  append-only audit log and does not authenticate the reviewer's identity.
- Its fingerprint helps detect changed source data. It is not a signature;
  a person editing the file can recompute it or assert an approval manually.
- Browser restore compares the full source batch and fingerprint with the
  source embedded in the page. A different batch or duplicate/partial
  decisions are rejected before replacing existing decisions.
- Runtime text is inserted as text, and source JSON cannot close the script
  element. A content policy permits only the generated script and blocks
  network connections and remote assets. There are no analytics or remote
  fonts. Files still contain the original descriptions; handle downloaded
  copies according to your own data-retention policy.
- Approval is not a compute proof or a confidentiality guarantee. Live
  inference and real payments remain disabled in this release.
- This is a generic reviewed CSV, not a certified Shopify, WooCommerce or
  marketplace importer. Map columns to the destination before importing.

## Browser verification

The optional `scripts/verify-review-browser.mjs` exercises the file directly in
Chromium: approval, editing, evidence validation, checkpoint and CSV downloads,
restore, rejection of a changed batch, filters and mobile layout. It asserts
no page errors and no HTTP requests. It requires Playwright and its Chromium
browser in the development environment; neither is a runtime dependency of
Connect or required to open the standalone review file.

```
node scripts/verify-review-browser.mjs
```

If Playwright is installed outside this repository, set
`KCONNECT_PLAYWRIGHT_MODULE` to that module's absolute path. Use `TMPDIR` for a
writable temporary directory in restricted environments. Browser screenshots
and downloaded test artifacts are written to ignored `output/browser/`.

Current verification: 47 automated tests pass, including a DOM harness running
the generated page script. Chromium execution and visual inspection could not
be completed in the build environment because the browser download failed.
The browser verification script is supplied, not reported as passed.

## Compare saved review checkpoints (v0.4)

```
node src/cli.js review-diff --baseline examples/catalogue-demo.review.json \
  --input kerrigan-review-decisions.json --output output/review-changes.json
```

This writes JSON and a companion `.md` report showing field/note changes,
state transitions, approvals added and approvals removed. Both files must
refer to the same source batch; the original inputs are never overwritten.
The two checkpoint fingerprints identify the exact supplied snapshots.
This does not reconstruct intermediate actions or authenticate reviewers.

An edited record that remains approved with the same approval timestamp gets
an explicit warning and exit code 2. Treat that as a reason to inspect the
checkpoint, not proof of misconduct. Exit 0 means comparison completed without
that warning; exit 1 means invalid inputs or another error.

The optional GitHub workflow `Verify offline review in Chromium` runs the
existing browser script on manual dispatch. It installs pinned Playwright
1.62.1 outside the application and the matching Chromium browser. It has not
run yet. Runtime operation of Connect still has no external npm dependencies.
Reference: https://playwright.dev/docs/ci-intro
