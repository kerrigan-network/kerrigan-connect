# First useful result

Requires Node **24.14 or later in the 24.x series**. The app has no runtime npm dependencies.

```sh
git clone https://github.com/BoltBlew/kerrigan-connect.git
cd kerrigan-connect
npm run quickstart
```

Repository access is required while this staging repository is private.

The command creates a random local API key, a temporary SQLite database and a gateway on a free loopback port. It runs nine real HTTP checks, restarts the gateway, verifies that replay adds no simulated payment, and removes its temporary data. It exits 0 for a pass and 1 for a failed check. It ignores existing gateway/wallet environment configuration and never contacts Kerrigan or another remote service. The JSON receipt contains no prompts, keys or machine identifiers.

To save the receipt:

```sh
npm run quickstart -- --output output/first-run.json
```

## Try a useful workflow

```sh
npm run review-demo
```

Open `output/catalogue.review.html`, review a product, correct a value, approve it, and download approved CSV. Six synthetic products and deterministic rules demonstrate the workflow. They do not measure an AI model's quality.

## Connect your app

For a persistent gateway, set `KCONNECT_API_KEY` to a freshly generated random value of at least 24 characters and run `npm start`. See the root README for shell examples. Model discovery is `GET http://127.0.0.1:8787/v1/models`; compatible chat is `POST /v1/chat/completions` with Bearer authentication. Use a stable `Idempotency-Key` before sending a request so a lost response can be retried without creating another intent. Reuse the original key and exact request; a changed body requires a new key.

Supported now: text chat, asynchronous jobs, and buffered SSE. Tools, embeddings and multimodal requests fail explicitly. Client keys belong in local environment configuration, never committed examples. Persistent mode retains job input/output in local SQLite; it is not encrypted by this application.

## Inspect real availability

```sh
npm run doctor
```

This separately makes GET requests to the configured coordinator and explorer. A successful doctor result means discovery is reachable; it does not enable paid inference. Its model list covers one coordinator, not the whole network. An unavailable endpoint is reported as unavailable.

## Understand the result

| Check | What it establishes |
| --- | --- |
| Local service, authentication, model discovery | The local integration surface starts and requires its key |
| Chat completion, buffered stream | Text and SSE response contracts work locally |
| Replay, changed-request rejection, restart replay | The demo preserves one intent across retry and restart |
| Capability boundary | Unsupported tool parameters are rejected |

No real GPU inference, payment, refund or confidential compute is verified by this command. Live activation prerequisites are in `WALLET_INTERFACE.md`; real network use needs the maintained signing interface and an explicitly funded pilot.

Troubleshooting: use `node --version` to check the required runtime; allow local loopback sockets and writable temporary storage. A free port is selected automatically. Run `npm test` for a more detailed local regression result. Avoid posting database files or keys in issue reports.
