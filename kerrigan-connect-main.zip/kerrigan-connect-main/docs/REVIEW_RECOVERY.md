# Review checkpoint recovery: E2/E3 increment

Recorded 26 September 2026. This is a tested recovery fix, **not E2 completion**. Machine-readable evidence and exact content hashes are in [review-recovery-2026-09-26.json](evidence/review-recovery-2026-09-26.json).

## Defect and fix

The review page reads an imported checkpoint asynchronously. Previously, a read finishing after a newer edit, rejection, reset or checkpoint selection could replace the latest decisions. In particular, it could silently bring back a saved approval after the reviewer had rejected the product, making it eligible for approved-only export again.

The page now snapshots its decision revision and the current restore attempt before reading. A newer edit or decision cancels that restore with a visible explanation. A newer file selection supersedes older reads, even if the newer file is invalid. Superseded reads cannot overwrite decisions, display a late error over a newer result, or clear the current file input. The original source batch remains unchanged.

Explicit checkpoint restoration still replaces the current decisions when no intervening change occurs. This is not autosave, a merge of two reviews, an append-only audit trail or authenticated reviewer identity.

The included `examples/catalogue-demo.review.html` was regenerated using the unchanged labelled dataset and current renderer. A regression checks exact equality with generated output. Old HTML copies already downloaded to a user's machine do not update automatically: use the regenerated page or render a new page from the saved checkpoint, then restore the checkpoint as normal. Keep saved checkpoint files before replacing any local copies.

## Local execution evidence

The local environment has Node **22.16.0**, Linux x86_64. A SHA-verified copy of the review modules and their test was reconstructed from current main; it is **not a full repository checkout or a supported product installation**.

Command: `node --test test/review-runtime.test.js`.

- Original renderer and original test: 1 passed.
- Original renderer and expanded regression: 9 tests, 2 passed and 7 failed. The failures reproduced lost edits/decisions and out-of-order restore behavior.
- Fixed renderer, expanded regression and bundled-page parity check: **10 passed**, none failed, skipped or cancelled.

The tests exercise the actual generated page script in the existing DOM/event-wiring harness. They check the downloaded checkpoint/CSV bytes, dirty-state warning, approval invalidation, rejection preservation, newer-selection precedence, error handling, size limit and bundled-source parity. They do not emulate browser layout, file-picker policy or Content Security Policy enforcement.

`node --check scripts/verify-review-browser.mjs` also passed; that establishes syntax only. The repository-wide `npm test`, fresh-package installation and pinned Node 24.19.0 execution have **not** been performed for this increment. The Node 24.14+ / 24.x product requirement is unchanged.

## Native browser attempt and precise blocker

Chromium **144.0.7559.96 (Debian 13 build)** launched using Playwright **1.57.0**, but navigation to both the generated `file:` review page and a temporary `http://127.0.0.1` synthetic-page server failed with `net::ERR_BLOCKED_BY_ADMINISTRATOR`. The application did not load and no application assertions or visual checks ran. The browser and temporary server were stopped.

No browser policy, permissions or security settings were changed. No `set_content`, data-URL substitute or fixture screenshot was counted as native application acceptance. The failure is an execution-environment navigation restriction; it does not establish a rendering defect in Connect. Conversely, the passing DOM tests do not prove the application works in a real browser.

The optional browser verifier now renders current source instead of relying on a potentially stale bundled file. It preserves existing review/export/reload/mobile checks, adds slow-read and newer-selection tests through actual controls, and records versions, source hashes, phase, status and completed checks in `output/browser/browser-receipt.json`. Its new journey is supplied and syntax-checked, **not reported passed**.

Run it in an authorized environment where normal local-file navigation is permitted:

```sh
node scripts/verify-review-browser.mjs
```

With tooling installed outside the application, `KCONNECT_PLAYWRIGHT_MODULE` can point to its Playwright module directory. `KCONNECT_CHROMIUM_EXECUTABLE` can point to an already installed Chromium executable; this option does not change or bypass that browser's policy. Do not alter administrator policy solely to pass the test. Neither setting is needed when the standard Playwright installation and browser are available. Browser tooling remains optional and outside Connect's runtime dependencies.

## CI and programme status

The previously recorded GitHub run `36254932107`, job `108439796210`, was read again through the Actions run-jobs API: failure, zero steps, `ubuntu-latest`, runner ID/group 0, empty runner name. The connector rejects the check-run detail endpoint, so no allocation-error annotation was obtained and the exact platform cause remains unknown. No unchanged rerun, workflow weakening or self-hosted reassignment was requested.

E2 remains open for an actual supported application workflow through Connect, review/export and restart/retry/duplicate intent. E3 still requires the full supported-runtime suite, fresh-install execution and real CI. E1's maintained compiled SDK/Drone and independent transaction/refund verification work is unchanged. E5 still requires separate authority and real execution/charging/opt-in repeat use. This increment spent no KRGN, used no payment keys or GPU execution, and measured no adoption.
