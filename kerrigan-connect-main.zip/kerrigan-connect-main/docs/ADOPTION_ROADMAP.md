# Kerrigan adoption build plan

Owner objective: build useful ecosystem complements that reduce the effort to try, integrate and repeatedly use Kerrigan. Canonical staging repository: `BoltBlew/kerrigan-connect` (private). Research refreshed 25 September 2026. This is a finite programme of seven independently buildable deliverables, followed by a release handoff.

## What the current evidence supports

- The [official website](https://kerrigan.network/) describes multi-algorithm proof of work, Sapling transaction privacy, masternodes/BroodNodes and an AI marketplace. It distinguishes the current bootstrap burn from intended V2 inference block rewards. Transaction privacy alone does not establish prompt confidentiality.
- The [public SDK](https://github.com/kerrigan-network/kerrigan-sdk) provides Rust wallet primitives, a CLI, shield bridge and browser wallet. Its current master was still `ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29` on this research pass. Existing wallet tooling makes another general wallet a poor use of our effort.
- The SDK wallet's [network module](https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/webwallet/src/network.js) and [AI view](https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/webwallet/src/views/ai.js) expose a discovery → provider-bound invoice → payment → inference flow. The remaining integration questions are recorded in `UPSTREAM_CONTRACT.md`.
- A fresh GET-only observation at **2026-09-25T18:21:08.285Z** found one advertised Llama 3.2 3B model, one connected Drone and inactive Drone block payouts on the configured coordinator/explorer. This is a dated observation of one coordinator, not a network census or a guarantee that inference can be purchased.
- The Swarm repository returned 404 through the current GitHub connection; that could mean access restrictions. The official guide could not be fetched by the web reader. Neither result proves documentation or implementation is absent upstream.
- Connect already has a local gateway, durable jobs, simulated accounting, JS client, n8n sample, catalogue evaluator/review workflow and GET-only discovery. Build on these rather than duplicate them.

The gaps below are **integration opportunities inferred from the interfaces we could inspect**, not an exhaustive audit of private Kerrigan work. Each item has a usable local or read-only deliverable that can be built without another account, private upstream access or spending. Actual adoption improvements remain hypotheses until users try them.

## Priority order

Rank reflects closeness to a user's first/repeated useful request, number of integrations helped, certainty that we can deliver, and current upstream dependencies. We have no user-conversion data supporting numeric impact estimates.

| Rank / ID | Deliverable | Adoption reason | Completion evidence |
| --- | --- | --- | --- |
| 1 / A1 | First-run developer toolkit | Remove setup uncertainty and get developers to a working request quickly | One command, disposable local HTTP gateway, auth/chat/SSE/retry/restart checks, secret-free receipt, setup guide |
| 2 / A2 | App integration kit | Let Python and JavaScript applications connect through familiar interfaces | Python standard-library client, runnable JS/Python/curl examples, documented compatibility matrix, actual local HTTP contract tests |
| 3 / A3 | Model and workload planner | Answer “which advertised model fits my task and what might it cost?” before users attempt a request | Validated model snapshot, explicit token estimates, context checks, integer cost arithmetic, stale/missing-rate handling and CLI JSON/Markdown output |
| 4 / A4 | Reusable business task packs | Give users repeatable work beyond a generic chatbot and the existing catalogue demo | Support-triage and document-field-extraction packs, synthetic datasets, schemas, endpoint runner, review/export and replay tests |
| 5 / A5 | GPU provider preflight | Reduce avoidable setup/support friction for potential inference suppliers | Local or supplied inventory parsing, opt-in GPU check, model-memory/config checklist, redacted support bundle and fixture tests |
| 6 / A6 | Capability and availability tracker | Make discovery changes and failures understandable for developers/operators | Bounded GET-only snapshot/diff CLI, model/provider additions/removals, stale/unknown states, single-coordinator scope, JSON/HTML report |
| 7 / A7 | Pilot evidence and adoption measurement kit | Give maintainers evidence about which integrations deserve promotion | Local opt-in event schema and summaries, versioned acceptance manifest, baseline/comparison reports, release checklist and reproducible handoff |

## Build steps and acceptance

### A1 — First-run developer toolkit

1. Compose the existing gateway, demo provider and SQLite ledger behind an automatically chosen loopback port.
2. Exercise the real HTTP boundary, including rejected auth, repeated intent, changed intent, unsupported tools, buffered SSE and restart replay.
3. Produce a sanitised JSON receipt, explain the path to the existing review demo, and include the command in CI.

Done: nine checks pass, bad auth/transport paths fail, data and server are removed, `npm test` passes. **Delivered in v0.5.0.** This establishes local integration readiness only.

### A2 — App integration kit

1. Document the exact supported compatible subset; preserve unknown/unsupported features as explicit errors.
2. Add a dependency-free Python client with bounded responses, deadlines and caller-supplied intent keys; provide runnable curl and JS examples.
3. Test Python and JS against a real disposable gateway: success, replay, conflict, timeout and unauthorised access. Existing n8n example is retained; do not call it n8n-verified without exercising a real n8n installation.

Done: examples work from a clean checkout, credentials are environment-only, no implicit new-key retry, and compatibility results state the versions and environment tested. Do not claim Open WebUI/LangChain support from protocol similarity alone. **Delivered in v0.6.0**; see `APP_INTEGRATION.md` and `fixtures/integration-v0.6.0.json`.

### A3 — Model and workload planner

1. Consume existing probe output with freshness and source scope preserved.
2. Accept explicit input/output token estimates and task requirements; reject impossible context budgets and unknown capability assumptions.
3. Return scenarios using advertised input/output rates; show missing values as unknown, fees and final invoice separately, and deterministic tests for overflow and stale snapshots.

Done: CLI JSON and readable report identify suitable advertised candidates or explain why none can be confirmed. Estimates must never be called invoices, final costs or measured throughput. No token-price predictions or GPU profitability promises. **Delivered in v0.7.0**; see `WORKLOAD_PLANNER.md` and `fixtures/planner-v0.7.0.json`.

### A4 — Reusable business task packs

1. Define support-triage and document-extraction schemas, small labelled synthetic cases and prompt templates.
2. Add an explicit endpoint runner with resumable intent IDs; retain local deterministic fixtures for regression testing.
3. Add evidence/field validation, human review and safe export; distinguish sample expected answers, fixture runs and actual model outputs.

Done: both packs run locally with labelled fixture outputs; actual endpoint mode has tested HTTP contracts, review prevents unapproved exports, repeated runs do not create duplicate intents. No email sending, ticket modification or external document acquisition. **Delivered in v0.8.0**; see `TASK_PACKS.md` and `fixtures/task-packs-v0.8.0/receipt.json`.

### A5 — GPU provider preflight

1. Inspect maintained public provider instructions before encoding checks; tag any requirement without a source as unknown.
2. Parse a supplied inventory and optionally read local GPU inventory using a documented command without privilege escalation or installation.
3. Produce actionable readiness checks and a redacted support report for missing drivers/memory/runtime requirements.

Done: fixture tests cover absent GPU/tooling and malformed reports; no wallets, public IPs, serial numbers or secrets in exports. Results are diagnostics, not proof of registration, earnings, VRAM sufficiency for every model, or live serving. No node is registered or funded automatically.

### A6 — Capability and availability tracker

1. Extend the GET-only probe into bounded timestamped snapshots and stable diffs.
2. Classify endpoint failure, stale observation, empty advertised list and genuine model/provider removal separately.
3. Render a small shareable report with source and observation date. Add retry limits and fixture tests; leave hosting as a separate release choice.

Done: known snapshots produce correct diffs and unknown states; no prompts/POSTs/payments, no uptime percentage from a single probe, and no whole-network capacity claim from a single coordinator.

### A7 — Pilot evidence and adoption measurement kit

1. Define local opt-in events for first-run pass, first useful workflow, return workflow and verified live request; keep simulation and real activity distinct.
2. Generate aggregate reports from supplied local events without transmitting telemetry or collecting prompt content/device fingerprints.
3. Package completed deliverables with exact versions, tests, compatibility limits and maintainer handoff. Record the live-integration and public-release decisions still needed.

Done: deterministic event deduplication and summary tests, no fabricated users or conversion lift, current documentation, all seven deliverables accepted, and an explicit final programme report.

## What is outside autonomous completion

The highest ultimate conversion step is a real paid request, but Connect still requires confirmation of maintained signing/reconciliation/verification contracts and a funded pilot. That is a documented release dependency, not an excuse to label local tests as network adoption. Publication/license choice, public hosting, live spending, key custody, external marketing and upstream merges require their actual access/authority. Keep all work in the private BoltBlew staging repository until those choices are made.

## Measurement and stopping

Desired eventual funnel: interested developer → successful first run → connected app → first useful task → verified real Kerrigan request → repeat real use. Provider activation is a separate funnel. Locally testable proxies include clean-checkout success, diagnosable failure, integration completion and repeat-intent correctness. No current adoption lift is claimed.

`ADOPTION_STATE.json` is the finite backlog. Each run starts from current GitHub main, takes the highest-ranked pending actionable acceptance criterion, implements/tests it, commits it and updates evidence. Preserve user changes and never force-push. No concurrent runs: an unfinished current-run claim with a recent timestamp is a reason to skip that invocation.

When all seven items are accepted, produce the final handoff and disable the hourly automation. If only owner/upstream blockers remain, record the precise blockers once, pause the automation and report that the programme is incomplete. Do not inflate the backlog or repeatedly rerun a CI job that never receives a runner. A later explicit owner request may reopen scope.
