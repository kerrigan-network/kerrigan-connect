# End-to-end delivery programme

Reopened by the owner on 26 September 2026. A1–A7 represent component delivery, not product readiness. Goal: a developer installs Connect, completes a useful Kerrigan-powered task, reviews/exports the result and repeats it reliably. Local fixtures alone cannot close this programme.

## Ordered gates

1. **E1 Maintained integration route.** Inspect current public and accessible upstream SDK/wallet/Drone contracts; pin source revisions. Map discovery, invoice, signing, broadcast, inference, replay, reconciliation and refunds. Implement supported adapters and failure handling with actual local HTTP contract tests. Clearly distinguish code absent in Connect from upstream information unavailable to this build. Do not invent cryptography or require upstream to conform to our prototype. Complete only after the supported route is implemented and remaining live-only checks are enumerated.
2. **E2 Complete application workflow.** Choose one supported application and run a task through its real interface, Connect, review and export. Include restart/retry, rejected output and duplicate-intent behaviour. Record actual application/browser versions and evidence. A mock application or fixture output alone does not satisfy this gate; live model usefulness is a separate E5 gate.
3. **E3 Release quality.** Review concurrent writes, file boundaries, failure recovery and installation. Fix defects with regression tests. Diagnose runner allocation and obtain real CI execution without weakening checks or moving work onto an unverified self-hosted runner. Record unresolved platform tests precisely.
4. **E4 Practical onboarding.** Deliver tested install/start/diagnose/stop instructions for the chosen supported platforms, grounded in actual SDK and Drone operation. Fresh installation must reach a reviewed workflow; provider guidance must match maintained software, not inferred mining requirements.
5. **E5 Bounded live pilot.** Prepare the exact non-sensitive task, explicit budget, wallet custody, expected output quality, repeat-use and failure/reconciliation checks. After separate authority and prerequisites exist, demonstrate real execution, charging and safe replay. Measure actual opt-in use with evidence; manually supplied hashes are not independent verification. Complete only with real evidence or remain blocked/incomplete.

## Execution and stopping

Each run fetches current main, ADOPTION_STATE.json, this roadmap, AUTONOMOUS_RUNBOOK.md, applicable AGENTS.md, recent commits, branches, PRs and active claims. Claim bounded work with a maximum two-hour expiry. Preserve user work; non-force commits to this private staging repository are authorised. Verify remote tree/ref after saving. Prioritise E1, but advance independent E2–E4 work when E1 has a precise external dependency. Never duplicate completed or claimed work.

Keep implementation, local HTTP tests, real application/browser tests, CI, live GPU/payment tests and adoption outcomes separate. No real KRGN spending, payment-key custody, paid services, provider registration, public deployment/publication, permission changes, upstream merges or external outreach without separate explicit authority. GET-only discovery is permitted; synthetic POST contract tests stay on loopback.

Continue concrete work until all gates pass. If all remaining work needs external action, commit exact blockers, pause and report incomplete scope. Do not label the whole programme complete because local tests pass. Notify for useful milestones, consequential defects or precise owner blockers; avoid routine no-change updates.
