# Add Kerrigan Connect integration gateway and catalogue demo

Application builders currently need to implement Swarm-specific invoicing, payments and request recovery before they can connect an existing AI workflow. This companion project creates a reusable application boundary and a practical batch example.

The companion application adds a local compatible chat API, persistent SQLite jobs, idempotency, atomic budget reservations, simulated payment/refund accounting, crash recovery, a CSV catalogue workflow, a JS client and an importable n8n example. A live read-only probe checks the existing model catalogue and chain status.

It also adds a labelled catalogue evaluator, quality reports and a GET-only readiness assessment. An offline review workspace lets a person correct results, approve products and export approved rows. Checkpoint comparison reports show changes and approval transitions. Checkpoints preserve the source and latest decisions; approval resets on edits.

The default mode is an explicitly labelled simulation. Read-only mode cannot submit paid work. No mainnet signing backend, cryptographic compute verification or confirmed live-refund integration is included. Buffered SSE compatibility is implemented; native upstream streaming is deferred.

Validation includes accounting and failure tests, restart recovery, real local HTTP requests, catalogue replay without duplicate payments, n8n example request/response code, and a read-only live Coordinator/explorer probe. The v0.4 suite has 52 passing tests, including generated page logic in a DOM harness. Full Chromium and visual verification remain incomplete because the browser download failed in the build environment. See `docs/STATUS.md` for the tested revision's results.

The source remains separate from daemon consensus code. Before a paid pilot, agree the maintained Swarm contract, integrate a local wallet backend, reconcile interrupted payments and validate actual provider/refund behaviour. Licence and destination layout require maintainer review.
