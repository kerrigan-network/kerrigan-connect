# Operator console

The local operator console at `/operator` presents bounded read-only diagnostics from one Connect instance. It shows local gateway health, model discovery, failed or reconciliation-required jobs and local-ledger utilisation. A supplied version 1 diagnostic can be loaded for a Drone host; it is labelled supplied and is never promoted to independently verified evidence.

Use Node 24.14–24.x, set `KCONNECT_API_KEY`, run `npm start`, then open `http://127.0.0.1:8787/operator`. The key remains only in page memory and is cleared from the input. The console contains no registration, wallet, shell, service-control or retry actions.

## Compatibility boundary

Source review on 26 September 2026 used maintained public Core commit `7c4d3e5fa11525827f8152d168c6ca7a127e16bf` and SDK commit `ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29`. Core's `src/evo/inference_wire.h` defines the v1.3.0 `CDroneRegTx` special-transaction registration and explicitly records that the SDK registration builder and Coordinator scanner still use the replaced OP_RETURN form. The console therefore reports `known_mismatch` for registration.

The current maintained Drone runtime and installer source was not available through the authorised repository connection. Runtime version and install compatibility remain `unknown`; Core compatibility, a supplied GUI version and successful mining are not substituted for inference-service readiness. The committed supplied fixture intentionally contains unknown values.

## Evidence meanings

- `supplied_demo`: local deterministic Connect simulation, no GPU or KRGN.
- `live_get`: current GET response from the configured Coordinator, not a network census or successful inference.
- `supplied`: a local JSON diagnostic chosen by the operator, not independently verified.
- local utilisation: at most 200 local Connect jobs; cost is simulated in demo mode and unknown otherwise.
- problem jobs: at most 25 failed or reconciliation-required records with identifiers, status, model and bounded error code—never prompts, outputs or upstream error details.

Run `npm run test:operator` for focused security, failure, bounded disclosure and no-mutation checks. `npm test` includes the same tests. Native-browser visual evidence remains subject to the existing browser availability limitation.
