# Model, context and advertised-cost planner (A3)

Use this before connecting an application: give it a saved discovery snapshot and explicit workload estimates. It compares the requested context, advertised providers, optional required capabilities and optional compute-only ceiling. It writes JSON plus a readable Markdown report. It never sends a prompt, asks for an invoice, holds a payment key or spends KRGN.

## Run

```sh
# Optional fresh discovery: the existing probe issues GET requests only.
npm run probe -- --output output/probe.json
# Planning itself is offline, with no API key required.
npm run plan -- --input output/probe.json --workload examples/workload.json --output output/plan.json
```

Add `--model MODEL_ID` to restrict selection. Without `--output`, JSON goes to stdout. Exit 0 means at least one advertised candidate meets the requested checks; exit 2 means none can be confirmed; malformed input exits 1. Reports still write on exit 2, explaining why. A probe can report partial errors; inspect the saved snapshot. A model endpoint error is unknown, not an empty catalogue.

To examine the committed historical observation without new network access:

```sh
npm run plan -- --input fixtures/live-probe-2026-09-25.json --workload examples/workload.json --output output/historical-plan.json
```

This old observation should now return exit 2 and `stale`, not pretend to be current. Never edit an observation timestamp to make it pass. Reproducible deterministic tests use an injected clock; the CLI deliberately does not allow a freshness bypass.

## Workload contract

| Field | Meaning |
| --- | --- |
| `input_tokens` | Positive safe integer estimate for the entire request: instructions, context, retrieved content and conversation history, not just the newest message |
| `output_tokens` | Positive safe integer output ceiling to plan for; not a predicted answer length |
| `context_overhead_tokens` | Nonnegative safe integer allowance for templates/special tokens, default 0; added to context **and** estimated billed input |
| `jobs` | Positive safe integer number of identical-estimate requests, default 1; does not imply concurrent network capacity |
| `required_capabilities` | Optional unique list: chat, tools, embeddings, vision, structured_output, streaming, confidentiality; default empty means numerical/context screening only |
| `max_advertised_compute_sats` | Optional nonnegative integer or decimal string up to 30 digits, for the **whole batch at 100% output**; excludes unknown fees and is not a spending authorisation |

Unknown workload keys and unsupported capability names are errors. Numeric estimates must be safe integers; money in reports is always a decimal string. BigInt arithmetic preserves exact sums/products beyond JavaScript's safe-number range. Input/output files are separate; inputs are bounded to 2 MB and the catalogue to 1,000 unique model IDs. No prompt text is needed or stored by the planner.

## Reading the result

`advertised_fit` means a fresh, successful model observation has at least one listed provider, adequate context and all explicitly requested requirements advertised. It is **not** a tested job, a reservation, a model-quality recommendation, a guarantee of serving, or proof of whole-network capacity. A missing price can coexist with numerical/context fit if no price ceiling was requested; `price_status` stays unknown. A required but missing capability prevents confirmation. Legacy gateway compatibility flags are not provider advertisements. A confidentiality requirement always remains unknown: even an advertised boolean is not proof.

Snapshot freshness is five minutes. Future timestamps and invalid dates are unknown. Missing context/providers, failed model discovery and simulated models cannot confirm a live advertised fit. Known insufficient context, no advertised providers or exceeding a supplied compute ceiling are blocked. Stale snapshots can still show explicitly dated arithmetic, but never a confirmed candidate. Candidate ordering is by ID, not a claim that the cheapest model is best.

Three output scenarios use 25%, 50% and 100% of the supplied output ceiling (rounded up to a whole token). They are arithmetic illustrations, not probabilities or throughput measurements. Per-job compute is `(input + overhead) × advertised input rate + scenario output × advertised output rate`; batch compute multiplies by jobs. KRGN display uses 100,000,000 satoshis per KRGN. Cache discounts, actual tokenisation, invoice binding, fees and refunds are not modelled. **Fees and final invoice remain unknown**, separately from advertised compute.

Discovery now preserves absent input/output rates as `null`, rather than treating missing input pricing as zero. `rates_observed` distinguishes an explicit zero advertisement. Old snapshots containing zero without this provenance are unknown; refresh them. Existing positive historical rates remain estimates. `advertised_capabilities` contains only explicit boolean upstream values; existing `capabilities` remains Connect adapter policy and is ignored for planning.

## Evidence and limitations

The public [Kerrigan SDK network module](https://github.com/kerrigan-network/kerrigan-sdk/blob/master/webwallet/src/network.js), re-read on 25 September 2026, documents discovery rate/context fields and a separate provider invoice path which accounts for tokenisation and cache state. That separation is why this report never calls advertised arithmetic an invoice. Reading that source is not end-to-end validation. A direct web-reader GET of the coordinator failed during this run; no new live model count or price observation is claimed.

```sh
npm run test:planner
npm test
npm run quickstart
```

Tests cover context equality/excess, stale/future/invalid observations, missing/zero prices, unknown capability requirements, provider absence, synthetic inputs, large exact amounts, compute ceilings, malformed/oversized files and actual CLI JSON/Markdown outputs. They are local automated tests, not real-browser checks, third-party app validation, GitHub CI success or GPU usage. The programme's funded live pilot and private-to-public release remain separate dependencies.
