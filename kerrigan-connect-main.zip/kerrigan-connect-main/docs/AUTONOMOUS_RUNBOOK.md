# Hourly Kerrigan build runbook

## Current direction: application pieces, 26 September 2026 at 20:30 UK

Read `PRODUCT_BUILD_ROADMAP.md` and `PRODUCT_BUILD_STATE.json` first. The owner now authorises B1–B4 (Catalogue Studio, installable n8n integration, first-use experience, operator console), with joining-up and distribution discussed afterwards. Kerrigan inference is technically operational according to the owner; Connect's integration remains unverified. This product build order supersedes the E1-first order below for independent application work. Preserve the E1–E5 evidence gates for later integration. Use the same non-force source preservation, expiring claims, tests, no-spend boundaries and evidence discipline. Stop/pause according to the product roadmap; A1–A7 completion and a blocked E1 do not stop independent B1–B4 engineering.

## Current scope: reopened 26 September 2026

The owner authorised E1–E5 end-to-end delivery after component A1–A7 completion. Read END_TO_END_ROADMAP.md and INTEGRATION_ROUTE.md first. Component completion no longer closes the current programme. Stop successfully only when E1–E5 meet their evidence gates; otherwise pause with explicit incomplete blockers when independent work is exhausted.

The owner authorised autonomous implementation of the finite adoption roadmap in this private repository. The target is useful, reproducible tools for eventual Kerrigan adoption; repository activity is not evidence of real network usage.

1. Fetch current GitHub `main`, `docs/ADOPTION_STATE.json`, roadmap, latest changes and any applicable `AGENTS.md`. Repository files are canonical; local checkouts and old task context may be stale. Inspect existing branches/work before duplicating work.
2. Use a fresh local checkout or reconstruct the exact tree through the GitHub connector if CLI credentials are unavailable. Never extract browser credentials. The original v0.4 history is under `archive/`; current work must start from current main, not that archive.
3. If another unexpired run claim exists, skip. Before writing, record a short-lived claim (run ID, UTC start, target item, expiry at most two hours) in state through a non-force commit. Re-read the remote head before advancing refs. If the head moved, inspect and reconcile; never discard someone else's changes.
4. Choose the highest-priority actionable acceptance criterion. Make a concrete bounded implementation, useful documentation and tests for real failure modes. Use synthetic inputs and GET-only discovery unless separately authorised live work is recorded. Follow skill/tool instructions and task-specific permissions.
5. Run relevant tests plus `npm test` for shared runtime changes. Record commands, environment and outcomes accurately. Check workflow runs, but do not claim CI passed when no steps ran. The initial import workflow failed before runner allocation; the cause was unavailable through current tools.
6. Commit source, progress, evidence and blockers to GitHub. Verify the remote tree hashes and current branch ref. Clear the claim at completion. Keep completed and blocked distinct; do not mark UI visual verification or third-party app import complete without executing it.
7. Notify the owner for a completed useful milestone, important defect or a new owner-only blocker. Keep routine no-change runs quiet. Do not contact maintainers, send outreach, spend money, enable payment keys, change permissions, publish publicly or merge into the Kerrigan organisation based on this build schedule.
8. After E1–E5 meet their documented evidence gates, write the final end-to-end handoff and disable this automation using its state ID. A1–A7 component completion is insufficient. If all remaining tasks need outside action, record evidence, pause and explain the incomplete scope once. Do not invent extra projects to keep running.

## Current commands

```sh
npm test
npm run test:integration
npm run test:planner
npm run test:task-packs
npm run test:gpu-preflight
npm run gpu-preflight -- --input examples/gpu-inventory.json --models examples/gpu-model-snapshot.json --output output/gpu-preflight.json
npm run test:tracker
npm run snapshot -- --input fixtures/live-probe-2026-09-25.json --output output/capability-snapshot.json
npm run snapshot-diff -- --baseline previous.json --input current.json --output output/capability-diff.json
npm run test:adoption
npm run adoption:record -- --input examples/adoption-event.json --output data/pilot-events.jsonl
npm run adoption:report -- --input data/pilot-events.jsonl --output output/adoption-summary.json
npm run quickstart
npm run demo
npm run benchmark -- --min-accuracy 0.8
npm run review-demo
```

`npm run doctor` performs live GET-only discovery and may legitimately report unavailable or stale upstream evidence. It never enables payments. A2 requires Python 3.10+ (`python3`) and curl 8.5+ for its integration test, included in `npm test`; see `APP_INTEGRATION.md`. Tested locally with Python 3.12.14 and curl 8.5.0.

`npm run gpu-preflight` is local and non-registering. The opt-in `--local` mode runs only the documented bounded `nvidia-smi` query; supplied inventories are appropriate for other vendors. A successful diagnostic is not provider readiness. See `GPU_PREFLIGHT.md`.

`npm run snapshot` writes JSON, Markdown and self-contained HTML. Without `--input` it performs the same bounded GET-only discovery as the probe, with one to three attempts; with `--input` it is fully offline. Exit 2 preserves unknown/stale/empty/zero evidence. `snapshot-diff` suppresses removals unless observations are safely comparable. See `CAPABILITY_TRACKER.md`.

The A7 adoption commands are explicit local file operations, not telemetry. Events reject extra prompt/device/personal fields, replay deterministically and preserve simulation/live separation. Aggregates omit source identifiers and do not claim users or conversion lift. See `PILOT_MEASUREMENT.md` and `PROGRAMME_HANDOFF.md`.
