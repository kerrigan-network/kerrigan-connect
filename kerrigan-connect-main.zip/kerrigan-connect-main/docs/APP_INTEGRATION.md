# App integration kit (A2)

This kit connects applications to the **Connect local gateway**. It complements Kerrigan's public wallet SDK; it does not sign invoices, custody keys or enable live inference. Current gateway jobs and payments are deterministic simulations. The SQLite ledger stores prompts and results locally without application encryption.

## Run from a clean checkout

Requirements: Node 24.14–24.x (tested 24.19.0), Python 3.10+ standard library (tested 3.12.14), and curl 8.5+ for the shell example (tested 8.5.0). No pip packages or runtime npm dependencies are required. Commands run at repository root.

```sh
npm ci --ignore-scripts --no-audit --no-fund
# Set a local gateway credential in this shell; retain it in your second shell.
export KCONNECT_API_KEY="$(node -e 'console.log(require("node:crypto").randomBytes(24).toString("hex"))')"
npm start
```

In a second shell, set the **same** `KCONNECT_API_KEY` through your environment, then:

```sh
export KCONNECT_URL=http://127.0.0.1:8787
export KCONNECT_INTENT_KEY=my-first-integration-001
node examples/integration/job.mjs
python3 examples/integration/job.py
sh examples/integration/chat.sh
```

All three examples use the same request and key, so they replay one intent in the same gateway ledger. Use a new **persisted caller key only for genuinely new work**. If a timeout loses the response, submit the exact request with the original key. A changed request with the same key is a 409 conflict. There is no automatic retry or new-key generation. Polling uses GET only; deadline expiry does not cancel an accepted job. Keep the ledger to retain replay protection across restarts.

Examples read credentials only from environment variables. Do not enable shell tracing or commit environment files. Curl receives credentials through stdin configuration rather than command arguments; its example is intentionally restricted to loopback and the demo model. JS/Python accept `KCONNECT_MODEL`; select an advertised model explicitly for other installations. Output contains local job content, so handle it as your application data.

## Client API

JS: import `ConnectClient` from `src/client.js`; construct with `{baseUrl, apiKey, timeoutMs: 15000, maxResponseBytes: 2000000}`. Call `models()`, `submit(request, intentKey)`, `job(jobId)`, `wait(jobId, {timeoutMs: 180000, intervalMs: 100})`.

Python: add `integrations/python` to your module path and import `ConnectClient, ConnectError` from `kerrigan_connect`. Construct with `api_key=...`, optional `base_url`, `timeout=15` (seconds), `max_response_bytes=2000000`. Call `models()`, `submit(request, intent_key)`, `job(job_id)`, `wait(job_id, timeout=180, interval=.1)`.

Both clients bound response bytes and elapsed request time, reject insecure remote HTTP, and refuse redirects. They require intent keys of 8–160 letters, digits, dots, underscores, colons or hyphens before submitting. They return terminal failed/cancelled/reconciliation jobs as data; applications must inspect `status`. Errors expose `code`, `status`, and optionally `jobId` (JS) / `job_id` (Python). Remote error messages are not copied into exceptions. A timeout/transport failure leaves acceptance uncertain; preserve the key.

Python uses at most eight concurrent daemon network workers to bound caller wall time even if DNS or headers stall. A timed-out resolver/socket may finish later; workers check expiry before sending after connection, and never retry. Saturation fails as `client_busy`. Already sent requests may finish at the gateway. Direct connections use system TLS verification and do not inherit HTTP proxy environment variables. JS uses Node fetch. Injected JS fetch implementations must honour AbortSignal and return standard streaming Responses.

## Exact compatibility boundary

| Surface | Supported subset / limit |
| --- | --- |
| `GET /v1/models` | Authenticated model list; advertising a model is not proof of availability |
| `POST /connect/jobs` | Asynchronous job, mandatory intent key, 202 new / 200 replay |
| `GET /connect/jobs/{id}` | Job status/result; terminal completed, failed, cancelled, needs_reconciliation |
| `POST /v1/chat/completions` | Text chat response; curl uses this route; clients above use durable jobs |
| Messages | 1–64 messages, roles system/user/assistant, string content, at least one user; ≤100,000 UTF-8 bytes of serialised messages |
| Request fields | `model`, `messages`, `max_tokens` **or** `max_completion_tokens` (1–16384), `temperature` (0–2), `top_p` (>0–1), `seed` (nonnegative safe integer), boolean `stream`, optional integer `budget_sats` |
| Defaults | Output limit 512, temperature 0.7, top_p 0.9, seed 42; simulation does not demonstrate model sampling fidelity |
| Streaming | Gateway chat route offers **buffered** SSE after completion; Python/JS job clients do not parse SSE. Job `stream` does not create a token stream |
| Unknown parameters | Explicit `unsupported_parameter` error; no silent tools/JSON-mode emulation |
| Unsupported | Tools/function calls, multimodal messages, embeddings, Responses API, `response_format`, native token streaming, cancellation through these clients |
| Request/response bounds | Gateway request body ≤200,000 bytes; clients default to 2,000,000 response bytes, configurable in JS/Python. An oversized response fails without retrying |
| Remote deployment | Clients require HTTPS remotely; current gateway enforces loopback Host. Reverse proxy/public hosting is outside this delivery |

Generic chat callers may omit a key at the server boundary, but then cannot safely replay a lost response. All examples in this kit supply one. Chat and job requests share the gateway's existing normalisation and ledger; unknown features stay errors.

## Reproduce verification

```sh
npm run test:integration
npm test
npm run quickstart
```

The integration command launches real disposable loopback gateways and a fault server, then launches Python and the actual JS/Python/curl example processes. It covers success, same-key replay, changed-body conflict, bad auth, unsupported fields, deadline expiry, a delayed POST response followed by recovery with the same key, response bounds, malformed JSON and refused redirects. Payments are simulated; assertions verify no duplicate simulated payment on replay. Slow-body and total polling deadlines are tested too. No external network is needed.

See `fixtures/integration-v0.6.0.json` for the recorded local environment and commands. `npm test` requires `python3` and `curl` now; missing tools are failures, never silently skipped. Actual browser verification, n8n import, Open WebUI and LangChain remain **unverified**. The n8n request/parser contract has local tests, which do not establish application compatibility. GitHub CI is a separate result, not inferred from these local checks.
