# E5 bounded live pilot proposal

Status: **prepared, not authorised and not executed**. This document is the reviewable plan required before any live KRGN spend, payment-key custody, provider registration or paid service use. Nothing in this plan enables live mode.

## Purpose and exact task

Use the existing catalogue workflow on a deliberately non-sensitive three-row batch of ordinary product descriptions. The operator submits the batch through Connect, reviews every result in the offline review workspace, rejects or corrects unsupported output, exports only approved rows, then repeats the same batch under the same stable intent to verify replay safety. No customer data, secrets, personal data or proprietary documents are permitted.

Success is not "the request returned 200". The pilot must independently evidence: a maintained-SDK payment transaction, actual model output, the charged amount and fee, review/export, safe same-intent replay without a second charge, restart recovery, and an opt-in return workflow recorded separately from the first workflow.

## Proposed hard budget

These are proposed ceilings, not spending authority:

- Total pilot ceiling: **50,000 KRGN smallest units (sats)**.
- Maximum provider amount per new paid intent: **20,000 sats**.
- Maximum network fee per transaction: **2,000 sats**.
- Maximum newly paid inference intents: **2**. The replay check must reuse an existing paid intent and must not create a third payment.
- Stop immediately if the invoice plus maximum fee can exceed the remaining pilot ceiling, if the denomination cannot be confirmed from maintained software, or if any retry would require a new payment whose prior state is unresolved.

Before execution, the owner must explicitly approve the final numeric ceilings after current maintained wallet/Drone denomination and fee semantics are confirmed. Connect must enforce the approved ceilings in code/config; an operator promise is not a control.

## Wallet custody

Use a dedicated limited-balance pilot wallet controlled by the owner. Seed/private-key material stays inside the maintained wallet/SDK signing boundary and is never placed in Connect configuration, HTTP requests, GitHub, test fixtures, logs or adoption records. Connect may receive only the minimum non-secret signing result and transaction evidence required by the maintained adapter.

The signing session must be explicit and one-shot. No background process may retain authority to create a different payment after an ambiguous failure.

## Preconditions

Do not start live execution until all of these are true:

1. E1 has a reproducible compiled maintained SDK/WASM path and current supported Drone/coordinator contract confirmation.
2. A live GET reader can independently observe the relevant transaction/lifecycle evidence.
3. Transaction/refund semantic verification is implemented; supplied transaction IDs or receipt hashes alone are insufficient.
4. E2 has completed the chosen catalogue task through the real application/browser review/export interface, including rejected output and duplicate intent.
5. E3 has real GitHub CI execution and the release/recovery/concurrency checks required by the roadmap.
6. E4 fresh-install onboarding reaches the reviewed workflow on a supported platform.
7. The owner separately authorises the exact spend ceiling and owner-controlled wallet session.

If any precondition fails, the pilot remains blocked; do not enable live spending to make a test pass.

## Execution evidence

For each newly paid intent retain a redacted, non-sensitive evidence bundle containing:

- Connect run/intent ID and request fingerprint; never the seed or private key.
- Pinned maintained SDK revision and Connect commit.
- Model/provider identifiers and invoice binding needed for verification.
- Raw-transaction hash/txid derived from the maintained SDK result plus the independently observed transaction/lifecycle state.
- Provider amount, network fee and total charged amount as independently reconciled.
- Inference outcome classification and a hash of a redacted receipt; do not store sensitive prompt/output content in adoption records.
- Review checkpoint fingerprint and approved export fingerprint.
- Whether the request was a new paid intent, exact replay, restart recovery or rejected output.

Repository fixtures and manually supplied hashes remain labelled synthetic/supplied and cannot substitute for this bundle.

## Safe retry and recovery checks

Run the following bounded checks without creating duplicate spend:

1. **Exact replay:** repeat the same stable intent after success. Verify the same payment/result path is reused and independently confirm no second charge.
2. **Restart after prepared/signing boundary:** stop Connect after durable preparation at a testable boundary, restart, reconcile first and continue only when state is known.
3. **Lost broadcast acknowledgement:** if broadcast acknowledgement is unavailable, lookup the prepared txid before any rebroadcast. Rebroadcast only the same raw transaction when the maintained route says that is safe.
4. **Inference transport failure:** retry inference with the original payment transaction reference and unchanged bound request. Never generate a replacement payment automatically.
5. **Rejected output:** reject one result in review and prove it is absent from approved export.
6. **Refund/unused-token evidence:** when the maintained service genuinely emits a refund/credit for this pilot, verify destination, amount and relation to the original payment independently. Do not manufacture extra paid work solely to force a refund.

Any unknown payment state stops the paid path until reconciled.

## Output-quality gate

For the three catalogue rows, the reviewer must inspect category and extracted attributes against the source description. A row is useful only when the reviewer can approve it without inventing unsupported evidence. Record approved/rejected/corrected counts and the exported rows. Do not convert this three-row pilot into a general accuracy claim.

## Opt-in repeat-use evidence

Use the existing local adoption recorder only after the underlying evidence exists. For each consenting pilot journey, record a first useful workflow only after review/export. Record a return workflow only when the same locally assigned journey performs a later, distinct reviewed workflow. A live receipt hash by itself does not prove live execution; the independent pilot evidence bundle above is authoritative.

Minimum evidence to close E5:

- at least one independently verified live paid request with reviewed/exported useful output;
- safe exact replay with no duplicate charge;
- one exercised restart/recovery path with reconciled payment state;
- actual charged amount/fee recorded within the approved ceiling;
- at least one genuine opt-in return workflow after a first useful workflow;
- no unresolved payment/refund ambiguity.

The roadmap may require more evidence if maintained software or real execution exposes additional failure modes.

## Authority request template

When E1-E4 prerequisites are satisfied, request one narrow approval: permission to use the owner-controlled dedicated pilot wallet for the exact task above, with the final confirmed total/job/fee ceilings, on the pinned maintained SDK/Drone route. The request must identify the Connect commit, SDK revision, current model/provider, expected maximum number of new payments, stop conditions and evidence locations.

Until that approval is explicit, E5 status is **blocked / not executed** and live spending remains disabled.
