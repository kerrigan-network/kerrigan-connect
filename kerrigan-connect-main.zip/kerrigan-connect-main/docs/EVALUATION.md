# Catalogue evaluation and readiness

## Run the offline benchmark

```
npm run benchmark
npm run benchmark -- --min-accuracy 0.9
```

The default command runs the **local deterministic simulation** on 16 synthetic,
author-labelled cases. It writes `output/benchmark.json`, a companion `.html`
report for review in a browser, and a `.csv` of validated results. No network or
API key is required. No real GPU or KRGN is used. A checked-in example is at
`fixtures/benchmark-demo-v0.2.json.html`.

The second command intentionally exits 2: the current rules achieve 13/16
category matches, below the example 90% threshold. This threshold is a CLI
example, not a validated business acceptance criterion. Do not tune the demo
rules to this tiny set and report the result as commercial model performance.

## What the scores mean

- Schema acceptance checks output structure and literal attribute evidence.
- Category accuracy compares the category to the authored label.
- Exact match requires the category and all three attributes to match.
- Attribute accuracy includes null labels; populated-attribute accuracy
  separately measures extraction where an attribute is present in the label.
- Per-category recall and the confusion matrix show where mistakes occur.
- All labelled cases remain in denominators, including failed and missing jobs.
  Duplicate and foreign result IDs are rejected.
- Known costs include the original cost of replayed jobs. They are **not** the
  incremental amount spent by this run. Unknown costs are counted separately.
- Execution labels derive from backend receipts and are not compute proofs.

Attribute matching ignores case and repeated whitespace; it does not perform
unit conversion or semantic synonym matching. Flags are not scored. The set
includes keyword collisions, negation, missing detail and an instruction inside
a description. It is neither representative customer data nor a security audit.
Labels should be independently reviewed before making an acceptance decision.

## Point the same workflow at the gateway

Start the demo server using README instructions, then:

```
node src/cli.js benchmark --url http://127.0.0.1:8787 \
  --model demo/catalogue-v1 --output output/gateway-benchmark.json
```

This exercises durable jobs and the HTTP boundary. The default run ID is derived
from the dataset and model. Repeating the same run against the same ledger reuses
jobs; a new `--run-id` creates a new evaluation. For a custom set use `--input`
with the JSON schema demonstrated in `examples/catalogue-benchmark.json`.
Only descriptions, IDs and the taxonomy are sent for inference; answer labels
stay in the evaluator. Reports contain the descriptions and should be kept
local for private catalogues. HTML text is escaped and external resources and
scripts are blocked by its content policy.

A real model requires an explicit `--url` and `--model`. The current gateway
still rejects paid live inference. This option prepares the evaluator for the
wallet milestone; it does not bypass that restriction.

## Readiness without spending

```
npm run doctor
node src/cli.js doctor --model Llama-3.2-3B-Instruct_IQ4_XS
node src/cli.js doctor --input fixtures/live-probe-2026-09-25.json
```

The default doctor makes the same three GET requests as `probe`; it sends no
prompts, invoices or payments. An input file is a **snapshot**, not a new network
observation. Timestamps older than five minutes, invalid timestamps and timestamps
more than one minute in the future are not considered fresh.

Exit 0 means discovery checks passed, **not** that live inference is ready.
Exit 1 means discovery is blocked or unknown. Signing/reconciliation and the
paid pilot remain explicit blockers even when every endpoint is healthy.
Inactive Drone block rewards are reported separately from inference payment
readiness. Neither advertised rates nor a model listing is a binding quote.

Benchmark exits: 0 = processing completed and any configured gate passed;
2 = review-required output or failed accuracy gate; 1 = configuration/runtime
failure. An omitted quality gate makes no accuracy acceptance claim.
