# Kerrigan application build handoff

Status: **paused incomplete for external validation**, 26 September 2026.

The four authorised application pieces now have reviewable local implementations. This is not a claim that Connect's live route is complete, and it does not contradict the owner's confirmation that Kerrigan's inference network is technically operational but not yet marketed.

| Piece | Implemented and locally tested | Still unverified |
| --- | --- | --- |
| B1 Catalogue Studio | CSV validation, taxonomy/model selection, stable batch/restart recovery, progress, honest cost states, source review, checkpoint recovery and approved-only export | Native Chromium download/CSP/responsive flow |
| B2 n8n integration | Private installable package, credentials, discovery, submit/status/result/recovery, stable caller intent, bounded errors; installed and executed twice in n8n 2.40.7 | Registry/community-manager installation, because publication is not authorised |
| B3 First-use | Loopback guided status, demo/live/unavailable labels and ready handoff into Studio; clean-package HTTP path | Native Chromium status and Studio navigation |
| B4 Operator console | Authenticated read-only local/supplied health, model, failed-job and utilisation diagnostics; Core/SDK source provenance and registration mismatch; mining/inference separation | Current maintained Drone runtime/installer compatibility and native Chromium application flow |

Local verification on Node 24.19.0/Linux: 162 repository tests passed, including five B4 tests and the fresh-tarball installation workflow. B2 additionally ran in an isolated n8n 2.40.7 profile with one simulated payment across two stable-intent executions.

## Exact external blockers

1. Native application evidence needs a Chromium-capable environment without the current administrator loopback block.
2. B4 runtime/install compatibility needs the current maintained Drone runtime/installer source or an authoritative compatibility profile. Public Core `7c4d3e5` explicitly records that SDK `ae6ca83` and the Coordinator registration scanner still use the replaced OP_RETURN form, so the console correctly reports a known registration mismatch rather than compatibility.
3. GitHub Actions continues to fail before allocating a runner or executing a step; local tests are not CI evidence.
4. Public/registry installation, website integration, live inference/payment activation, distribution and outreach remain outside this build authority.

No real KRGN was spent. No payment key, wallet, provider registration, service mutation, public deployment, publication or outreach was performed. E1–E5 remain incomplete for the later integration/validation discussion.
