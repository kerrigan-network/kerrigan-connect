# Local pilot evidence and adoption measurement

This opt-in kit records a deliberately small adoption funnel without telemetry. Nothing is instrumented automatically: an operator must create an event file and run the local command. The command performs no HTTP request and the aggregate omits event IDs, journey IDs and evidence references.

## Record an event

Start from `examples/adoption-event.json`. Give each event a caller-issued stable `event_id`, a locally assigned non-identifying `journey_id`, an ISO timestamp and a SHA-256 reference to a non-sensitive receipt or review checkpoint.

```sh
npm run adoption:record -- \
  --input examples/adoption-event.json \
  --output data/pilot-events.jsonl
```

Exact replay is a no-op. Reusing an event ID with different content fails as a conflict. The normalised JSONL log is sorted by time and event ID, capped at 50,000 events/20 MB, and remains on the local machine unless the operator deliberately moves it.

The accepted stages are:

| Stage | Evidence kind | Meaning |
| --- | --- | --- |
| `first_run_pass` | `quickstart_receipt` | A bounded first-run check passed |
| `first_useful_workflow` | `reviewed_workflow` or `local_workflow_receipt` | The operator judged one workflow useful |
| `return_workflow` | `return_workflow_receipt` | The same locally assigned journey later returned |
| `verified_live_request` | `live_receipt_hash` | A live event was supplied with a receipt hash |

Activity must be separately labelled `simulated`, `local_only` or `live`. A `verified_live_request` rejects anything except `live`. Even then, this tool only validates the event shape and counts the supplied receipt hash; it does not independently validate inference, an invoice, payment, chain transaction or confidentiality.

Do not hash or store prompts, outputs, customer documents or secrets as evidence. Hash a redacted non-sensitive receipt/checkpoint instead. The strict schema rejects all extra fields, including prompt, device, network, wallet and personal fields. A journey ID should be a random pilot-local label, never an email address, username, wallet address or device fingerprint.

## Generate an aggregate

```sh
npm run adoption:report -- \
  --input data/pilot-events.jsonl \
  --output output/adoption-summary.json
```

The command writes JSON, Markdown and self-contained HTML. It counts unique events and journeys by stage and activity, identifies sequence gaps, and records exact duplicates. It never emits source identifiers. The source fingerprint makes the report reproducible without exposing the log.

Counts are evidence about supplied opt-in local records. They are not unique people, conversion rates, conversion lift, market adoption or network usage. A test fixture with two synthetic journeys is included under `fixtures/adoption-v0.11.0/`; its zero live events are intentional and must not be presented as a pilot result.

## Operational choices

The repository does not transmit telemetry, schedule collection, host a dashboard or set retention policy. A pilot owner must separately decide who may opt in, where the local log is held, its deletion period and whether an aggregate can be shared. Deleting the JSONL file and generated reports removes this tool's copies, subject to filesystem backups and recovery systems.

## Tests

```sh
npm run test:adoption
npm test
```

Tests cover strict privacy fields, live/simulation separation, deterministic deduplication, conflict detection, sequence gaps, identifier-free aggregation and actual CLI JSON/Markdown/HTML output. They are local automated tests, not measured adoption, live inference or third-party validation.
