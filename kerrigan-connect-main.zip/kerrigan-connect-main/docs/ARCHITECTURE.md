# Architecture

Kerrigan Connect is an application-side companion to the existing Coordinator and wallet SDK. It does not implement consensus, run a mining pool, replace a Drone, register providers, hold a treasury wallet or change block rewards.

## Modules

| Module | Responsibility |
| --- | --- |
| `server.js` | Local authenticated HTTP API; chat response translation and buffered SSE |
| `gateway.js` | One persistent job queue; quote/payment/inference boundaries |
| `ledger.js` | SQLite transactions, reservations, accounting, recovery and event history |
| `coordinator.js` | Observed `/v1/models`, `/v1/invoice`, `/v1/chat` contracts and read-only probe |
| `demo.js` | Deterministic provider and simulated payment/refund backend |
| `catalogue.js` | CSV import/export, request construction and output validation |
| `client.js` | Small JS client for submitting and polling durable jobs |
| `lock.js` | Exclusive worker ownership per local data directory |

## Job lifecycle

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> quoted: Reserve invoice and fee ceiling
    queued --> cancelled: Cancel before payment
    queued --> failed: Quote or budget rejected
    quoted --> payment_pending: Persist payment intent
    payment_pending --> paid: Record transaction and actual fee
    payment_pending --> needs_reconciliation: Unknown outcome
    paid --> running: Submit using stored transaction
    running --> completed: Retain response
    running --> needs_reconciliation: Execution outcome uncertain
    needs_reconciliation --> paid: Explicit retry with known transaction
```

A durable intent must precede any future wallet call. A wallet failure is considered ambiguous unless chain/wallet reconciliation proves otherwise. This version provides no API that simply clears a pending payment reservation, fabricates a receipt, or starts a second payment for the job.

## Startup recovery

| Persisted state | Action |
| --- | --- |
| `queued` | Obtain a quote when the worker reaches it |
| `quoted` | Release the old reservation and obtain a fresh quote |
| `payment_pending` | Hold the reservation; mark `needs_reconciliation` |
| `paid` | Submit inference with the original transaction ID |
| `running` | Return to `paid`; same transaction ID on retry |
| Terminal states | Retain state and accounting; never automatically pay again |

The single-worker lock and `BEGIN IMMEDIATE` reservations prevent local workers from authorising overlapping budget allocations. Database operations use WAL and `synchronous=FULL`. The lock is intended for one machine, not a network filesystem or distributed deployment. After an unclean process exit, inspect the PID in `data/gateway.lock` and confirm no worker is running before removing that lock. Automatic stale-lock deletion is deliberately avoided because concurrent recovery can otherwise race.

## Budget policy

Every amount is an integer in KRGN satoshis. An invoice reserves its full amount plus the configured maximum network fee. The lower of the operator job ceiling and caller `budget_sats` is enforced.

Daily committed funds = all outstanding reservations + today's gross recorded payments and network fees. Refunds do not replenish the daily allowance. Outstanding reservations carry across UTC midnight. The payment receipt replaces the fee ceiling with the actual fee.

This is application accounting, not custody protection. The future wallet must independently enforce invoice bindings and fee limits. A wallet with unrestricted keys could otherwise bypass these policies.

## Idempotency

Canonical normalised request data is hashed. A repeated key with the same request returns the existing job; a different request returns 409. Rendering choices such as `stream` do not create different jobs. API callers should supply keys before their first request; server-generated keys cannot protect a retry when the first response is lost.

The catalogue CLI derives a key from the run ID and product ID. Its default run ID is derived from input, model and taxonomy. Explicit run IDs allow stable resume and deliberately reject changed product input under that identity.

## Verification boundaries

Transport success, response receipt, correct computation and prompt confidentiality are separate properties. A returned commitment is retained as unverified evidence. `verification` remains `not_performed`; output validation only checks JSON shape and literal evidence for extracted attributes.

The demo is not a benchmark. A future benchmark must evaluate labelled data against real models and include retries, refunds, fees, latency and human corrections.
