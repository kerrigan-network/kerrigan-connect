# Kerrigan Connect

## Start here

Run `npm run quickstart` for a disposable, authenticated local HTTP check with restart and retry verification. It takes no wallet configuration and spends no KRGN. See [First useful result](docs/QUICKSTART.md) and the [ranked adoption roadmap](docs/ADOPTION_ROADMAP.md).

A standalone integration gateway and catalogue-processing workflow for Kerrigan Swarm.

**Milestone 0.1: working local demo, durable accounting and live read-only discovery.**
Real wallet signing, paid mainnet inference, cryptographic compute verification and chain-confirmed refunds are **not enabled**. Demo inference is deterministic rules, not a GPU model. Every demo response includes `x_kerrigan.simulated: true`.

Built independently while Kerrigan repository access is pending. No affiliation, production readiness or upstream approval is implied. The code is kept separate from the daemon and consensus rules.

## Run in one minute

Requires **Node.js 24.14 or later in the 24.x line**. No npm dependencies, API subscriptions, GPU or wallet are needed for the demonstration.

```bash
npm run demo
npm test
```

The demo classifies the six public example products, validates extracted attributes against the descriptions, and exercises simulated quotes, payment records and refunds. It is not evidence of real model accuracy or real compute pricing.

To start the HTTP gateway:

```bash
export KCONNECT_API_KEY="$(node -e 'process.stdout.write(require("node:crypto").randomBytes(32).toString("hex"))')"
npm start
```

The gateway binds to `127.0.0.1:8787` and defaults to demo mode. Keep that terminal running. Open `http://127.0.0.1:8787/start` for the guided status check and handoff, or use the same API key in Studio or another terminal. See [First-use guide](docs/FIRST_USE.md).

For the new local **Catalogue Studio**, open `http://127.0.0.1:8787/studio` and enter that API key. Import a CSV or choose the six-product sample, save a batch checkpoint, process, review and export approved rows. Demo processing and costs are simulated. See [Catalogue Studio](docs/CATALOGUE_STUDIO.md) for restart recovery and current validation limits. The command-line route is:

```bash
curl http://127.0.0.1:8787/v1/models \
  -H "Authorization: Bearer $KCONNECT_API_KEY"

curl http://127.0.0.1:8787/v1/chat/completions \
  -H "Authorization: Bearer $KCONNECT_API_KEY" \
  -H 'Content-Type: application/json' \
  -H 'Idempotency-Key: first-demo-request-0001' \
  --data-binary @examples/chat.json

node src/cli.js catalogue \
  --input examples/catalogue.csv \
  --output output/catalogue-results.csv \
  --run-id catalogue-demo-001
```

Rerun with the same run ID and unchanged input to retrieve the same jobs. Changing an existing product's request under that run ID produces an idempotency conflict instead of another payment. Start a new run ID only when you intend new work.

The CSV is saved after every row. The accompanying `.report.json` records accepted rows, rows needing review and simulated costs. `accepted` means schema and literal attribute-evidence checks passed; classification accuracy still needs a labelled benchmark.

## Inspect Kerrigan's live network

```bash
npm run probe
```

This makes **GET requests only** to the Coordinator's model catalogue, connected-Drone count and the chain explorer. It sends no prompts, requests no invoices and spends nothing. Failures are reported as unknown, never as zero capacity.

To expose live model discovery through the gateway, use a different data directory:

```bash
KCONNECT_MODE=read-only KCONNECT_DATA_DIR=./data-readonly npm start
```

`/v1/models` now lists observed live models. Submission endpoints return `live_spending_disabled`. The configured Coordinator is only one view of the network.

On networks requiring an HTTP proxy, use Node's environment-proxy support:

```bash
NODE_USE_ENV_PROXY=1 npm run probe
```

## What works

| Capability | Status |
| --- | --- |
| `/v1/models`, `/v1/chat/completions` | Working compatible subset; chat runs in demo mode |
| SSE response format | Working **buffered** SSE; not upstream token streaming |
| Durable jobs and idempotency | SQLite; persisted before payment and inference |
| Per-job and daily budget limits | Integer satoshis; include maximum network fees |
| Refund accounting | Simulated receipts; gross daily allowance is not restored |
| Restart recovery | Retries recorded payments; holds ambiguous payments for reconciliation |
| CSV catalogue CLI and JS client | Working against the HTTP gateway |
| n8n workflow | Importable example; its code/request shape is tested, not a full n8n deployment |
| Live model/chain probe | Read-only; no funding required |
| Mainnet payment backend | Not implemented or enabled |
| Compute verification / confidentiality proof | Not implemented |
| Multiple tenants / public hosting | Not supported; one operator and loopback binding |

## Connect existing tools

- **Open WebUI:** use `http://127.0.0.1:8787/v1` as the compatible endpoint and your gateway API key. Choose `demo/catalogue-v1`. The UI server must run on the same host/network namespace; an isolated Docker container cannot reach the host's loopback. This milestone does not expose the gateway remotely.
- **n8n:** import [the workflow](integrations/n8n/catalogue-demo.json), then follow [the integration guide](integrations/n8n/README.md). It targets a local n8n installation.
- **JavaScript:** import `ConnectClient` from `src/client.js` and use `submit(request, key)` followed by `wait(job.id)`.

Unsupported features fail explicitly: tools/function calling, embeddings, images, audio, model-native structured output and non-text messages. Do not treat compatibility as support for every OpenAI API option.

## Accounting and retention

100,000,000 KRGN satoshis = 1 KRGN. Budgets are local spending policies, not protocol-enforced wallet restrictions. Only the allowlisted budget settings are returned by the status endpoint; API credentials are never included.

Daily budgets use **UTC**, include current outstanding reservations from all dates, and count gross payments plus fees made today. Confirmed refunds reduce net cost but do not refill the daily allowance. The maximum network-fee reservation is released when the actual receipt is recorded.

Requests and outputs are retained in the local SQLite database so jobs can resume. The application does not encrypt this database. API access uses a single operator token, which grants access to all local jobs. Console logs do not include prompts or keys. See [privacy and limits](docs/PRIVACY.md).

With the server stopped:

```bash
node src/cli.js purge --days 7
```

This removes input/output fields from older terminal jobs while retaining accounting, idempotency tombstones and unresolved jobs. It is logical deletion, not secure erasure of database pages, WAL files or backups.

## Repository map

```text
src/                  Gateway, ledger, Coordinator adapter, CLI and JS client
test/                 Failure, accounting, recovery, API and catalogue tests
examples/             Public sample data and requests
integrations/n8n/     Importable workflow and setup notes
docs/                 Architecture, API, upstream contract and merge plan
```

- [Architecture](docs/ARCHITECTURE.md)
- [HTTP API](docs/API.md)
- [Observed upstream contract](docs/UPSTREAM_CONTRACT.md)
- [Wallet integration boundary](docs/WALLET_INTERFACE.md)
- [Merge plan](docs/MERGE_PLAN.md)
- [Milestone status](docs/STATUS.md)

## Development and licensing

```bash
npm ci --ignore-scripts
npm test
```

The lockfile contains no external packages. Native `node:sqlite` is still experimental in some Node 24 releases; pin the tested runtime during the pilot and review the storage choice before production rollout.

The repository is private/unlicensed pending the owner's and Kerrigan maintainers' licence decision. No package publication, GitHub write, mainnet payment or deployment has been performed by this project.

## Labelled evaluation and readiness (v0.2)

Run `npm run benchmark` to generate local JSON, CSV and HTML reports from 16
synthetic labelled cases. The offline rules score 13/16 for category and 12/16
for all fields; these are not Kerrigan model results.

Run `npm run doctor` for GET-only discovery checks and explicit integration
blockers. A healthy discovery result never enables real payments.
See [evaluation instructions](docs/EVALUATION.md) for quality gates, custom data,
gateway replay and exit codes.

## Offline review workspace (v0.3)

Open `examples/catalogue-demo.review.html` directly in your browser to review
six simulated results. Correct fields, approve or reject products, save a JSON
checkpoint, and download only approved rows as CSV. No account or server is
needed for this included demo.

Use `npm run review-demo` to regenerate it. Catalogue and benchmark commands
also produce review workspaces for their output. Editing approved fields
resets approval; restore accepts decisions for the exact same source batch.
See [review instructions and boundaries](docs/REVIEW.md).

## Review comparison and temporary GitHub home (v0.4)

`review-diff` compares two saved review checkpoints and produces JSON and
Markdown change reports. See [review instructions](docs/REVIEW.md).

The intended temporary home is a private `BoltBlew/kerrigan-connect` repository.
It has not been created yet. [Publishing instructions](docs/BOLTBLEW_SETUP.md)
include restoring the Git bundle and a script that creates the private repo
from an authenticated BoltBlew checkout. No credentials are in the package.

## App integration kit

[Python, JavaScript and curl examples](docs/APP_INTEGRATION.md) use caller-owned intent keys and bounded requests. Run `npm run test:integration` for actual local HTTP contract tests, including lost-response recovery. This is local simulation, not live GPU use.

## Workload planner

[Plan model/context fit and advertised compute scenarios](docs/WORKLOAD_PLANNER.md) from a saved GET-only probe and explicit token estimates. `npm run plan -- --input probe.json --workload examples/workload.json --output output/plan.json` writes JSON and Markdown, preserving unknown prices, stale observations and capability limits. No inference or spending is performed.

## Business task packs

[Run support triage and document extraction](docs/TASK_PACKS.md) using labelled local fixtures or an explicit Connect endpoint. Endpoint inputs need only an ID and source text; expected answers are optional. [Try the installed support workflow](docs/INSTALL.md#try-a-new-support-input) with synthetic unlabelled inputs. Stable intent keys make batches resumable; literal evidence validation and human approval protect export, and exported results retain their simulation flag. The packs do not contact customers, alter tickets or fetch documents.

## GPU provider preflight

[Generate a redacted GPU diagnostic](docs/GPU_PREFLIGHT.md) from a strict supplied inventory or an opt-in local `nvidia-smi` query. Saved model-catalogue VRAM values are compared as advertised metadata only; missing operational driver, runtime, service and registration requirements stay unknown. The tool installs nothing, uses no wallet and does not register a provider.

## Capability and availability tracker

[Capture and compare bounded GET-only Coordinator observations](docs/CAPABILITY_TRACKER.md) as JSON, Markdown and self-contained HTML. Endpoint failures, stale evidence, empty advertised lists, zero connected providers and genuine changes remain distinct. Provider identifiers are one-way hashed and one Coordinator is never described as the whole network or an uptime measurement.

## Local pilot evidence

[Record opt-in local adoption events and generate identifier-free aggregates](docs/PILOT_MEASUREMENT.md) without telemetry, prompt content or device fingerprints. Simulation, local-only activity and supplied live-receipt evidence remain separate. The [programme handoff](docs/PROGRAMME_HANDOFF.md) lists every delivered component and the live/release decisions still required.
