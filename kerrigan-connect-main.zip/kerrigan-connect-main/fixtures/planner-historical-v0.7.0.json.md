# Kerrigan workload plan

Observation: 2026-09-25T14:18:12.614Z — stale.

Source: https://coordinator.jskitty.com. One supplied coordinator observation; not a whole-network census.

Workload: 10 job(s), 1000 input tokens + 128 overhead, 256 output ceiling per job.

Required capabilities: none; numerical/context screening only. Batch compute-only ceiling: not supplied satoshis.

No candidate meets all requested checks in a fresh successful observation. See candidate reasons and catalogue state.

| Model | Fit | Context needed / advertised | Providers | Price | Reasons |
| --- | --- | --- | --- | --- | --- |
| Llama-3.2-3B-Instruct&#95;IQ4&#95;XS | unknown | 1384 / 16384 | 1 | advertised | stale |

## Advertised compute scenarios — not invoices

| Model | Output ceiling used | Sats / job | Sats / batch | KRGN / batch | Fees | Final invoice |
| --- | --- | --- | --- | --- | --- | --- |
| Llama-3.2-3B-Instruct&#95;IQ4&#95;XS | 25% | 88400 | 884000 | 0.00884000 | unknown | unknown |
| Llama-3.2-3B-Instruct&#95;IQ4&#95;XS | 50% | 120400 | 1204000 | 0.01204000 | unknown | unknown |
| Llama-3.2-3B-Instruct&#95;IQ4&#95;XS | 100% | 184400 | 1844000 | 0.01844000 | unknown | unknown |

## Limits

- Caller token estimates, not tokenisation; include full conversation, instructions and template overhead.
- Scenarios are arithmetic at 25%, 50% and 100% of the requested output ceiling, not predicted output or probabilities.
- Advertised rates only; no cache discount, fee, refund, final invoice, latency, throughput or confidentiality is confirmed.
- Jobs use identical estimates; batch arithmetic does not establish concurrent capacity.
- Legacy zero prices without explicit observation provenance are unknown. No network requests or prompts are sent by this planner.

Live inference and spending remain disabled.
