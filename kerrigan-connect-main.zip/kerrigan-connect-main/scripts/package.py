#!/usr/bin/env python3
"""Package committed source and complete Git history, excluding local data/secrets."""
import argparse
import hashlib
import io
import json
import pathlib
import subprocess
import tarfile
import tempfile
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
VERSION = json.loads((ROOT / 'package.json').read_text())['version']

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default=str(ROOT.parent / f'kerrigan-connect-v{VERSION}.zip'))
    args = parser.parse_args()
    if git('status', '--porcelain').strip():
        raise SystemExit('Commit or remove untracked changes before packaging.')
    sha = git('rev-parse', 'HEAD').decode().strip()
    branch = git('branch', '--show-current').decode().strip()
    files = {}
    with tarfile.open(fileobj=io.BytesIO(git('archive', '--format=tar', 'HEAD'))) as archive:
        for member in archive.getmembers():
            if member.isfile():
                files['kerrigan-connect/' + member.name] = archive.extractfile(member).read()
    with tempfile.TemporaryDirectory(prefix='connect-package-', dir=ROOT.parent) as temporary:
        bundle = pathlib.Path(temporary) / 'kerrigan-connect.bundle'
        subprocess.run(['git', 'bundle', 'create', str(bundle), '--all'], cwd=ROOT, check=True)
        files['kerrigan-connect.bundle'] = bundle.read_bytes()
    files['START_HERE.md'] = f'''# Kerrigan Connect v{VERSION}\n\nOpen kerrigan-connect/examples/catalogue-demo.review.html in a browser to try the offline review workspace without installing anything.\n\nThe kerrigan-connect/ directory contains runnable source. Requires Node 24.14+ (24.x).\n\n    cd kerrigan-connect\n    npm run demo\n    npm test\n\nRead README.md for server setup and catalogue processing. The default is a\nlabelled simulation. Live mode is read-only; no real payments are enabled.\n\nThe self-contained Git history can be restored separately:\n\n    git clone kerrigan-connect.bundle kerrigan-connect-git\n\nSee docs/MERGE_PLAN.md before integrating into an existing Kerrigan repository.\n'''.encode()
    manifest = {
        'project': 'Kerrigan Connect', 'version': VERSION, 'commit': sha, 'branch': branch,
        'files': {name: hashlib.sha256(data).hexdigest() for name, data in sorted(files.items())},
    }
    files['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    output = pathlib.Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 9, 25, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    print(json.dumps({'path': str(output), 'commit': sha, 'files': len(files), 'bytes': output.stat().st_size,
                      'sha256': hashlib.sha256(output.read_bytes()).hexdigest()}))

if __name__ == '__main__':
    main()
