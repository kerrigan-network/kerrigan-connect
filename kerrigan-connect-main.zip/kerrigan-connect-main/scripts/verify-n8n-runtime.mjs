#!/usr/bin/env node
import { randomUUID } from 'node:crypto';
import { once } from 'node:events';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { promisify } from 'node:util';
import { execFile } from 'node:child_process';
import { createGatewayServer } from '../src/server.js';
import { Ledger } from '../src/ledger.js';
import { Gateway } from '../src/gateway.js';
import { DemoPayments, DemoProvider } from '../src/demo.js';

const exec = promisify(execFile);
const n8nBin = process.env.N8N_BIN;
const userFolder = process.env.N8N_USER_FOLDER;
const projectId = process.env.N8N_PROJECT_ID;
const customExtensions = process.env.N8N_CUSTOM_EXTENSIONS;
if (!n8nBin || !userFolder || !projectId || !customExtensions) throw new Error('Set N8N_BIN, N8N_USER_FOLDER, N8N_PROJECT_ID and N8N_CUSTOM_EXTENSIONS for an isolated local n8n profile.');

const temporary = await mkdtemp(join(tmpdir(), 'kerrigan-n8n-runtime-'));
const suffix = randomUUID().replaceAll('-', '').slice(0, 12);
const workflowId = 'KrgRun' + suffix;
const credentialId = 'KrgCred' + suffix;
const credentialName = 'Kerrigan runtime ' + suffix;
const apiKey = 'n8n-runtime-' + randomUUID() + '-' + randomUUID();
const ledger = new Ledger();
const payments = new DemoPayments();
const gateway = new Gateway({
  ledger,
  provider: new DemoProvider(),
  payments,
  budgets: { dailyBudgetSats: 1_000_000, jobBudgetSats: 100_000, maxNetworkFeeSats: 1000 },
});
const server = createGatewayServer(gateway, { apiKey });
server.listen(0, '127.0.0.1');
await once(server, 'listening');
const baseUrl = 'http://127.0.0.1:' + server.address().port;

const environment = {
  ...process.env,
  N8N_USER_FOLDER: userFolder,
  N8N_ENCRYPTION_KEY: process.env.N8N_ENCRYPTION_KEY || 'kerrigan-isolated-runtime-verification-key',
  N8N_DIAGNOSTICS_ENABLED: 'false',
  N8N_VERSION_NOTIFICATIONS_ENABLED: 'false',
  N8N_HIRING_BANNER_ENABLED: 'false',
  N8N_CUSTOM_EXTENSIONS: customExtensions,
};
const run = async args => exec(n8nBin, args, { env: environment, timeout: 120_000, maxBuffer: 10_000_000 });

function allObjects(value, output = []) {
  if (value && typeof value === 'object') {
    output.push(value);
    for (const child of Array.isArray(value) ? value : Object.values(value)) allObjects(child, output);
  }
  return output;
}

function executionJson(text) {
  const start = text.indexOf('{\n  "data":');
  if (start < 0) throw new Error('n8n did not emit raw execution JSON.');
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let index = start; index < text.length; index++) {
    const character = text[index];
    if (inString) {
      if (escaped) escaped = false;
      else if (character === '\\') escaped = true;
      else if (character === '"') inString = false;
      continue;
    }
    if (character === '"') inString = true;
    else if (character === '{') depth++;
    else if (character === '}' && --depth === 0) return JSON.parse(text.slice(start, index + 1));
  }
  throw new Error('n8n raw execution JSON was incomplete.');
}

try {
  const credentialsPath = join(temporary, 'credentials.json');
  await writeFile(credentialsPath, JSON.stringify([{
    id: credentialId,
    name: credentialName,
    type: 'kerriganConnectApi',
    data: { baseUrl, apiKey },
  }]));
  await run(['import:credentials', '--input=' + credentialsPath, '--projectId=' + projectId]);

  const source = JSON.parse(await readFile(new URL('../integrations/n8n/workflows/catalogue-job.json', import.meta.url), 'utf8'));
  source.id = workflowId;
  source.name = 'Kerrigan packaged runtime verification ' + suffix;
  for (const node of source.nodes.filter(item => item.type === 'n8n-nodes-kerrigan-connect.kerriganConnect')) {
    node.type = 'CUSTOM.kerriganConnect';
    node.credentials = { kerriganConnectApi: { id: credentialId, name: credentialName } };
  }
  const workflowPath = join(temporary, 'workflow.json');
  await writeFile(workflowPath, JSON.stringify(source));
  await run(['import:workflow', '--input=' + workflowPath, '--projectId=' + projectId]);

  const executions = [];
  for (let attempt = 0; attempt < 2; attempt++) {
    const { stdout } = await run(['execute', '--id=' + workflowId, '--rawOutput']);
    const output = executionJson(stdout);
    const completed = allObjects(output).find(item => item.status === 'completed' && item.result?.simulated === true);
    if (!completed || !/^job_[a-f0-9-]{36}$/.test(completed.id)) throw new Error('n8n execution did not return a completed simulated Kerrigan job.');
    executions.push({ job_id: completed.id, status: completed.status, simulated: completed.result.simulated });
  }
  if (executions[0].job_id !== executions[1].job_id || payments.payCalls !== 1) throw new Error('Repeated n8n execution did not replay the retained intent safely.');
  process.stdout.write(JSON.stringify({
    n8n_runtime: 'executed',
    workflow_imported: true,
    credential_imported: true,
    package_node_executed: true,
    loader: 'private_custom_extension',
    executions,
    simulated_payments: payments.payCalls,
    live_spending: false,
  }, null, 2) + '\n');
} finally {
  server.closeAllConnections();
  await new Promise(resolve => server.close(resolve));
  await gateway.stop();
  ledger.close();
  await rm(temporary, { recursive: true, force: true });
}
