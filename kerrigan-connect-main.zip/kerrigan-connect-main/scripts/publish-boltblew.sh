#!/usr/bin/env bash
# Run locally after authenticating GitHub CLI. Creates one new PRIVATE repo.
set -euo pipefail
project_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_root"
command -v gh >/dev/null || { echo 'Install GitHub CLI, then run gh auth login.' >&2; exit 1; }
[[ "$(gh api user --jq .login)" == 'BoltBlew' ]] || { echo 'The authenticated GitHub account must be BoltBlew.' >&2; exit 1; }
git rev-parse --verify HEAD >/dev/null
[[ -z "$(git status --porcelain)" ]] || { echo 'Commit or remove local changes before publishing.' >&2; exit 1; }
[[ -z "$(git remote)" ]] || { echo 'This checkout already has a remote. Review it before publishing.' >&2; exit 1; }
npm test
# gh fails if the target already exists. No force-push or repository overwrite.
gh repo create BoltBlew/kerrigan-connect --private --source=. --remote=origin --push \
  --description 'Independent Kerrigan integration prototype: local gateway, catalogue evaluation and offline review.'
gh repo view BoltBlew/kerrigan-connect --json nameWithOwner,isPrivate,url
