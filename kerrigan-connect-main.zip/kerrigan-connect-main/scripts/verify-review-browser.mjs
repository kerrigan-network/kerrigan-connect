/** Optional native-browser check. Requires a separately installed Playwright. */
import { createRequire } from 'node:module';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { renderReview } from '../src/review.js';
const require = createRequire(import.meta.url);
const modulePath = process.env.KCONNECT_PLAYWRIGHT_MODULE || 'playwright';
const { chromium } = require(modulePath);
const destination = resolve('output/browser'); mkdirSync(destination, { recursive: true });
// Exercise current source, not a previously generated page that might be stale.
const session = JSON.parse(readFileSync('examples/catalogue-demo.review.json', 'utf8'));
const html = renderReview(session);
const target = resolve(destination, 'catalogue.review.html'); writeFileSync(target, html);
const receipt = { format_version: 1, scope: 'native file-origin browser with synthetic catalogue data',
  status: 'failed', phase: 'launch', node: process.version, playwright: require(`${modulePath}/package.json`).version,
  browser: null, html_sha256: createHash('sha256').update(html).digest('hex'),
  source_sha256: Object.fromEntries(['src/review-page.js', 'src/review-browser.js', 'src/review-core.js', 'src/review.js', 'src/validation.js',
    'examples/catalogue-demo.review.json', 'scripts/verify-review-browser.mjs'].map(path =>
    [path, createHash('sha256').update(readFileSync(path)).digest('hex')])),
  real_krgn_spent: 0, live_execution_verified: false, checks: [] };
let browser;
try {
  browser = await chromium.launch({ headless: true, args: ['--no-sandbox'],
    ...(process.env.KCONNECT_CHROMIUM_EXECUTABLE ? { executablePath: process.env.KCONNECT_CHROMIUM_EXECUTABLE } : {}) });
  receipt.browser = browser.version();
  const page = await browser.newPage({ viewport: { width: 1440, height: 1050 }, acceptDownloads: true });
  const errors = [], requests = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('request', r => { if (/^https?:/.test(r.url())) requests.push(r.url()); });
  page.on('dialog', d => d.accept());
  receipt.phase = 'navigation';
  await page.goto(pathToFileURL(target).href);
  receipt.phase = 'workflow';
  await page.getByRole('heading', { name: 'Catalogue review', exact: true }).waitFor();
  assert.equal(await page.locator('#count-pending').textContent(), '6');
  assert.equal(await page.locator('#export').isDisabled(), true);
  await page.locator('#approve').click(); assert.equal(await page.locator('#count-approved').textContent(), '1');
  await page.locator('#material').fill('gold');
  assert.equal(await page.locator('#count-approved').textContent(), '0');
  assert.equal(await page.locator('#approve').isDisabled(), true);
  await page.locator('#material').fill(''); await page.locator('#note').fill('Manually checked against the source description.');
  await page.locator('#approve').click();
  let waiting = page.waitForEvent('download'); await page.locator('#save').click();
  const checkpoint = resolve(destination, 'decisions.json'); await (await waiting).saveAs(checkpoint);
  waiting = page.waitForEvent('download'); await page.locator('#export').click();
  const exported = resolve(destination, 'approved.csv'); await (await waiting).saveAs(exported);
  const csv = readFileSync(exported, 'utf8');
  assert.ok(csv.includes('SKU-001') && !csv.includes('SKU-002'));
  await page.reload(); assert.equal(await page.locator('#count-approved').textContent(), '0');
  await page.locator('#restore').setInputFiles(checkpoint);
  await page.getByText('Restored decisions for this exact source batch.', { exact: true }).waitFor();
  assert.equal(await page.locator('#count-approved').textContent(), '1');
  assert.equal(await page.locator('#note').inputValue(), 'Manually checked against the source description.');
  const bad = JSON.parse(readFileSync(checkpoint, 'utf8')); bad.source.rows[0].description += ' Different source';
  const badPath = resolve(destination, 'wrong-batch.json'); writeFileSync(badPath, JSON.stringify(bad));
  await page.locator('#restore').setInputFiles(badPath); await page.getByText('This checkpoint belongs to a different source batch.', { exact: true }).waitFor();
  assert.equal(await page.locator('#count-approved').textContent(), '1');
  await page.locator('#next').click(); assert.equal(await page.locator('#product-id').textContent(), 'SKU-002');
  await page.locator('#reject').click(); assert.equal(await page.locator('#count-rejected').textContent(), '1');
  await page.locator('#filter').selectOption('rejected'); assert.equal(await page.locator('.queue-item').count(), 1);
  await page.locator('#filter').selectOption('all');
  waiting = page.waitForEvent('download'); await page.locator('#export').click();
  const afterReject = resolve(destination, 'approved-after-reject.csv'); await (await waiting).saveAs(afterReject);
  assert.ok(!readFileSync(afterReject, 'utf8').includes('SKU-002'));
  receipt.checks.push('approval/edit/evidence checks', 'checkpoint download/reload/restore', 'wrong-source rejection',
    'rejected/pending rows excluded from downloaded CSV', 'queue filters');
  // Delay only the file read, not the app or DOM. Interact through real controls.
  await page.reload();
  await page.evaluate(() => {
    const read = File.prototype.text;
    window.delayedReads = [];
    File.prototype.text = function () {
      return new Promise((resolve, reject) => {
        window.delayedReads.push(() => read.call(this).then(resolve, reject));
      });
    };
  });
  await page.locator('#restore').setInputFiles(checkpoint);
  await page.waitForFunction(() => window.delayedReads.length === 1);
  await page.locator('#note').fill('Preserve this newer review work.');
  await page.locator('#reject').click();
  await page.evaluate(() => window.delayedReads[0]());
  await page.getByText('Review changed while the checkpoint was loading. Restore cancelled; save your current decisions and try again.', { exact: true }).waitFor();
  assert.equal(await page.locator('#note').inputValue(), 'Preserve this newer review work.');
  assert.equal(await page.locator('#decision').textContent(), 'rejected');
  assert.equal(await page.locator('#export').isDisabled(), true);
  waiting = page.waitForEvent('download'); await page.locator('#save').click();
  const preserved = resolve(destination, 'preserved-decisions.json'); await (await waiting).saveAs(preserved);
  assert.equal(JSON.parse(readFileSync(preserved, 'utf8')).decisions[0].state, 'rejected');
  await page.locator('#restore').setInputFiles(checkpoint);
  await page.locator('#restore').setInputFiles(preserved);
  await page.waitForFunction(() => window.delayedReads.length === 3);
  await page.evaluate(() => window.delayedReads[2]());
  await page.getByText('Restored decisions for this exact source batch.', { exact: true }).waitFor();
  await page.evaluate(() => window.delayedReads[1]());
  assert.equal(await page.locator('#decision').textContent(), 'rejected');
  assert.equal(await page.locator('#note').inputValue(), 'Preserve this newer review work.');
  receipt.checks.push('slow restore preserves newer edits/rejection', 'latest checkpoint selection wins');
  await page.screenshot({ path: resolve(destination, 'review-desktop.png'), fullPage: true });
  await page.setViewportSize({ width: 390, height: 844 });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true);
  await page.screenshot({ path: resolve(destination, 'review-mobile.png'), fullPage: true });
  assert.deepEqual(errors, []); assert.deepEqual(requests, []);
  receipt.checks.push('mobile width', 'zero page errors', 'zero HTTP requests');
  receipt.status = 'passed'; receipt.phase = 'complete';
  console.log('Browser verification passed: current rendered source, review/export, restart/restore, slow-read safety, latest-selection precedence, mobile width and zero HTTP requests.');
} catch (error) {
  receipt.error = error.message;
  throw error;
} finally {
  writeFileSync(resolve(destination, 'browser-receipt.json'), `${JSON.stringify(receipt, null, 2)}\n`);
  if (browser) await browser.close();
}
