import { mkdtemp, mkdir } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { once } from 'node:events';
import { Ledger } from '../src/ledger.js';
import { Gateway } from '../src/gateway.js';
import { DemoProvider, DemoPayments } from '../src/demo.js';
import { createGatewayServer } from '../src/server.js';

const modulePath = process.env.KCONNECT_PLAYWRIGHT_MODULE;
if (!modulePath) throw new Error('Set KCONNECT_PLAYWRIGHT_MODULE to an installed Playwright package.');
const { chromium } = await import(pathToFileURL(join(modulePath, 'index.mjs')));
const root = await mkdtemp(join(tmpdir(), 'kconnect-first-use-'));
const output = join(process.cwd(), 'output', 'first-use-browser');
await mkdir(output, { recursive: true });
const apiKey = 'synthetic-browser-first-use-key';
const ledger = new Ledger(join(root, 'ledger.sqlite'), { mode: 'demo' });
const payments = new DemoPayments();
const gateway = new Gateway({
  ledger, provider: new DemoProvider(), payments, mode: 'demo',
  budgets: { dailyBudgetSats: 1_000_000, jobBudgetSats: 100_000, maxNetworkFeeSats: 1000 },
});
const server = createGatewayServer(gateway, { apiKey });
let browser;
try {
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const base = `http://127.0.0.1:${server.address().port}`;
  browser = await chromium.launch({ headless: true, ...(process.env.KCONNECT_CHROMIUM_EXECUTABLE ? { executablePath: process.env.KCONNECT_CHROMIUM_EXECUTABLE } : {}) });
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const browserErrors = [];
  page.on('console', event => { if (event.type() === 'error') browserErrors.push(event.text()); });
  page.on('pageerror', error => browserErrors.push(error.message));
  await page.goto(base + '/start');
  await page.getByLabel('Gateway API key').fill(apiKey);
  await page.getByRole('button', { name: 'Check status' }).click();
  await page.getByText('available simulated', { exact: true }).waitFor();
  if (await page.locator('#gateway-key').inputValue()) throw new Error('API key input was not cleared.');
  if (payments.payCalls !== 0) throw new Error('The first-use status check must not submit or pay.');
  await page.screenshot({ path: join(output, 'desktop.png'), fullPage: true });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.screenshot({ path: join(output, 'mobile.png'), fullPage: true });
  await page.getByRole('link', { name: 'Open Catalogue Studio' }).click();
  await page.waitForURL(base + '/studio');
  await page.getByRole('heading', { name: /Catalogue Studio/i }).waitFor();
  if (browserErrors.length) throw new Error(`Browser errors: ${browserErrors.join(' | ')}`);
  console.log(JSON.stringify({ browser: await browser.version(), route: '/start', studio_handoff: true, payments: 0, screenshots: ['desktop.png', 'mobile.png'] }, null, 2));
} finally {
  if (browser) await browser.close();
  server.closeAllConnections();
  await new Promise(resolve => server.close(resolve));
  await gateway.stop();
  ledger.close();
}
