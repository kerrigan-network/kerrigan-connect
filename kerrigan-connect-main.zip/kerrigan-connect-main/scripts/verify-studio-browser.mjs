/** Optional native-browser flow; Playwright is not an application dependency. */
import { createRequire } from 'node:module';
import { mkdirSync, mkdtempSync, readFileSync, writeFileSync, rmSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { once } from 'node:events';
import assert from 'node:assert/strict';
import { Ledger } from '../src/ledger.js';
import { Gateway } from '../src/gateway.js';
import { DemoProvider, DemoPayments } from '../src/demo.js';
import { createGatewayServer } from '../src/server.js';

const require = createRequire(import.meta.url), modulePath = process.env.KCONNECT_PLAYWRIGHT_MODULE || 'playwright';
const { chromium } = require(modulePath);
const destination = resolve('output/studio-browser'); mkdirSync(destination, { recursive: true });
const directory = mkdtempSync(join(destination, 'temporary-ledger-'));
const key = 'studio-browser-synthetic-key-123456';
const receipt = { format_version: 1, scope: 'native Chromium on loopback with synthetic catalogue products',
  status: 'failed', phase: 'launch', node: process.version, playwright: require(`${modulePath}/package.json`).version,
  real_krgn_spent: 0, live_execution_verified: false, checks: [],
  source_sha256: Object.fromEntries(['src/studio.js', 'src/studio/index.html', 'src/studio/app.js', 'src/studio/style.css',
    'src/server.js', 'src/catalogue.js', 'src/review.js', 'src/review-core.js', 'src/review-browser.js', 'scripts/verify-studio-browser.mjs']
    .map(path => [path, createHash('sha256').update(readFileSync(path)).digest('hex')])) };
let browser, running;
async function stop() {
  if (!running) return;
  const { server, gateway, ledger } = running; running = null;
  server.closeAllConnections(); await new Promise(resolve => server.close(resolve));
  await gateway.stop(); ledger.close();
}
async function start() {
  const ledger = new Ledger(join(directory, 'ledger.sqlite')), payments = new DemoPayments();
  const gateway = new Gateway({ ledger, provider: new DemoProvider(), payments,
    budgets: { dailyBudgetSats: 1_000_000, jobBudgetSats: 100_000, maxNetworkFeeSats: 1000 } });
  const server = createGatewayServer(gateway, { apiKey: key }); running = { ledger, gateway, payments, server };
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  return `http://127.0.0.1:${server.address().port}`;
}
try {
  browser = await chromium.launch({ headless: true, args: ['--no-sandbox'],
    ...(process.env.KCONNECT_CHROMIUM_EXECUTABLE ? { executablePath: process.env.KCONNECT_CHROMIUM_EXECUTABLE } : {}) });
  receipt.browser = browser.version();
  const page = await browser.newPage({ viewport: { width: 1440, height: 1100 }, acceptDownloads: true });
  const errors = [], outside = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  page.on('dialog', dialog => dialog.accept());
  await page.route('**/*', route => {
    const url = new URL(route.request().url());
    if (url.protocol === 'http:' && url.hostname === '127.0.0.1') return route.continue();
    outside.push(url.origin); return route.abort();
  });
  let url = await start();
  async function connect() {
    await page.goto(url + '/studio');
    await page.locator('#gateway-key').fill(key); await page.locator('#connect').click();
    await page.getByText('Connected · simulated demo · no KRGN spend.', { exact: true }).waitFor();
    assert.equal(await page.locator('#gateway-key').inputValue(), '');
  }
  receipt.phase = 'initial batch'; await connect();
  await page.locator('#sample').click(); await page.locator('#prepare').click();
  await page.getByText('Batch prepared. Source and request identities are fixed for this run.', { exact: true }).waitFor();
  assert.equal(await page.locator('#process').isDisabled(), true);
  const batchFile = join(destination, 'batch.json');
  let waiting = page.waitForEvent('download'); await page.locator('#batch-save').click(); await (await waiting).saveAs(batchFile);
  assert.ok(!readFileSync(batchFile, 'utf8').includes(key));
  await page.locator('#process').click();
  await page.getByText('All products have receipts. Open review to check the results and approve exports.', { exact: true }).waitFor();
  assert.equal(running.payments.payCalls, 6);
  await page.locator('#open-review').click(); await page.locator('#product-id').waitFor({ state: 'visible' });
  assert.equal(await page.locator('#count-pending').textContent(), '6');
  await page.locator('#approve').click(); await page.locator('#next').click(); await page.locator('#reject').click();
  const decisions = join(destination, 'decisions.json');
  waiting = page.waitForEvent('download'); await page.locator('#save').click(); await (await waiting).saveAs(decisions);
  const approved = join(destination, 'approved.csv');
  waiting = page.waitForEvent('download'); await page.locator('#export').click(); await (await waiting).saveAs(approved);
  const csv = readFileSync(approved, 'utf8'); assert.ok(csv.includes('tee-01') && !csv.includes('mug-02'));
  receipt.checks.push('connect/import/prepare/process', 'batch download excludes credentials', 'approved-only CSV and review checkpoint');
  await page.screenshot({ path: join(destination, 'desktop.png'), fullPage: true });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.screenshot({ path: join(destination, 'mobile.png'), fullPage: true });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), true, 'Mobile layout must not overflow horizontally');
  receipt.checks.push('desktop/mobile screenshots and horizontal overflow check');

  receipt.phase = 'gateway restart recovery';
  await stop(); url = await start(); await connect();
  await page.locator('#batch-restore').setInputFiles(batchFile);
  await page.getByText('Batch restored. Resume to recover existing receipts and continue remaining products.', { exact: true }).waitFor();
  await page.locator('#process').click();
  await page.getByText('All products have receipts. Open review to check the results and approve exports.', { exact: true }).waitFor();
  assert.equal(running.payments.payCalls, 0);
  await page.locator('#open-review').click(); await page.locator('#restore').setInputFiles(decisions);
  await page.getByText('Restored decisions for this exact source batch.', { exact: true }).waitFor();
  assert.equal(await page.locator('#count-approved').textContent(), '1');
  assert.equal(await page.locator('#count-rejected').textContent(), '1');
  assert.deepEqual(errors, []); assert.deepEqual(outside, []);
  receipt.checks.push('gateway restart preserves receipts without new simulated payments', 'review decisions restore to exact batch', 'no runtime/CSP errors or outside requests');
  receipt.phase = 'complete'; receipt.status = 'passed';
} catch (error) {
  receipt.error = error.message; process.exitCode = 1;
} finally {
  await browser?.close(); await stop(); rmSync(directory, { recursive: true, force: true });
  writeFileSync(join(destination, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
  console.log(JSON.stringify(receipt, null, 2));
}
