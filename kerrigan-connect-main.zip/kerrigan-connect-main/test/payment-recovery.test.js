import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';
import { Ledger } from '../src/ledger.js';
import { Gateway } from '../src/gateway.js';
import { DemoProvider } from '../src/demo.js';
import { normalizeRequest } from '../src/validation.js';
import { LoopbackPaymentBridge, PreparedPaymentRecovery } from '../src/payment-recovery.js';
import { CoordinatorClient } from '../src/coordinator.js';
import { request, budgets } from './helpers.js';

// Deliberately synthetic bytes, NOT SDK output or a real signed transaction.
const signed = { txid: 'a'.repeat(64), tx_hex: '01020304', fee: 100, spent_utxos: [['b'.repeat(64), 0]] };
const currentBlock = async () => ({ height: 100, hash: 'f'.repeat(64) });
async function server(t, action = 'ok') {
  const calls = [];
  const http = createServer(async (req, res) => {
    let body = ''; for await (const chunk of req) body += chunk;
    calls.push({ method: req.method, path: req.url, type: req.headers['content-type'], body });
    if (action === 'disconnect') { req.socket.destroy(); return; }
    if (action === 'redirect') { res.writeHead(302, { location: '/unexpected' }); res.end(); return; }
    res.end(action === 'mismatch' ? 'c'.repeat(64) : action === 'oversize' ? 'x'.repeat(129) : signed.txid);
  });
  http.listen(0, '127.0.0.1'); await once(http, 'listening');
  t.after(() => new Promise(resolve => { http.closeAllConnections(); http.close(resolve); }));
  return { calls, bridge: new LoopbackPaymentBridge(`http://127.0.0.1:${http.address().port}`) };
}
async function evidenceServer(t) {
  const calls = [];
  const http = createServer((req, res) => {
    calls.push({ method: req.method, path: req.url }); res.setHeader('content-type', 'application/json');
    res.end(JSON.stringify(req.url === '/v1/block/current'
      ? { height: 199999, hash: 'f'.repeat(64) }
      : { txid: signed.txid, hex: signed.tx_hex, confirmations: 0 }));
  });
  http.listen(0, '127.0.0.1'); await once(http, 'listening');
  t.after(() => new Promise(resolve => { http.closeAllConnections(); http.close(resolve); }));
  return { calls, client: new CoordinatorClient({ coordinatorUrl: `http://127.0.0.1:${http.address().port}` }) };
}
async function pending(ledger, key = 'prepared-job-01') {
  const req = normalizeRequest(request());
  const invoice = await new DemoProvider().quote(req);
  const job = ledger.create(key, req).job;
  ledger.reserve(job.id, invoice, budgets); ledger.beginPayment(job.id);
  return { jobId: job.id, request: req, invoice };
}

test('real loopback bridge uses wallet wire contract and integrates with gateway', async t => {
  const ledger = new Ledger(); t.after(() => ledger.close());
  const { bridge, calls } = await server(t);
  let preparations = 0;
  const payments = new PreparedPaymentRecovery({ ledger, bridge, prepare: async () => {
    preparations++; return structuredClone(signed);
  }, getRawTransaction: async txid => { assert.equal(txid, signed.txid); return signed.tx_hex; }, getCurrentBlock: currentBlock });
  const gateway = new Gateway({ ledger, provider: new DemoProvider(), payments, budgets });
  t.after(() => gateway.stop());
  const { job } = gateway.submit(request(), 'prepared-gateway-01');
  assert.equal((await gateway.wait(job.id)).status, 'completed');
  gateway.submit(request(), 'prepared-gateway-01');
  assert.equal(preparations, 1);
  assert.deepEqual(calls, [{ method: 'POST', path: '/sendrawtransaction', type: 'text/plain', body: signed.tx_hex }]);
  assert.equal(ledger.get(job.id).paid_sats, ledger.get(job.id).invoice.amount_sat);
  assert.ok(!JSON.stringify(ledger.view(job.id)).includes(signed.tx_hex));
});

test('coordinator GET readers drive expiry and exact-byte recovery after broadcast', async t => {
  const ledger = new Ledger(); t.after(() => ledger.close());
  const { bridge, calls: broadcasts } = await server(t);
  const { client, calls: reads } = await evidenceServer(t);
  const payments = new PreparedPaymentRecovery({ ledger, bridge, prepare: async () => signed,
    getRawTransaction: txid => client.rawTransaction(txid), getCurrentBlock: () => client.currentBlock() });
  const gateway = new Gateway({ ledger, provider: new DemoProvider(), payments, budgets });
  t.after(() => gateway.stop());
  const { job } = gateway.submit(request(), 'coordinator-evidence-01');
  assert.equal((await gateway.wait(job.id)).status, 'completed');
  assert.equal(broadcasts.length, 1);
  assert.deepEqual(reads.map(x => x.path), [
    '/v1/block/current', '/v1/block/current', `/v1/tx/${signed.txid}`,
  ]);
  assert.ok(reads.every(x => x.method === 'GET'));
});

test('lost acknowledgement survives database reopen and recovers by lookup without repaying', async t => {
  const dir = mkdtempSync(join(tmpdir(), 'kconnect-outbox-'));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const path = join(dir, 'ledger.sqlite');
  let ledger = new Ledger(path);
  const { bridge, calls } = await server(t, 'disconnect');
  let prepares = 0;
  let payments = new PreparedPaymentRecovery({ ledger, bridge, prepare: async () => { prepares++; return signed; }, getRawTransaction: async () => signed.tx_hex, getCurrentBlock: currentBlock });
  let gateway = new Gateway({ ledger, provider: new DemoProvider(), payments, budgets });
  const { job } = gateway.submit(request(), 'lost-ack-recovery');
  const failed = await gateway.wait(job.id);
  assert.equal(failed.status, 'needs_reconciliation');
  assert.ok(failed.reserved_sats > 0);
  await gateway.stop(); ledger.close();
  ledger = new Ledger(path); t.after(() => ledger.close());
  payments = new PreparedPaymentRecovery({ ledger, bridge, prepare: async () => { throw Error('must not sign again'); }, getRawTransaction: async () => signed.tx_hex, getCurrentBlock: currentBlock });
  gateway = new Gateway({ ledger, provider: new DemoProvider(), payments, budgets, autoStart: false });
  t.after(() => gateway.stop());
  const recovered = await payments.reconcile(job.id);
  assert.equal(recovered.status, 'paid'); assert.equal(recovered.reserved_sats, 0);
  gateway.kick();
  assert.equal((await gateway.wait(job.id)).status, 'completed');
  assert.equal(prepares, 1); assert.equal(calls.length, 1);
});

test('broadcast intent committed by an exited child process prevents a new attempt', async t => {
  const dir = mkdtempSync(join(tmpdir(), 'kconnect-outbox-process-'));
  const path = join(dir, 'ledger.sqlite');
  let ledger = new Ledger(path);
  const args = await pending(ledger); ledger.stagePayment(args.jobId, signed); ledger.close();
  execFileSync(process.execPath, ['--input-type=module', '--eval', `
    import { Ledger } from ${JSON.stringify(new URL('../src/ledger.js', import.meta.url).href)};
    const ledger = new Ledger(process.argv[1]);
    ledger.beginPreparedBroadcast(process.argv[2]);
    process.exit(0); // Simulate termination after durable intent, before any response.
  `, path, args.jobId], { timeout: 5000 });
  ledger = new Ledger(path);
  t.after(() => { ledger.close(); rmSync(dir, { recursive: true, force: true }); });
  ledger.recover();
  assert.equal(ledger.get(args.jobId).status, 'needs_reconciliation');
  assert.equal(ledger.preparedPayment(args.jobId).broadcast_started, 1);
  assert.throws(() => ledger.beginPreparedBroadcast(args.jobId), { code: 'reconciliation_required' });
  assert.ok(ledger.get(args.jobId).reserved_sats > 0);
});

test('missing, different or unavailable lookup cannot release reservation or permit rebroadcast', async t => {
  const ledger = new Ledger(); t.after(() => ledger.close());
  const args = await pending(ledger);
  ledger.stagePayment(args.jobId, signed); ledger.beginPreparedBroadcast(args.jobId); ledger.recover();
  const reserved = ledger.get(args.jobId).reserved_sats;
  const { bridge, calls } = await server(t);
  for (const reader of [async () => null, async () => 'ffff', async () => { throw Error('PRIVATE_SERVER_DETAIL'); }]) {
    const payments = new PreparedPaymentRecovery({ ledger, bridge, prepare: async () => { throw Error('must not prepare'); }, getRawTransaction: reader, getCurrentBlock: currentBlock });
    await assert.rejects(payments.reconcile(args.jobId), e => e.code === 'payment_not_observed' && !e.message.includes('PRIVATE'));
    await assert.rejects(payments.pay(args), { code: 'reconciliation_required' });
    assert.equal(ledger.get(args.jobId).reserved_sats, reserved);
  }
  assert.equal(calls.length, 0);
});

test('atomic broadcast claim allows only one connection to attempt network I/O', async t => {
  const dir = mkdtempSync(join(tmpdir(), 'kconnect-outbox-concurrent-'));
  const path = join(dir, 'ledger.sqlite'); const a = new Ledger(path), b = new Ledger(path);
  t.after(() => { a.close(); b.close(); rmSync(dir, { recursive: true, force: true }); });
  const args = await pending(a); a.stagePayment(args.jobId, signed);
  const { bridge, calls } = await server(t);
  const payments = [a, b].map(ledger => new PreparedPaymentRecovery({ ledger, bridge, prepare: async () => signed, getRawTransaction: async () => signed.tx_hex, getCurrentBlock: currentBlock }));
  const results = await Promise.allSettled(payments.map(p => p.pay(args)));
  assert.equal(results.filter(x => x.status === 'fulfilled').length, 1);
  assert.equal(calls.length, 1);
});

test('prepared output is immutable, budget bounded and reserves inputs across jobs', async t => {
  const ledger = new Ledger(); t.after(() => ledger.close());
  const a = await pending(ledger), b = await pending(ledger, 'prepared-job-02');
  for (const patch of [{ tx_hex: 'x' }, { fee: 1001 }, { spent_utxos: [] }, { spent_utxos: [...signed.spent_utxos, ...signed.spent_utxos] }]) {
    assert.throws(() => ledger.stagePayment(a.jobId, { ...signed, ...patch }), { code: 'invalid_prepared_payment' });
  }
  ledger.stagePayment(a.jobId, signed); ledger.stagePayment(a.jobId, signed);
  assert.throws(() => ledger.stagePayment(a.jobId, { ...signed, tx_hex: 'ffff' }), { code: 'prepared_payment_conflict' });
  assert.throws(() => ledger.stagePayment(b.jobId, { ...signed, txid: 'c'.repeat(64) }), { code: 'payment_input_reserved' });
  assert.equal(ledger.preparedPayment(b.jobId), null);
  assert.throws(() => ledger.recordPayment(a.jobId, { txid: signed.txid, fee_sats: 100, amount_sats: a.invoice.amount_sat }), { code: 'invalid_receipt' });
});

test('unexpected acknowledgement and redirect stop after one broadcast attempt', async t => {
  for (const action of ['mismatch', 'redirect', 'oversize']) {
    const ledger = new Ledger(); t.after(() => ledger.close());
    const { bridge, calls } = await server(t, action); const args = await pending(ledger);
    const payments = new PreparedPaymentRecovery({ ledger, bridge, prepare: async () => signed, getRawTransaction: async () => { throw Error('lookup not expected'); }, getCurrentBlock: currentBlock });
    await assert.rejects(payments.pay(args), { code: 'broadcast_unknown' });
    await assert.rejects(payments.pay(args), { code: 'reconciliation_required' });
    assert.equal(calls.length, 1);
  }
});

test('development payment transport refuses public hosts, credentials and ambiguous URLs', () => {
  for (const url of ['https://kerrigan-bridge.jskitty.com', 'http://localhost:1234', 'http://127.0.0.1@evil.test', 'http://127.0.0.1/path', 'http://127.0.0.1?x=1']) {
    assert.throws(() => new LoopbackPaymentBridge(url), { code: 'live_spending_disabled' });
  }
});

test('expired or unavailable block tip stops before preparation and broadcast', async t => {
  for (const tip of [async () => 200000, async () => 200001, async () => ({ height: -1 }), async () => { throw Error('PRIVATE_NODE'); }]) {
    const ledger = new Ledger(); t.after(() => ledger.close());
    const { bridge, calls } = await server(t); const args = await pending(ledger);
    let preparations = 0;
    const payments = new PreparedPaymentRecovery({ ledger, bridge, prepare: async () => { preparations++; return signed; }, getRawTransaction: async () => signed.tx_hex, getCurrentBlock: tip });
    await assert.rejects(payments.pay(args), error => ['invoice_expired', 'chain_tip_unavailable'].includes(error.code) && !error.message.includes('PRIVATE'));
    assert.equal(preparations, 0); assert.equal(calls.length, 0);
    assert.equal(ledger.preparedPayment(args.jobId), null);
  }
});

test('invoice expiring during preparation stops before broadcast and retains prepared bytes', async t => {
  const ledger = new Ledger(); t.after(() => ledger.close());
  const { bridge, calls } = await server(t); const args = await pending(ledger);
  let reads = 0;
  const payments = new PreparedPaymentRecovery({ ledger, bridge, prepare: async () => signed,
    getRawTransaction: async () => signed.tx_hex, getCurrentBlock: async () => ++reads === 1 ? 199999 : 200000 });
  await assert.rejects(payments.pay(args), { code: 'invoice_expired' });
  assert.equal(calls.length, 0); assert.equal(ledger.preparedPayment(args.jobId).broadcast_started, 0);
});
