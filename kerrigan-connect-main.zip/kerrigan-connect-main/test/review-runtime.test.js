import test from 'node:test';
import assert from 'node:assert/strict';
import { runInNewContext } from 'node:vm';
import { readFileSync } from 'node:fs';
import { renderReview } from '../src/review.js';

// This small DOM harness verifies event wiring and downloaded bytes. It does not
// emulate browser rendering, CSP enforcement, file-picker policy or layout.
function loadPage(session) {
  const html = renderReview(session), downloads = [], blobs = new Map(), globalEvents = {};
  class Element {
    constructor(tag) { this.tag = tag; this.value = ''; this.textContent = ''; this.children = []; this.listeners = {}; this.attributes = {}; this.files = []; }
    append(...children) { this.children.push(...children); }
    replaceChildren(...children) { this.children = children; }
    setAttribute(k, v) { this.attributes[k] = v; }
    addEventListener(name, fn) { (this.listeners[name] ||= []).push(fn); }
    async fire(name) { for (const fn of this.listeners[name] || []) await fn({ target: this }); }
    click() { if (this.tag === 'a') downloads.push({ name: this.download, blob: blobs.get(this.href) }); else return this.fire('click'); }
  }
  const elements = Object.fromEntries([...html.matchAll(/\bid="([^"]+)"/g)].map(m => [m[1], new Element('element')]));
  elements.filter.value = 'all';
  runInNewContext(html.match(/<script>([\s\S]*)<\/script>/)[1], {
    document: { getElementById: id => { assert.ok(elements[id], `Missing element: ${id}`); return elements[id]; }, createElement: tag => new Element(tag) },
    Blob, structuredClone,
    URL: { createObjectURL: blob => { const id = `blob:${blobs.size}`; blobs.set(id, blob); return id; }, revokeObjectURL: id => blobs.delete(id) },
    setTimeout: () => {}, addEventListener: (name, fn) => { globalEvents[name] = fn; },
  }, { timeout: 1000 });
  return { elements, downloads, globalEvents };
}

test('standalone review script wires approval, edits, downloads and exact-source checkpoint restoration', async () => {
  const source = JSON.parse(readFileSync(new URL('../examples/catalogue-demo.review.json', import.meta.url)));
  const { elements: e, downloads, globalEvents } = loadPage(source);
  assert.equal(e['count-pending'].textContent, 6); assert.equal(e.export.disabled, true);
  await e.approve.click(); assert.equal(e['count-approved'].textContent, 1);
  e.material.value = 'gold'; await e.material.fire('input');
  assert.equal(e['count-approved'].textContent, 0); assert.equal(e.approve.disabled, true);
  e.material.value = ''; await e.material.fire('input'); await e.approve.click();
  await e.save.click();
  const saved = JSON.parse(await downloads[0].blob.text()); assert.equal(saved.decisions[0].state, 'approved');
  await e.export.click(); const csv = await downloads[1].blob.text(); assert.ok(csv.includes('SKU-001') && !csv.includes('SKU-002'));
  await e.reset.click(); assert.equal(e['count-approved'].textContent, 0);
  let prevented = false; globalEvents.beforeunload({ preventDefault: () => { prevented = true; } }); assert.equal(prevented, true);
  e.restore.files = [{ size: 3000, text: async () => JSON.stringify(saved) }]; await e.restore.fire('change');
  assert.equal(e['count-approved'].textContent, 1);
  const changed = structuredClone(saved); changed.source.rows[0].description += ' Different';
  e.restore.files = [{ size: 3000, text: async () => JSON.stringify(changed) }]; await e.restore.fire('change');
  assert.equal(e.message.textContent, 'This checkpoint belongs to a different source batch.'); assert.equal(e['count-approved'].textContent, 1);
  await e.next.click(); assert.equal(e['product-id'].textContent, 'SKU-002'); await e.reject.click();
  e.filter.value = 'rejected'; await e.filter.fire('change'); assert.equal(e.queue.children.length, 1);
});

function fixture() {
  return JSON.parse(readFileSync(new URL('../examples/catalogue-demo.review.json', import.meta.url)));
}
function deferredFile() {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return { file: { size: 3000, text: () => promise }, resolve, reject };
}
async function checkpoint(page) {
  await page.elements.save.click();
  return JSON.parse(await page.downloads.at(-1).blob.text());
}
function isDirty(page) {
  let prevented = false;
  page.globalEvents.beforeunload({ preventDefault: () => { prevented = true; } });
  return prevented;
}

for (const action of ['note', 'colour', 'reject', 'reset']) {
  test(`slow checkpoint restore preserves newer ${action} and never silently restores approval`, async () => {
    const page = loadPage(fixture()), e = page.elements;
    await e.approve.click();
    const saved = await checkpoint(page), delayed = deferredFile();
    e.restore.files = [delayed.file];
    const restoring = e.restore.fire('change');
    if (action === 'note' || action === 'colour') {
      e[action].value = action === 'note' ? 'New work while the file is loading.' : '';
      await e[action].fire('input');
    } else await e[action].click();
    const expectedState = action === 'reject' ? 'rejected' : 'pending';
    delayed.resolve(JSON.stringify(saved)); await restoring;
    assert.equal(e.decision.textContent, expectedState);
    assert.equal(e['count-approved'].textContent, 0);
    assert.equal(e.export.disabled, true);
    assert.match(e.message.textContent, /Review changed while the checkpoint was loading/);
    assert.equal(isDirty(page), true);
    const current = await checkpoint(page);
    assert.equal(current.decisions[0].state, expectedState);
    if (action === 'note') assert.equal(current.decisions[0].note, 'New work while the file is loading.');
    if (action === 'colour') assert.equal(current.decisions[0].values.colour, '');
    assert.deepEqual(current.source, saved.source);
  });
}

test('newest selected checkpoint wins even when an older file finishes last', async () => {
  const page = loadPage(fixture()), e = page.elements;
  const older = fixture(), newer = fixture();
  older.decisions[0].note = 'Older choice'; newer.decisions[0].note = 'Newest choice';
  const a = deferredFile(), b = deferredFile();
  e.restore.files = [a.file]; const first = e.restore.fire('change');
  e.restore.files = [b.file]; const second = e.restore.fire('change');
  b.resolve(JSON.stringify(newer)); await second;
  a.resolve(JSON.stringify(older)); await first;
  assert.equal(e.note.value, 'Newest choice');
  assert.equal(e.message.textContent, 'Restored decisions for this exact source batch.');
  assert.equal(isDirty(page), false);
});

test('superseded restore cannot clear the newest file input or report its late error', async () => {
  const page = loadPage(fixture()), e = page.elements, a = deferredFile(), b = deferredFile();
  e.restore.files = [a.file]; const first = e.restore.fire('change');
  e.restore.files = [b.file]; e.restore.value = 'newest-checkpoint.json';
  const second = e.restore.fire('change');
  a.reject(new Error('Old read failed')); await first;
  assert.equal(e.restore.value, 'newest-checkpoint.json');
  assert.notEqual(e.message.textContent, 'Old read failed');
  b.resolve(JSON.stringify(fixture())); await second;
  assert.equal(e.restore.value, '');
  assert.equal(e.message.textContent, 'Restored decisions for this exact source batch.');
});

test('a newer invalid checkpoint supersedes the older pending selection without replacing edits', async () => {
  const page = loadPage(fixture()), e = page.elements, a = deferredFile();
  e.note.value = 'Keep my current work'; await e.note.fire('input');
  e.restore.files = [a.file]; const first = e.restore.fire('change');
  e.restore.files = [{ size: 1, text: async () => '{' }]; await e.restore.fire('change');
  const failureMessage = e.message.textContent;
  a.resolve(JSON.stringify(fixture())); await first;
  assert.equal(e.note.value, 'Keep my current work');
  assert.equal(e.message.textContent, failureMessage);
  assert.equal(isDirty(page), true);
});

test('checkpoint size limit refuses the file before reading without losing decisions', async () => {
  const page = loadPage(fixture()), e = page.elements;
  await e.reject.click();
  let read = false;
  e.restore.files = [{ size: 20_000_001, text: async () => { read = true; return '{}'; } }];
  await e.restore.fire('change');
  assert.equal(read, false); assert.equal(e.decision.textContent, 'rejected');
  assert.equal(e.message.textContent, 'Checkpoint must be at most 20 MB.');
  assert.equal(isDirty(page), true);
});

test('bundled review page is regenerated from current source and the exact labelled dataset', () => {
  assert.equal(readFileSync(new URL('../examples/catalogue-demo.review.html', import.meta.url), 'utf8'), renderReview(fixture()));
});
