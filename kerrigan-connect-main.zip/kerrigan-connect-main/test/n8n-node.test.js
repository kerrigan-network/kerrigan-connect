import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { createGatewayServer } from '../src/server.js';
import { setup, request } from './helpers.js';

const require = createRequire(import.meta.url);
const { KerriganConnect } = require('../integrations/n8n/nodes/KerriganConnect/KerriganConnect.node.js');
const { KerriganConnectApi } = require('../integrations/n8n/credentials/KerriganConnectApi.credentials.js');
const { connectRequest, gatewayUrl, intentKey, requestBody } = require('../integrations/n8n/lib/client.js');
const apiKey = 'n8n-test-only-api-key-123456789';

async function fixture(t) {
  const state = setup(t);
  const server = createGatewayServer(state.gateway, { apiKey });
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  t.after(async () => { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); });
  return { ...state, credentials: { baseUrl: `http://127.0.0.1:${server.address().port}`, apiKey } };
}

async function execute(credentials, parameters, { continueOnFail = false } = {}) {
  const node = new KerriganConnect();
  return node.execute.call({
    getInputData: () => [{ json: {} }],
    getCredentials: async () => credentials,
    getNodeParameter: (name, _index, fallback) => parameters[name] ?? fallback,
    continueOnFail: () => continueOnFail,
  });
}

test('installable package declares credential and all B2 operations', () => {
  const manifest = JSON.parse(readFileSync(new URL('../integrations/n8n/package.json', import.meta.url)));
  assert.equal(manifest.name, 'n8n-nodes-kerrigan-connect');
  assert.deepEqual(manifest.n8n.credentials, ['credentials/KerriganConnectApi.credentials.js']);
  assert.deepEqual(manifest.n8n.nodes, ['nodes/KerriganConnect/KerriganConnect.node.js']);
  const operations = new KerriganConnect().description.properties.find(property => property.name === 'operation').options.map(option => option.value);
  assert.deepEqual(operations, ['models', 'submit', 'status', 'result', 'recover']);
  assert.equal(new KerriganConnectApi().properties.find(property => property.name === 'apiKey').typeOptions.password, true);
});

test('node discovers, submits, polls, inspects and recovers one durable intent over real HTTP', async t => {
  const { credentials, payments } = await fixture(t);
  const models = (await execute(credentials, { operation: 'models', requestTimeoutMs: 15000 }))[0][0].json;
  assert.equal(models.data[0].id, 'demo/catalogue-v1');
  const original = request();
  const submitted = (await execute(credentials, { operation: 'submit', intentKey: 'n8n-contract-intent-0001', requestJson: JSON.stringify(original), requestTimeoutMs: 15000 }))[0][0].json;
  assert.equal(submitted.status, 'queued');
  assert.equal(submitted._kerrigan_n8n.http_status, 202);
  const complete = (await execute(credentials, { operation: 'result', jobId: submitted.id, resultTimeoutMs: 5000, pollIntervalMs: 100, requestTimeoutMs: 15000 }))[0][0].json;
  assert.equal(complete.status, 'completed');
  assert.equal(complete.result.simulated, true);
  const status = (await execute(credentials, { operation: 'status', jobId: submitted.id, requestTimeoutMs: 15000 }))[0][0].json;
  assert.equal(status.id, submitted.id);
  const recovered = (await execute(credentials, { operation: 'recover', intentKey: 'n8n-contract-intent-0001', requestJson: original, requestTimeoutMs: 15000 }))[0][0].json;
  assert.equal(recovered.id, submitted.id);
  assert.equal(recovered._kerrigan_n8n.replayed, true);
  assert.equal(payments.payCalls, 1);
});

test('lost-response recovery preserves intent and changed input conflicts without duplicate payment', async t => {
  const { credentials, payments } = await fixture(t);
  const original = request();
  const first = await connectRequest(credentials, '/connect/jobs', { method: 'POST', body: original, key: 'n8n-lost-response-0001' });
  const replay = await connectRequest(credentials, '/connect/jobs', { method: 'POST', body: original, key: 'n8n-lost-response-0001' });
  assert.equal(first.body.id, replay.body.id);
  assert.equal(replay.status, 200);
  await assert.rejects(connectRequest(credentials, '/connect/jobs', { method: 'POST', body: request({ temperature: 1 }), key: 'n8n-lost-response-0001' }), { code: 'idempotency_conflict', status: 409 });
  const complete = (await execute(credentials, { operation: 'result', jobId: first.body.id, resultTimeoutMs: 5000, pollIntervalMs: 100, requestTimeoutMs: 15000 }))[0][0].json;
  assert.equal(complete.status, 'completed');
  assert.equal(payments.payCalls, 1);
});

test('validation is bounded and Continue On Fail returns a credential-free error', async t => {
  const { credentials } = await fixture(t);
  assert.throws(() => gatewayUrl('http://example.com:8787'), { code: 'invalid_credentials' });
  assert.throws(() => intentKey('new'), { code: 'invalid_intent_key' });
  assert.throws(() => requestBody('{broken'), { code: 'invalid_request_json' });
  assert.throws(() => requestBody({ payload: 'x'.repeat(200_001) }), { code: 'request_too_large' });
  const result = (await execute(credentials, { operation: 'submit', intentKey: 'bad', requestJson: request(), requestTimeoutMs: 15000 }, { continueOnFail: true }))[0][0].json;
  assert.equal(result.error.code, 'invalid_intent_key');
  assert.ok(!JSON.stringify(result).includes(apiKey));
  assert.ok(!JSON.stringify(result).includes('Hello'));
});

test('workflow exports are disabled, use packaged nodes and retain an explicit recovery key', () => {
  for (const name of ['catalogue-job.json', 'recover-intent.json']) {
    const workflow = JSON.parse(readFileSync(new URL(`../integrations/n8n/workflows/${name}`, import.meta.url)));
    assert.equal(workflow.active, false);
    const nodes = workflow.nodes.filter(node => node.type === 'n8n-nodes-kerrigan-connect.kerriganConnect');
    assert.ok(nodes.length > 0);
    assert.ok(nodes.every(node => ['submit', 'result', 'recover'].includes(node.parameters.operation)));
  }
  const recovery = readFileSync(new URL('../integrations/n8n/workflows/recover-intent.json', import.meta.url), 'utf8');
  assert.match(recovery, /Never generate a new key/);
  assert.match(recovery, /n8n-catalogue-package-demo-0001/);
});
