import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { CoordinatorClient } from '../src/coordinator.js';
import { normalizeRequest } from '../src/validation.js';

// Wire contract follows the pinned public webwallet adapter, not a real Drone.
const drone = 'a'.repeat(40);
const txid = 'd'.repeat(64);
const request = normalizeRequest({ model: 'fixture-model', messages: [{ role: 'user', content: 'Synthetic test only' }], max_tokens: 128, temperature: 0, top_p: 0.8, seed: 123 });

async function relay(t, invoiceError = false, modelFields = {}) {
  const calls = [];
  const server = createServer(async (req, res) => {
    let raw = ''; for await (const chunk of req) raw += chunk;
    const body = raw ? JSON.parse(raw) : null;
    calls.push({ method: req.method, path: req.url, body });
    res.setHeader('content-type', 'application/json');
    const result = req.url === '/v1/models' ? { models: [{ id: 'fixture-model', name: 'Fixture Model Q4', providers: [drone], context_length: 16384, ...modelFields }] }
      : req.url === '/v1/invoice' ? (invoiceError ? { error: 'PRIVATE_PROVIDER_DETAIL' } : {
        amount_sat: 2500, max_tokens: 128, drone_pubkey_hash: drone,
        pay_to_address: `K${'a'.repeat(33)}`, model_hash: 'b'.repeat(16), expires_block: 200000,
      }) : { response: 'Synthetic output', token_count: 2, commitment: { fixture: true } };
    res.end(JSON.stringify(result));
  });
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  t.after(() => new Promise(resolve => { server.closeAllConnections(); server.close(resolve); }));
  return { calls, client: new CoordinatorClient({ coordinatorUrl: `http://127.0.0.1:${server.address().port}` }) };
}

test('actual loopback relay carries pinned invoice and immutable inference replay fields', async t => {
  const { client, calls } = await relay(t);
  const invoice = await client.quote(request);
  const first = await client.infer(request, invoice, txid);
  await client.infer(request, invoice, txid);
  assert.deepEqual(calls.map(x => [x.method, x.path]), [['GET', '/v1/models'], ['POST', '/v1/invoice'], ['POST', '/v1/chat'], ['POST', '/v1/chat']]);
  assert.deepEqual(calls[1].body, { model: 'Fixture Model Q4', messages: request.messages, max_tokens: 128, drone_pubkey_hash: drone });
  assert.deepEqual(calls[2].body, { drone_pubkey_hash: drone, payment_txid: txid, model: 'Fixture Model Q4', messages: request.messages, max_tokens: 128, temperature: 0, top_p: 0.8, seed: 123, k: 16 });
  assert.deepEqual(calls[2].body, calls[3].body);
  assert.equal(first.content, 'Synthetic output');
  assert.equal(first.verification, 'not_performed');
});

test('HTTP 200 provider invoice rejection stops the flow and sanitises the error', async t => {
  const { client, calls } = await relay(t, true);
  await assert.rejects(client.quote(request), error => error.code === 'upstream_rejected' && !error.message.includes('PRIVATE_PROVIDER_DETAIL'));
  assert.equal(calls.length, 2);
});

test('missing or malformed transaction references cause no inference HTTP request', async t => {
  const { client, calls } = await relay(t);
  for (const bad of [undefined, '', 'not-a-transaction', 'e'.repeat(63)]) {
    await assert.rejects(client.infer(request, { drone_pubkey_hash: drone }, bad), { code: 'invalid_payment_reference' });
  }
  assert.equal(calls.length, 0);
});

test('saved quote survives JSON restart and catalogue rename without changing replay model', async t => {
  const fields = { name: 'Pinned Model' };
  const { client, calls } = await relay(t, false, fields);
  const invoice = JSON.parse(JSON.stringify(await client.quote(request)));
  fields.name = 'Replacement Model';
  const restarted = new CoordinatorClient({ coordinatorUrl: client.coordinatorUrl });
  await restarted.infer(JSON.parse(JSON.stringify(request)), invoice, txid);
  assert.equal(calls[2].body.model, 'Pinned Model');
  assert.equal(calls.filter(x => x.path === '/v1/models').length, 1);
  assert.equal('x_connect_binding' in calls[2].body, false);
});

test('changed task, sampling or invoice fields fail before inference HTTP', async t => {
  const { client, calls } = await relay(t);
  const invoice = await client.quote(request);
  for (const changed of [
    { model: 'other-model' }, { messages: [{ role: 'user', content: 'Different task' }] },
    { max_tokens: 127 }, { temperature: 1 }, { top_p: 0.9 }, { seed: 124 }, { k: 8 },
  ]) {
    await assert.rejects(client.infer({ ...request, ...changed }, invoice, txid), { code: 'invoice_binding_changed' });
  }
  for (const changed of [
    { drone_pubkey_hash: 'e'.repeat(40) }, { model_hash: 'e'.repeat(16) },
    { amount_sat: 1 }, { pay_to_address: `K${'b'.repeat(33)}` }, { expires_block: 1 },
    { max_tokens: 1 }, { x_connect_binding: undefined },
  ]) {
    await assert.rejects(client.infer(request, { ...invoice, ...changed }, txid), { code: 'invoice_binding_changed' });
  }
  assert.equal(calls.length, 2);
});

test('missing or invalid wire names never trigger an invoice POST', async t => {
  for (const name of [null, '', '   ', 'x'.repeat(257), 'bad\nname', 12]) {
    const { client, calls } = await relay(t, false, { name });
    await assert.rejects(client.quote(request), { code: name === null ? 'model_name_unavailable' : 'invalid_upstream_response' });
    assert.deepEqual(calls.map(x => x.method), ['GET']);
  }
});

test('quote snapshots inputs before asynchronous discovery', async t => {
  const { client, calls } = await relay(t);
  const mutable = structuredClone(request);
  const pending = client.quote(mutable);
  mutable.messages[0].content = 'Changed while discovery is pending';
  const invoice = await pending;
  assert.deepEqual(calls[1].body.messages, request.messages);
  await assert.rejects(client.infer(mutable, invoice, txid), { code: 'invoice_binding_changed' });
  await client.infer(request, invoice, txid);
});
