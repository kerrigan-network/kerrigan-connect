"""Launched by Node's real local HTTP contract harness; no pip dependencies."""
import os
import sys
import time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "integrations" / "python"))
from kerrigan_connect import ConnectClient, ConnectError

url, key = os.environ["KCONNECT_URL"], os.environ["KCONNECT_API_KEY"]
client = ConnectClient(base_url=url, api_key=key)
request = {"model": "demo/catalogue-v1", "messages": [{"role": "user", "content": "Hello"}], "max_tokens": 128}
assert client.models()["object"] == "list"
job = client.submit(request, "python-contract-001")
assert client.wait(job["id"])["status"] == "completed"
assert client.submit(request, "python-contract-001")["id"] == job["id"]


def fails(code, fn, status=None):
    try:
        fn()
    except ConnectError as error:
        assert error.code == code, (error.code, code)
        if status:
            assert error.status == status
        assert key not in str(error)
    else:
        raise AssertionError(f"Expected {code}")


fails("idempotency_conflict", lambda: client.submit({**request, "temperature": 1}, "python-contract-001"), 409)
fails("unsupported_parameter", lambda: client.submit({**request, "tools": []}, "python-tools-001"), 400)
fails("unauthorized", lambda: ConnectClient(base_url=url, api_key="wrong").models(), 401)
start = time.monotonic()
fails("deadline_exceeded", lambda: ConnectClient(base_url=os.environ["SLOW_URL"], api_key=key, timeout=.05).models())
assert time.monotonic() - start < 1
fails("deadline_exceeded", lambda: ConnectClient(base_url=os.environ["SLOW_SUBMIT_URL"], api_key=key, timeout=.05).submit(request, "python-lost-response-001"))
recovered = client.submit(request, "python-lost-response-001")
assert client.wait(recovered["id"])["status"] == "completed"
for route, code in [("large", "response_too_large"), ("invalid", "invalid_response"), ("redirect", "redirect_rejected"), ("dribble", "deadline_exceeded")]:
    fails(code, lambda: ConnectClient(base_url=os.environ["FAULT_URL"] + "/" + route, api_key=key, timeout=.1, max_response_bytes=100).models())
# wait must consume one total deadline, even when a single job read stalls.
start = time.monotonic()
fails("deadline_exceeded", lambda: ConnectClient(base_url=os.environ["FAULT_URL"] + "/dribble", api_key=key).wait(job["id"], timeout=.05))
assert time.monotonic() - start < 1
for invalid in (None, "short", "bad key 0001"):
    try:
        client.submit(request, invalid)
    except ValueError:
        pass
    else:
        raise AssertionError("Invalid key accepted")
print("Python HTTP contract: success replay conflict unauthorized timeout unsupported bounds redirect malformed wait-deadline passed")
