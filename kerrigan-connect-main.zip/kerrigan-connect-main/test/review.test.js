import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdtempSync, writeFileSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { promisify } from 'node:util';
import { execFile } from 'node:child_process';
import { createReview, validateReview, renderReview, exportReviewed } from '../src/review.js';
import { reviewLogic } from '../src/review-core.js';
import { DEFAULT_TAXONOMY } from '../src/catalogue.js';
import { fingerprint } from '../src/validation.js';
const rules = reviewLogic();
const fixture = () => createReview([
  { id: 'a', description: 'Blue ceramic mug 350 ml', status: 'accepted', category: 'Home & Kitchen', colour: 'blue', material: 'ceramic', size: '350 ml', simulated: true, net_cost_sats: 100 },
  { id: 'b', description: 'Black keyboard', status: 'review_required', error: 'invalid_json', simulated: null },
], { runId: 'review-test', model: 'demo/catalogue-v1', taxonomy: DEFAULT_TAXONOMY });

test('every new result starts pending and only explicitly approved rows are exported', () => {
  const s = fixture(); assert.ok(s.decisions.every(d => d.state === 'pending'));
  assert.equal(exportReviewed(s).trim().split('\r\n').length, 1);
  rules.decide(s, 'a', 'approved'); rules.decide(s, 'b', 'rejected');
  const csv = exportReviewed(s); assert.ok(csv.includes('Blue ceramic mug')); assert.ok(!csv.includes('Black keyboard'));
  assert.ok(csv.includes('"true"') && csv.includes(s.source_hash));
});
test('editing an approved value or note resets approval while preserving the original source', () => {
  const s = fixture(); const source = JSON.stringify(s.source);
  rules.decide(s, 'a', 'approved'); const values = { ...s.decisions[0].values, colour: '' };
  rules.update(s, 'a', values, ''); assert.equal(s.decisions[0].state, 'pending'); assert.equal(s.decisions[0].reviewed_at, null);
  rules.decide(s, 'a', 'approved'); rules.update(s, 'a', values, 'Colour omitted for now.'); assert.equal(s.decisions[0].state, 'pending');
  assert.equal(JSON.stringify(s.source), source);
});
test('approval blocks unsupported evidence and out-of-taxonomy categories, but permits a corrected failed result', () => {
  const s = fixture(); const bad = { ...s.decisions[0].values, material: 'gold' };
  rules.update(s, 'a', bad, ''); assert.throws(() => rules.decide(s, 'a', 'approved'), /literal evidence/);
  rules.update(s, 'a', { ...bad, material: 'ceramic', category: 'Made up' }, ''); assert.throws(() => rules.decide(s, 'a', 'approved'), /taxonomy/);
  rules.update(s, 'b', { category: 'Electronics', colour: 'black', material: '', size: '' }, 'Manually recovered.');
  rules.decide(s, 'b', 'approved'); assert.ok(exportReviewed(s).includes('Black keyboard'));
});
test('checkpoint restoration binds to the exact original source and rejects partial or duplicate decisions', () => {
  const s = fixture(), saved = fixture(); rules.decide(saved, 'a', 'approved'); rules.restore(s, saved); assert.equal(s.decisions[0].state, 'approved');
  const changed = fixture(); changed.source.rows[0].description = 'Changed'; changed.source_hash = fingerprint(changed.source);
  assert.throws(() => rules.restore(s, changed), /different source batch/);
  const duplicate = fixture(); duplicate.decisions[1] = duplicate.decisions[0]; assert.throws(() => rules.restore(s, duplicate), /Duplicate/);
  const partial = fixture(); partial.decisions.pop(); assert.throws(() => rules.restore(s, partial), /one decision/);
  assert.equal(s.decisions[0].state, 'approved');
});
test('CLI validates the source fingerprint and approved values on imported checkpoints', () => {
  const s = fixture(); s.source.rows[0].description = 'Tampered'; assert.throws(() => validateReview(s), /fingerprint/);
  const injected = fixture(); rules.decide(injected, 'a', 'approved'); injected.decisions[0].values.material = 'gold';
  assert.throws(() => exportReviewed(injected), /unsupported/);
});
test('review HTML cannot break out of the embedded payload and permits only its hashed script', () => {
  const s = fixture(); s.source.rows[0].description = '</script><img src=x onerror=alert(1)>'; s.source_hash = fingerprint(s.source);
  const html = renderReview(s); assert.equal((html.match(/<script>/g) || []).length, 1); assert.equal((html.match(/<\/script>/g) || []).length, 1);
  assert.ok(!html.includes('<img src=x'));
  const script = html.match(/<script>([\s\S]*)<\/script>/)[1];
  assert.ok(html.includes(`script-src 'sha256-${createHash('sha256').update(script).digest('base64')}'`));
  assert.ok(html.includes("connect-src 'none'"));
});
test('review CSV neutralises formulas in source fields and human notes', () => {
  const s = fixture(); s.source.rows[0].id = '=1+1'; s.decisions[0].id = '=1+1'; s.source_hash = fingerprint(s.source);
  rules.update(s, '=1+1', s.decisions[0].values, ' @SUM(1,2)'); rules.decide(s, '=1+1', 'approved');
  const csv = exportReviewed(s); assert.ok(csv.includes('"\'=1+1"')); assert.ok(csv.includes('"\' @SUM(1,2)"'));
});
test('CLI review export refuses unapproved data and preserves input while exporting reviewed rows', async t => {
  const dir = mkdtempSync(join(tmpdir(), 'kconnect-review-')); t.after(() => rmSync(dir, { recursive: true, force: true }));
  const input = join(dir, 'decisions.json'), output = join(dir, 'approved.csv'), html = join(dir, 'review.html');
  const s = fixture(); writeFileSync(input, JSON.stringify(s)); const exec = promisify(execFile);
  const cli = new URL('../src/cli.js', import.meta.url).pathname;
  await assert.rejects(exec(process.execPath, [cli,'export-reviewed','--input',input,'--output',output]), e => e.stderr.includes('No approved'));
  rules.decide(s, 'a', 'approved'); writeFileSync(input, JSON.stringify(s));
  await exec(process.execPath, [cli,'export-reviewed','--input',input,'--output',output]);
  assert.equal(readFileSync(output, 'utf8'), exportReviewed(s));
  await exec(process.execPath, [cli,'review','--input',input,'--output',html]); assert.ok(readFileSync(html, 'utf8').includes('Catalogue review'));
  await assert.rejects(exec(process.execPath, [cli,'review','--input',input,'--output',input]), e => e.stderr.includes('different files'));
  assert.deepEqual(JSON.parse(readFileSync(input, 'utf8')), s);
});
