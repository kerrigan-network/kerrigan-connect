import { Ledger } from '../src/ledger.js';
import { Gateway } from '../src/gateway.js';
import { DemoProvider, DemoPayments, DEMO_MODEL } from '../src/demo.js';

export const budgets = { dailyBudgetSats: 1_000_000, jobBudgetSats: 100_000, maxNetworkFeeSats: 1000 };
export const request = (extra = {}) => ({ model: DEMO_MODEL, messages: [{ role: 'user', content: 'Hello' }], max_tokens: 128, ...extra });
export function setup(t, options = {}) {
  const ledger = options.ledger || new Ledger();
  const provider = options.provider || new DemoProvider();
  const payments = options.payments || new DemoPayments();
  const gateway = new Gateway({ ledger, provider, payments, budgets, ...options });
  t.after(async () => { await gateway.stop(); ledger.close(); });
  return { ledger, provider, payments, gateway };
}
