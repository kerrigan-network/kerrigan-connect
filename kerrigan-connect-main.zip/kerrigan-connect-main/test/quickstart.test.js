import test from 'node:test';
import assert from 'node:assert/strict';
import { runQuickstart } from '../src/quickstart.js';

test('first-run check proves real HTTP, replay, SSE and restart using loopback only', async () => {
  const calls = [];
  const report = await runQuickstart({ fetchImpl: (url, opts) => {
    assert.equal(new URL(url).hostname, '127.0.0.1');
    calls.push({ url, key: opts.headers.authorization });
    return fetch(url, opts);
  } });
  assert.equal(report.passed, true);
  assert.equal(report.checks.length, 9);
  assert.equal(report.real_krgn_spent, 0);
  assert.ok(calls.length >= 9);
  assert.ok(!JSON.stringify(report).includes(calls.find(c => c.key).key));
  await assert.rejects(fetch(calls[0].url)); // server really stopped
});

test('first-run receipt fails when authentication is broken and sanitises transport errors', async () => {
  const authFailure = await runQuickstart({ fetchImpl: (url, opts) => !opts.headers.authorization && url.endsWith('/v1/models')
    ? Promise.resolve(new Response('{}', { status: 200 })) : fetch(url, opts) });
  assert.equal(authFailure.passed, false);
  assert.equal(authFailure.checks.at(-1).id, 'authentication');
  const broken = await runQuickstart({ fetchImpl: () => { throw new Error('secret-token-private-prompt'); } });
  assert.equal(broken.passed, false);
  assert.ok(!JSON.stringify(broken).includes('secret-token'));
});
