import test from 'node:test';
import assert from 'node:assert/strict';
import { parseNodeVersion, assertSupportedRuntime } from '../src/runtime.js';

test('runtime parser accepts supported Node 24 releases', () => {
  assert.deepEqual(parseNodeVersion('24.19.0'), [24, 19, 0]);
  assert.doesNotThrow(() => assertSupportedRuntime('24.14.0'));
  assert.doesNotThrow(() => assertSupportedRuntime('24.99.1'));
});

test('runtime guard fails clearly before unsupported installations run', () => {
  for (const version of ['23.11.0', '24.13.9', '25.0.0', 'garbage']) {
    assert.throws(() => assertSupportedRuntime(version), { code: 'unsupported_runtime' });
  }
});
