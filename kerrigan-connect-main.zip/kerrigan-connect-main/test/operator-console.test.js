import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { readFileSync } from 'node:fs';
import { setup } from './helpers.js';
import { createGatewayServer } from '../src/server.js';
import { operatorReport, validateOperatorDiagnostic } from '../src/operator-console.js';

const key = 'synthetic-operator-key-long-enough';
const supplied = () => JSON.parse(readFileSync(new URL('../fixtures/operator-diagnostic-v1.json', import.meta.url)));

async function endpoint(t, options = {}) {
  const state = setup(t, options);
  const server = createGatewayServer(state.gateway, { apiKey: key });
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  t.after(() => new Promise(resolve => server.close(resolve)));
  return { ...state, base: `http://127.0.0.1:${server.address().port}` };
}

test('operator assets are local, restrictive and contain no browser command or mutation controls', async t => {
  const { base } = await endpoint(t);
  const response = await fetch(`${base}/operator`), html = await response.text();
  assert.equal(response.status, 200);
  assert.match(response.headers.get('content-security-policy'), /default-src 'none'/);
  assert.match(html, /Read-only operator diagnostics/);
  for (const source of [html, await (await fetch(`${base}/operator/app.js`)).text()]) {
    assert.doesNotMatch(source, /child_process|exec\(|spawn\(|sudo |powershell|cmd\.exe/i);
  }
});

test('demo report labels simulation, local utilisation and registration mismatch without readiness inflation', async t => {
  const { gateway } = setup(t);
  const report = await operatorReport(gateway);
  assert.equal(report.models.source, 'supplied_demo');
  assert.equal(report.readiness.inference_service, 'simulated_only');
  assert.equal(report.compatibility.registration_contract, 'known_mismatch');
  assert.equal(report.compatibility.runtime_version, 'unknown');
  assert.equal(report.observed_utilisation.cost_kind, 'simulated');
  assert.equal(report.readiness.mining_does_not_establish_inference_readiness, true);
  assert.deepEqual(report.controls, { provider_registration: false, service_mutation: false, wallet_operations: false, browser_shell: false });
});

test('read-only discovery failure stays unknown and exposes no upstream detail', async t => {
  const { gateway } = setup(t, { mode: 'read-only', provider: { models: async () => { throw new Error('PRIVATE upstream route'); } }, payments: null });
  const report = await operatorReport(gateway);
  assert.equal(report.models.state, 'unknown');
  assert.equal(report.models.error_code, 'discovery_unavailable');
  assert.equal(report.readiness.inference_service, 'unknown');
  assert.doesNotMatch(JSON.stringify(report), /PRIVATE/);
});

test('supplied diagnostics are exact, bounded and never turn mining into inference readiness', async t => {
  const valid = supplied(); valid.drone.mining_detected = true; valid.drone.health.service = 'healthy'; valid.drone.models = ['model/one'];
  const parsed = validateOperatorDiagnostic(valid);
  assert.equal(parsed.drone.mining_detected, true);
  const { gateway } = setup(t, { mode: 'read-only', provider: { models: async () => [] }, payments: null });
  const report = await operatorReport(gateway, { supplied: valid });
  assert.equal(report.readiness.inference_service, 'supplied_unverified');
  assert.equal(report.readiness.mining, 'observed_supplied');
  assert.throws(() => validateOperatorDiagnostic({ ...valid, command: 'run-me' }), { code: 'invalid_operator_diagnostic' });
  valid.drone.utilisation.gpu_busy_percent = 101;
  assert.throws(() => validateOperatorDiagnostic(valid), { code: 'invalid_operator_diagnostic' });
});

test('authenticated HTTP diagnostics are read-only and bound failed-job disclosure', async t => {
  const { base, gateway, payments } = await endpoint(t);
  const { job } = gateway.submit({ model: 'demo/catalogue-v1', messages: [{ role: 'user', content: 'synthetic' }], max_tokens: 10 }, 'operator-failure-1');
  gateway.ledger.fail(job.id, { code: 'synthetic_failure', message: 'PRIVATE detail' });
  const unauthorised = await fetch(`${base}/connect/operator`);
  assert.equal(unauthorised.status, 401);
  const before = payments.payCalls;
  const response = await fetch(`${base}/connect/operator`, { headers: { Authorization: `Bearer ${key}` } });
  const report = await response.json();
  assert.equal(report.local_jobs.problems[0].error_code, 'synthetic_failure');
  assert.doesNotMatch(JSON.stringify(report), /PRIVATE detail/);
  const suppliedResponse = await fetch(`${base}/operator/api/supplied`, { method: 'POST', headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' }, body: JSON.stringify(supplied()) });
  assert.equal(suppliedResponse.status, 200);
  assert.equal(payments.payCalls, before);
  assert.equal(gateway.ledger.list().length, 1);
});
