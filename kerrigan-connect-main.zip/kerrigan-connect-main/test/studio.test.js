import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
import { randomUUID } from 'node:crypto';
import { createGatewayServer } from '../src/server.js';
import { prepareStudioBatch } from '../src/studio.js';
import { browserApp } from '../src/review-browser.js';
import { reviewLogic } from '../src/review-core.js';
import { DEMO_MODEL } from '../src/demo.js';
import { normalizeRequest } from '../src/validation.js';
import { setup } from './helpers.js';

const key = 'synthetic-studio-test-key-123456';
const checkpoint = () => ({ format: 'kconnect-studio-batch', version: 1, run_id: 'studio-test-1', model: DEMO_MODEL,
  taxonomy: ['Clothing', 'Home & Kitchen', 'Uncategorised'], csv: 'id,description\na,Blue cotton shirt size M\nb,White ceramic mug 350 ml\n' });
async function serverFor(t, options = {}) {
  const state = setup(t, options), server = createGatewayServer(state.gateway, { apiKey: key });
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  t.after(async () => { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); });
  const base = `http://127.0.0.1:${server.address().port}`;
  const call = (path, body, headers = {}) => fetch(base + path, { method: body === undefined ? 'GET' : 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json', ...headers },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
  return { ...state, base, call };
}

test('Studio serves only allowlisted assets; batch APIs require auth and reject hostile origins', async t => {
  const { base, call, payments } = await serverFor(t);
  for (const path of ['/studio', '/studio/', '/studio/app.js', '/studio/style.css', '/studio/review-core.js', '/studio/review-browser.js']) {
    const response = await fetch(base + path); assert.equal(response.status, 200);
    assert.match(response.headers.get('content-security-policy'), /frame-ancestors 'none'/);
    assert.match(response.headers.get('content-security-policy'), /script-src 'self'/);
    assert.ok(!(await response.text()).includes(key));
  }
  assert.equal((await fetch(base + '/studio/api/prepare', { method: 'POST' })).status, 401);
  assert.equal((await fetch(base + '/studio/ledger.js')).status, 401);
  assert.equal((await call('/studio/api/prepare', checkpoint(), { Origin: 'https://outside.example' })).status, 403);
  assert.equal((await call('/studio/api/prepare', { ...checkpoint(), csv: 'id,description\nx,a\nx,b' })).status, 400);
  assert.equal((await call('/studio/api/prepare', { ...checkpoint(), csv: 'x'.repeat(2_000_001) })).status, 400);
  assert.equal(payments.payCalls, 0);
});

test('Studio binds review to exact batch receipts and preserves replay and approved-only export', async t => {
  const { call, gateway, payments } = await serverFor(t);
  const first = await (await call('/studio/api/prepare', { ...checkpoint(), api_key: 'must-not-be-saved' })).json();
  assert.ok(!JSON.stringify(first).includes('must-not-be-saved'));
  const restored = await (await call('/studio/api/prepare', JSON.parse(JSON.stringify(first.checkpoint)))).json();
  assert.deepEqual(first, restored);
  const ids = [];
  for (const intent of first.intents) {
    const response = await call('/connect/jobs', intent.request, { 'Idempotency-Key': intent.key });
    assert.equal(response.status, 202);
    const job = await response.json(); ids.push(job.id); await gateway.wait(job.id);
  }
  for (const [i, intent] of restored.intents.entries()) {
    const response = await call('/connect/jobs', intent.request, { 'Idempotency-Key': intent.key });
    assert.equal(response.status, 200); assert.equal((await response.json()).id, ids[i]);
  }
  assert.equal(payments.payCalls, 2);
  const receipt = await (await call('/studio/api/review', { checkpoint: first.checkpoint, job_ids: ids })).json();
  assert.equal(receipt.accounting.simulated, true); assert.equal(receipt.accounting.unknown_rows, 0);
  assert.ok(receipt.accounting.recorded_sats > 0);
  const { session } = receipt, rules = reviewLogic();
  assert.ok(session.source.rows.every(row => row.simulated && row.status === 'accepted'));
  rules.decide(session, 'a', 'approved'); rules.decide(session, 'b', 'rejected');
  const csv = rules.csv(session); assert.ok(csv.includes('Blue cotton shirt') && !csv.includes('White ceramic mug'));
  assert.equal((await call('/studio/api/review', { checkpoint: first.checkpoint, job_ids: ids.toReversed() })).status, 409);
  const changed = { ...first.checkpoint, csv: first.checkpoint.csv.replace('Blue', 'Red') };
  assert.equal((await call('/studio/api/review', { checkpoint: changed, job_ids: ids })).status, 409);
  const changedIntent = prepareStudioBatch(changed).intents[0];
  assert.equal(changedIntent.key, first.intents[0].key);
  assert.equal((await call('/connect/jobs', changedIntent.request, { 'Idempotency-Key': changedIntent.key })).status, 409);
  assert.equal(payments.payCalls, 2);
});

test('Studio refuses incomplete receipts and reports uncertain final cost as unknown', async t => {
  const { call, ledger, gateway } = await serverFor(t);
  await gateway.stop(); // Hold the job before the background worker can claim it.
  const source = { ...checkpoint(), csv: 'id,description\na,Blue cotton shirt size M\n' };
  const intent = prepareStudioBatch(source).intents[0];
  const { job } = ledger.create(intent.key, normalizeRequest(intent.request));
  assert.equal((await call('/studio/api/review', { checkpoint: source, job_ids: [job.id] })).status, 409);
  ledger.reserve(job.id, { amount_sat: 10 }, { dailyBudgetSats: 1000, jobBudgetSats: 100, maxNetworkFeeSats: 2 });
  ledger.beginPayment(job.id); ledger.fail(job.id, new Error('Unknown payment outcome'));
  const result = await (await call('/studio/api/review', { checkpoint: source, job_ids: [job.id] })).json();
  assert.equal(result.session.source.rows[0].net_cost_sats, null);
  assert.equal(result.accounting.unknown_rows, 1); assert.equal(result.accounting.recorded_sats, 0);
  assert.equal(result.session.source.rows[0].simulated, true);
});

// Event-wiring and HTTP evidence only; this harness does not prove layout, CSP,
// native module loading, download policy or file-picker behaviour in a browser.
function page(base, fetcher = fetch) {
  const html = readFileSync(new URL('../src/studio/index.html', import.meta.url), 'utf8');
  const downloads = [], blobs = new Map();
  class Element {
    constructor(tag) { this.tag = tag; this.value = ''; this.children = []; this.listeners = {}; this.files = []; this.disabled = false; }
    append(...children) { this.children.push(...children); if (this.tag === 'select' && !this.value && children[0]) this.value = children[0].value; }
    replaceChildren(...children) { this.children = []; this.append(...children); }
    setAttribute() {}
    addEventListener(name, fn) { (this.listeners[name] ||= []).push(fn); }
    async fire(name) { for (const fn of this.listeners[name] || []) await fn({ target: this }); }
    click() { if (this.tag === 'a') downloads.push({ name: this.download, blob: blobs.get(this.href) }); else if (!this.disabled) return this.fire('click'); }
    scrollIntoView() {}
  }
  const elements = Object.fromEntries([...html.matchAll(/<([a-z][a-z0-9]*)\b[^>]*\bid="([^"]+)"/g)].map(m => [m[2], new Element(m[1])]));
  elements['review-template'].content = { cloneNode: () => new Element('fragment') };
  elements.taxonomy.value = 'Electronics\nClothing\nHome & Kitchen\nSports & Outdoors\nUncategorised';
  elements.filter.value = 'all';
  const source = readFileSync(new URL('../src/studio/app.js', import.meta.url), 'utf8').replace(/^import .*;\n/gm, '');
  runInNewContext(`const browserApp = ${browserApp.toString()}; const reviewLogic = ${reviewLogic.toString()};\n${source}`, {
    document: { getElementById: id => { assert.ok(elements[id], `Missing ${id}`); return elements[id]; }, createElement: tag => new Element(tag) },
    Blob, structuredClone, AbortSignal, crypto: { randomUUID },
    URL: { createObjectURL: blob => { const id = `blob:${blobs.size}`; blobs.set(id, blob); return id; }, revokeObjectURL() {} },
    setTimeout: (fn, delay) => { if (delay < 1000) return setTimeout(fn, 1); }, addEventListener() {},
    fetch: (path, options) => fetcher(base + path, options),
  });
  elements['gateway-key'].value = key;
  return { elements, downloads };
}

test('Studio UI recovers a lost submit response using its downloaded batch, then reviews and exports', async t => {
  const { base, payments } = await serverFor(t);
  let lost = false;
  const first = page(base, async (url, options) => {
    const response = await fetch(url, options);
    if (url.endsWith('/connect/jobs') && !lost) { lost = true; await response.text(); throw new Error('Synthetic lost response'); }
    return response;
  });
  const e = first.elements;
  await e.connect.click(); assert.equal(e['gateway-key'].value, '');
  await e.sample.click(); await e.prepare.click(); assert.equal(e.process.disabled, true);
  await e['batch-save'].click();
  const saved = await first.downloads[0].blob.text(); assert.ok(!saved.includes(key));
  await e.process.click(); assert.match(e['studio-error'].textContent, /Synthetic lost response/);
  assert.match(e['progress-status'].textContent, /lost response does not prove/);
  const resumed = page(base), r = resumed.elements;
  await r.connect.click(); r['batch-restore'].files = [{ size: saved.length, text: async () => saved }];
  await r['batch-restore'].fire('change'); await r.process.click();
  assert.equal(r.progress.value, 6); assert.equal(payments.payCalls, 6);
  await r['open-review'].click(); assert.equal(r['count-pending'].textContent, 6);
  await r.approve.click(); await r.next.click(); await r.reject.click();
  await r.export.click(); const csv = await resumed.downloads.at(-1).blob.text();
  assert.ok(csv.includes('tee-01') && !csv.includes('mug-02'));
  await r.save.click(); const decisions = JSON.parse(await resumed.downloads.at(-1).blob.text());
  assert.equal(decisions.decisions[0].state, 'approved'); assert.equal(decisions.decisions[1].state, 'rejected');
});

test('Studio read-only UI permits preparation but never enables processing', async t => {
  const { base, payments } = await serverFor(t, { mode: 'read-only' });
  const { elements: e } = page(base);
  await e.connect.click(); await e.sample.click(); await e.prepare.click(); await e['batch-save'].click();
  assert.equal(e.process.disabled, true); assert.match(e['connection-status'].textContent, /read-only/);
  assert.equal(payments.payCalls, 0);
});
