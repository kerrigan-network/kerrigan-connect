import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { Ledger } from '../src/ledger.js';
import {
  KERRIGAN_SDK_REVISION, LoopbackPaymentBridge, MaintainedSdkPaymentPreparer, PreparedPaymentRecovery,
} from 'kerrigan-connect/integration';
import { DemoProvider } from '../src/demo.js';
import { normalizeRequest } from '../src/validation.js';
import { request, budgets } from './helpers.js';

const txHex = '01020304';
const txid = Buffer.from(createHash('sha256').update(createHash('sha256').update(Buffer.from(txHex, 'hex')).digest()).digest()).reverse().toString('hex');
const utxo = { txid: 'b'.repeat(64), vout: 2, amount: 50_000, script_pubkey: `76a914${'c'.repeat(40)}88ac` };
const signed = { txid, tx_hex: txHex, fee: 100, spent_utxos: [[utxo.txid, utxo.vout]] };
const session = { utxos: [utxo], seed: new Uint8Array(64).fill(7), account: 4, index: 9 };

async function inputs() {
  const normalized = normalizeRequest(request());
  const invoice = { ...(await new DemoProvider().quote(normalized)), pay_to_address: `K${'a'.repeat(33)}` };
  return { request: normalized, invoice };
}

test('adapter pins the maintained SDK revision and maps exact wallet arguments', async () => {
  assert.equal(KERRIGAN_SDK_REVISION, 'ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29');
  const { request: normalized, invoice } = await inputs();
  const calls = [];
  const sdk = {
    init: async () => calls.push(['init']),
    buildInferencePaymentTx: (...args) => { calls.push(args); return signed; },
  };
  const prepare = new MaintainedSdkPaymentPreparer({ sdk, withSigningSession: callback => callback(session) });
  assert.deepEqual(await prepare.prepare({ request: normalized, invoice }), signed);
  assert.deepEqual(await prepare.prepare({ request: normalized, invoice }), signed);
  assert.deepEqual(calls[0], ['init']);
  assert.equal(calls.filter(x => x[0] === 'init').length, 1);
  const [passedUtxos, passedInvoice, params, passedSeed, account, index] = calls[1];
  assert.deepEqual(passedUtxos, [utxo]);
  assert.deepEqual(passedInvoice, {
    pay_to_address: invoice.pay_to_address, amount_sat: invoice.amount_sat,
    drone_pubkey_hash: invoice.drone_pubkey_hash, model_hash: invoice.model_hash, max_tokens: invoice.max_tokens,
  });
  assert.deepEqual(params, { temperature: normalized.temperature, topP: normalized.top_p, seed: normalized.seed, k: normalized.k });
  assert.equal(passedSeed, session.seed); assert.equal(account, 4); assert.equal(index, 9);
});

test('adapter rejects mismatches before opening an owner-controlled signing session', async () => {
  const { request: normalized, invoice } = await inputs();
  let sessions = 0;
  const prepare = new MaintainedSdkPaymentPreparer({
    sdk: { init: async () => {}, buildInferencePaymentTx: () => signed },
    withSigningSession: async callback => { sessions++; return callback(session); },
  });
  await assert.rejects(prepare.prepare({ request: { ...normalized, max_tokens: normalized.max_tokens + 1 }, invoice }), { code: 'invoice_binding_changed' });
  await assert.rejects(prepare.prepare({ request: normalized, invoice: { ...invoice, model_hash: 'x'.repeat(16) } }), { code: 'invalid_invoice' });
  assert.equal(sessions, 0);
});

test('adapter rejects inconsistent SDK output and sanitizes signer failures', async () => {
  const args = await inputs();
  for (const bad of [
    { ...signed, txid: 'a'.repeat(64) },
    { ...signed, spent_utxos: [['d'.repeat(64), 0]] },
    { ...signed, spent_utxos: [signed.spent_utxos[0], signed.spent_utxos[0]] },
  ]) {
    const prepare = new MaintainedSdkPaymentPreparer({ sdk: { init: async () => {}, buildInferencePaymentTx: () => bad }, withSigningSession: callback => callback(session) });
    await assert.rejects(prepare.prepare(args), { code: 'invalid_prepared_payment' });
  }
  const failed = new MaintainedSdkPaymentPreparer({
    sdk: { init: async () => {}, buildInferencePaymentTx: () => { throw Error('PRIVATE WALLET DETAIL'); } },
    withSigningSession: callback => callback(session),
  });
  await assert.rejects(failed.prepare(args), error => error.code === 'payment_preparation_failed' && !error.message.includes('PRIVATE'));
});

test('owner-controlled session must invoke the signer exactly once', async () => {
  const args = await inputs();
  for (const withSigningSession of [
    async () => signed,
    async callback => { await callback(session); return callback(session); },
  ]) {
    const prepare = new MaintainedSdkPaymentPreparer({ sdk: { init: async () => {}, buildInferencePaymentTx: () => signed }, withSigningSession });
    await assert.rejects(prepare.prepare(args), { code: 'invalid_wallet_session' });
  }
});

test('SDK adapter plugs into durable preparation and loopback broadcast end to end', async t => {
  const ledger = new Ledger(); t.after(() => ledger.close());
  const args = await inputs();
  const job = ledger.create('sdk-adapter-flow-01', args.request).job;
  ledger.reserve(job.id, args.invoice, budgets); ledger.beginPayment(job.id);
  const received = [];
  const http = createServer(async (req, res) => {
    let body = ''; for await (const chunk of req) body += chunk;
    received.push({ method: req.method, path: req.url, body }); res.end(txid);
  });
  http.listen(0, '127.0.0.1'); await once(http, 'listening');
  t.after(() => new Promise(resolve => http.close(resolve)));
  const sdkPrepare = new MaintainedSdkPaymentPreparer({
    sdk: { init: async () => {}, buildInferencePaymentTx: () => signed },
    withSigningSession: callback => callback(session),
  });
  const payments = new PreparedPaymentRecovery({
    ledger, prepare: value => sdkPrepare.prepare(value),
    bridge: new LoopbackPaymentBridge(`http://127.0.0.1:${http.address().port}`),
    getRawTransaction: async () => txHex, getCurrentBlock: async () => ({ height: 100, hash: 'f'.repeat(64) }),
  });
  const receipt = await payments.pay({ jobId: job.id, ...args });
  assert.equal(receipt.txid, txid);
  assert.deepEqual(received, [{ method: 'POST', path: '/sendrawtransaction', body: txHex }]);
  assert.deepEqual(ledger.preparedPayment(job.id).spent_utxos, signed.spent_utxos);
});
