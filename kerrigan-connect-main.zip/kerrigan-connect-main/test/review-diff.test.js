import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { promisify } from 'node:util';
import { execFile } from 'node:child_process';
import { compareReviews, renderReviewDiff } from '../src/review-diff.js';
import { reviewLogic } from '../src/review-core.js';
import { fingerprint } from '../src/validation.js';
const baseline = () => JSON.parse(readFileSync(new URL('../examples/catalogue-demo.review.json', import.meta.url), 'utf8'));
const rules = reviewLogic();

test('review comparison distinguishes edits, approval additions and approval removals', () => {
  const a = baseline(); rules.decide(a, 'SKU-001', 'approved', '2026-09-25T12:00:00Z');
  const b = structuredClone(a);
  rules.update(b, 'SKU-001', {...b.decisions[0].values, material: ''}, 'Remove unsupported detail');
  rules.decide(b, 'SKU-002', 'approved'); rules.decide(b, 'SKU-003', 'rejected');
  const report = compareReviews(a,b);
  assert.equal(report.summary.changed_products, 3); assert.equal(report.summary.unchanged_products, 3);
  assert.equal(report.summary.newly_approved, 1); assert.equal(report.summary.approval_removed, 1);
  assert.equal(report.summary.edited_products, 1); assert.equal(report.summary.after.approved, 1);
  assert.equal(report.baseline_checkpoint_sha256, fingerprint(a));
});
test('review comparison refuses another source batch and handles reordered decisions', () => {
  const a = baseline(), b = structuredClone(a); b.decisions.reverse();
  assert.equal(compareReviews(a,b).summary.changed_products, 0);
  b.source.run_id = 'different'; b.source_hash = fingerprint(b.source);
  assert.throws(() => compareReviews(a,b), /exact same source/);
});
test('review comparison flags edited approved data retaining an old approval timestamp', () => {
  const a = baseline(); rules.decide(a, 'SKU-001', 'approved');
  const b = structuredClone(a); b.decisions[0].note = 'Manually altered after approval';
  assert.equal(compareReviews(a,b).summary.approval_warnings, 1);
});
test('Markdown report escapes notes and product identifiers that could alter report markup', () => {
  const a = baseline(), b = structuredClone(a);
  rules.update(b, 'SKU-001', b.decisions[0].values, '<img src=x> | [click](https://bad.example)\n# heading');
  const md = renderReviewDiff(compareReviews(a,b));
  assert.ok(md.includes('&lt;img') && md.includes('&#124;') && !md.includes('<img') && !md.includes('\n# heading'));
  assert.ok(renderReviewDiff(compareReviews(a,a)).includes('No differences'));
});
test('review-diff CLI writes both reports, flags suspicious approvals and protects its inputs', async t => {
  const dir = mkdtempSync(join(tmpdir(),'kconnect-diff-')); t.after(()=>rmSync(dir,{recursive:true,force:true}));
  const a = baseline(); rules.decide(a, 'SKU-001','approved'); const b = structuredClone(a); b.decisions[0].note = 'Changed';
  const oldPath=join(dir,'old.json'), newPath=join(dir,'new.json'), report=join(dir,'report.json');
  writeFileSync(oldPath,JSON.stringify(a)); writeFileSync(newPath,JSON.stringify(b));
  const cli = new URL('../src/cli.js',import.meta.url).pathname, exec=promisify(execFile);
  const args=[cli,'review-diff','--baseline',oldPath,'--input',newPath,'--output',report];
  await assert.rejects(exec(process.execPath,args),e=>e.code===2);
  assert.equal(JSON.parse(readFileSync(report,'utf8')).summary.approval_warnings,1);
  assert.ok(readFileSync(`${report}.md`,'utf8').includes('CHECK TIMESTAMP'));
  args[args.length-1]=oldPath;
  await assert.rejects(exec(process.execPath,args),e=>e.stderr.includes('different files'));
  assert.deepEqual(JSON.parse(readFileSync(oldPath,'utf8')),a);
});
