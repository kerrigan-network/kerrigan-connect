import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { mkdtempSync, readFileSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { execFileSync, spawnSync } from 'node:child_process';
import { createGatewayServer } from '../src/server.js';
import { ConnectClient } from '../src/client.js';
import { DemoProvider, DemoPayments, DEMO_MODEL } from '../src/demo.js';
import { setup } from './helpers.js';
import { validateDataset, validateTaskOutput, taskRequest, intentKey, runTaskPack,
  createTaskReview, validateTaskReview, decideTask, exportApprovedTasks } from '../src/task-packs.js';

const support = JSON.parse(readFileSync(new URL('../examples/task-packs/support-triage.json', import.meta.url)));
const documents = JSON.parse(readFileSync(new URL('../examples/task-packs/document-extraction.json', import.meta.url)));
const API_KEY = 'task-pack-test-key-123456789';
async function endpoint(t, provider = new DemoProvider(), payments = new DemoPayments()) {
  const state = setup(t, { provider, payments });
  const server = createGatewayServer(state.gateway, { apiKey: API_KEY });
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  t.after(async () => { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); });
  return { ...state, client: new ConnectClient({ baseUrl: `http://127.0.0.1:${server.address().port}`, apiKey: API_KEY }) };
}

test('both labelled synthetic datasets are valid and fixture runs are explicit', async () => {
  for (const dataset of [support, documents]) {
    assert.equal(validateDataset(dataset, dataset.pack), dataset);
    const report = await runTaskPack({ dataset, runId: `fixture-${dataset.pack}`, mode: 'fixture' });
    assert.equal(report.execution, 'fixture'); assert.ok(report.rows.every(r => r.validation.accepted));
    assert.ok(report.rows.every(r => r.execution.labelled_expected_output && r.job_id === null));
    assert.match(report.note, /no model or endpoint/i);
  }
});

test('validators reject hallucinated evidence, extra fields and missing-field contradictions', () => {
  const s = structuredClone(support.cases[0]);
  s.expected.evidence = 'not in source'; assert.deepEqual(validateTaskOutput(support.pack, s.expected, s.source), { accepted: false, reason: 'unsupported_evidence', field: 'evidence' });
  s.expected = { ...support.cases[0].expected, secret: 'extra' }; assert.equal(validateTaskOutput(support.pack, s.expected, s.source).reason, 'invalid_schema');
  const d = structuredClone(documents.cases[2]); d.expected.fields.currency = 'GBP'; d.expected.evidence.currency = null; d.expected.missing_fields = ['supplier'];
  assert.equal(validateTaskOutput(documents.pack, d.expected, d.source).reason, 'unsupported_evidence');
  const d2 = structuredClone(documents.cases[2]); d2.expected.missing_fields = [];
  assert.equal(validateTaskOutput(documents.pack, d2.expected, d2.source).reason, 'missing_field_mismatch');
  assert.throws(() => validateDataset({ ...support, cases: [support.cases[0], support.cases[0]] }, support.pack), { code: 'invalid_dataset' });
});

test('prompt templates treat source as data and never include expected labels', () => {
  for (const dataset of [support, documents]) {
    const item = dataset.cases[0], request = taskRequest(dataset.pack, item, { model: DEMO_MODEL });
    const body = JSON.parse(request.messages[1].content);
    assert.deepEqual(body, { task: dataset.pack, case_id: item.id, source: item.source });
    assert.ok(!request.messages.some(m => m.content.includes(JSON.stringify(item.expected))));
    assert.match(request.messages[0].content, /untrusted data/); assert.equal(request.temperature, 0);
  }
});

test('both packs execute over a real authenticated gateway and replay without duplicate intents', async t => {
  const provider = new DemoProvider(), payments = new DemoPayments();
  const { client } = await endpoint(t, provider, payments);
  for (const dataset of [support, documents]) {
    const args = { dataset, client, model: DEMO_MODEL, runId: `http-${dataset.pack}`, mode: 'endpoint' };
    const first = await runTaskPack(args), paid = payments.payCalls, replay = await runTaskPack(args);
    assert.ok(first.rows.every(r => r.validation.accepted && r.execution.kind === 'endpoint' && r.execution.simulated));
    assert.deepEqual(replay.rows.map(r => r.job_id), first.rows.map(r => r.job_id)); assert.equal(payments.payCalls, paid);
    assert.deepEqual(replay.rows.map(r => r.intent_key), first.rows.map(r => r.intent_key));
  }
  assert.equal(payments.payCalls, support.cases.length + documents.cases.length);
});

test('endpoint contract omits labels and changed source with same run/case key conflicts', async t => {
  const seen = [];
  class RecordingProvider extends DemoProvider {
    async infer(request, invoice) { seen.push(request.messages.at(-1).content); return super.infer(request, invoice); }
  }
  const { client } = await endpoint(t, new RecordingProvider());
  const one = { ...support, cases: [support.cases[0]] };
  await runTaskPack({ dataset: one, client, model: DEMO_MODEL, runId: 'same-run', mode: 'endpoint' });
  assert.equal(seen.length, 1); assert.ok(!seen[0].includes('expected'));
  const changed = structuredClone(one); changed.cases[0].source += ' Changed.';
  changed.cases[0].expected.evidence = 'Changed.';
  await assert.rejects(runTaskPack({ dataset: changed, client, model: DEMO_MODEL, runId: 'same-run', mode: 'endpoint' }), { code: 'idempotency_conflict' });
  assert.equal(seen.length, 1);
});

test('intent keys are stable, bounded and separate packs/runs', () => {
  const a = intentKey('run-1', 'support-triage', 'case-1');
  assert.equal(a, intentKey('run-1', 'support-triage', 'case-1')); assert.ok(a.length <= 160);
  assert.notEqual(a, intentKey('run-2', 'support-triage', 'case-1'));
  assert.notEqual(a, intentKey('run-1', 'document-extraction', 'case-1'));
  assert.throws(() => intentKey('bad run', 'support-triage', 'case-1'), { code: 'invalid_run_id' });
});

test('unlabelled endpoint inputs work for both packs and replay independently of local labels', async t => {
  const seen = [];
  class RecordingProvider extends DemoProvider {
    async infer(request, invoice) { seen.push(JSON.parse(request.messages.at(-1).content)); return super.infer(request, invoice); }
  }
  const payments = new DemoPayments();
  const { client } = await endpoint(t, new RecordingProvider(), payments);
  for (const labelled of [support, documents]) {
    const dataset = { ...labelled, cases: labelled.cases.map(({ id, source }) => ({ id, source })) };
    const args = { dataset, client, model: DEMO_MODEL, runId: `unlabelled-${dataset.pack}`, mode: 'endpoint' };
    const report = await runTaskPack(args);
    assert.ok(report.rows.every(row => row.expected === null && row.validation.accepted));
    assert.ok(report.rows.every(row => row.execution.simulated && !row.execution.labelled_expected_output));
    const paid = payments.payCalls;
    const replay = await runTaskPack({ ...args, dataset: labelled });
    assert.deepEqual(replay.rows.map(row => row.job_id), report.rows.map(row => row.job_id));
    assert.equal(payments.payCalls, paid);
    const review = createTaskReview(report);
    assert.throws(() => exportApprovedTasks(review), { code: 'nothing_approved' });
    const approved = decideTask(review, dataset.cases[0].id, { decision: 'approved', reviewer: 'Test Reviewer' });
    assert.equal(JSON.parse(exportApprovedTasks(approved)).id, dataset.cases[0].id);
  }
  assert.ok(seen.every(body => Object.keys(body).sort().join(',') === 'case_id,source,task'));
});

test('unlabelled fixtures and malformed optional labels fail before any endpoint submission', async () => {
  const unlabelled = { ...support.cases[0] }; delete unlabelled.expected;
  const dataset = { ...support, cases: [support.cases[0], unlabelled] };
  dataset.cases[1] = { ...unlabelled, id: 'unlabelled-002' };
  assert.equal(validateDataset(dataset, support.pack), dataset);
  await assert.rejects(runTaskPack({ dataset, mode: 'fixture', runId: 'no-labels' }), { code: 'invalid_dataset' });
  let submitted = 0;
  const client = { submit() { submitted++; }, wait() {} };
  for (const item of [null, { ...unlabelled, extra: true },
    ...[null, undefined, false, {}, { ...support.cases[0].expected, evidence: 'invented quote' }].map(expected => ({ ...unlabelled, expected }))]) {
    await assert.rejects(runTaskPack({ dataset: { ...support, cases: [item] }, client,
      model: DEMO_MODEL, mode: 'endpoint', runId: 'malformed-label' }), { code: 'invalid_dataset' });
  }
  assert.equal(submitted, 0);
});

test('review defaults pending, invalid output cannot be approved, and export includes approved only', async () => {
  const run = await runTaskPack({ dataset: support, runId: 'review-fixture', mode: 'fixture' });
  const review = createTaskReview(run); assert.ok(review.cases.every(c => c.decision === 'pending'));
  assert.throws(() => exportApprovedTasks(review), { code: 'nothing_approved' });
  let decided = decideTask(review, 'support-001', { decision: 'approved', reviewer: 'Human One', notes: 'Evidence checked.', now: '2026-09-25T20:00:00Z' });
  decided = decideTask(decided, 'support-002', { decision: 'rejected', reviewer: 'Human One', notes: 'Needs rewrite.', now: '2026-09-25T20:01:00Z' });
  const lines = exportApprovedTasks(decided).trim().split('\n').map(JSON.parse);
  assert.deepEqual(lines.map(x => x.id), ['support-001']); assert.equal(lines[0].provenance.execution, 'fixture');
  assert.equal(lines[0].provenance.simulated, true);
  const tampered = structuredClone(decided); tampered.cases[0].output.summary = 'changed';
  assert.throws(() => validateTaskReview(tampered), { code: 'review_source_changed' });
  const changedReviewer = structuredClone(decided); changedReviewer.cases[0].reviewer = 'Someone Else';
  assert.throws(() => validateTaskReview(changedReviewer), { code: 'approval_changed' });
  const handApproved = structuredClone(review); Object.assign(handApproved.cases[0], { decision: 'approved', reviewer: 'Human One', reviewed_at: '2026-09-25T20:00:00Z' });
  assert.throws(() => validateTaskReview(handApproved), { code: 'approval_changed' });
  const invalid = createTaskReview({ ...run, rows: [{ ...run.rows[0], output: { bad: true } }] });
  assert.throws(() => decideTask(invalid, 'support-001', { decision: 'approved', reviewer: 'Human One' }), { code: 'approval_invalid' });
});

test('fixture, review, decision and export CLI work without network and protect inputs', t => {
  const dir = mkdtempSync(join(tmpdir(), 'task-packs-')); t.after(() => rmSync(dir, { recursive: true, force: true }));
  for (const [name, dataset] of [['support', support], ['documents', documents]]) {
    const input = join(dir, `${name}.json`), result = join(dir, `${name}.result.json`), review = join(dir, `${name}.review.json`), approved = join(dir, `${name}.approved.json`), exported = join(dir, `${name}.jsonl`);
    writeFileSync(input, JSON.stringify(dataset));
    const stdout = execFileSync(process.execPath, ['src/cli.js','task-run','--fixture','--input',input,'--output',result,'--run-id',`cli-${name}`], { encoding: 'utf8' });
    assert.equal(JSON.parse(stdout).accepted, dataset.cases.length);
    execFileSync(process.execPath, ['src/cli.js','task-review','--input',result,'--output',review]);
    assert.notEqual(spawnSync(process.execPath, ['src/cli.js','task-export','--input',review,'--output',exported]).status, 0);
    execFileSync(process.execPath, ['src/cli.js','task-decide','--input',review,'--output',approved,'--case-id',dataset.cases[0].id,'--decision','approved','--reviewer','Test Reviewer']);
    execFileSync(process.execPath, ['src/cli.js','task-export','--input',approved,'--output',exported]);
    assert.equal(readFileSync(exported, 'utf8').trim().split('\n').length, 1);
    assert.notEqual(spawnSync(process.execPath, ['src/cli.js','task-review','--input',result,'--output',result]).status, 0);
  }
});
