import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { evaluate, validateDataset, renderReport } from '../src/evaluation.js';
import { assessReadiness } from '../src/readiness.js';
import { processCatalogue } from '../src/catalogue.js';
import { DEMO_MODEL } from '../src/demo.js';
import { setup } from './helpers.js';
const dataset = JSON.parse(readFileSync(new URL('../examples/catalogue-benchmark.json', import.meta.url)));
const exec = promisify(execFile);
const root = new URL('../', import.meta.url).pathname;
const goodRows = () => dataset.cases.map(c => ({ id: c.id, status: 'accepted', category: c.expected.category, ...c.expected.attributes, simulated: false, net_cost_sats: 20 }));

test('evaluation keeps missing and failed jobs in denominators and distinguishes unknown costs', () => {
  const rows = goodRows(); rows.pop(); rows[0].status = 'review_required'; rows[0].net_cost_sats = undefined;
  const r = evaluate(dataset, rows);
  assert.equal(r.metrics.category_accuracy.correct, 14);
  assert.equal(r.metrics.category_accuracy.total, 16);
  assert.equal(r.cost.unknown_cases, 2);
  assert.equal(r.cost.complete, false);
  assert.equal(r.execution, 'mixed_or_unknown');
  assert.equal(r.confusion.flatMap(c => Object.values(c.counts)).reduce((a,b) => a+b), 16);
});
test('evaluation counts null labels but separately scores populated attribute extraction', () => {
  const rows = goodRows(); rows[0].colour = null;
  const r = evaluate(dataset, rows);
  assert.equal(r.metrics.category_accuracy.rate, 1);
  assert.equal(r.metrics.exact_match.correct, 15);
  assert.equal(r.metrics.attributes.colour.correct, 15);
  assert.equal(r.metrics.populated_attribute_accuracy.correct, r.metrics.populated_attribute_accuracy.total - 1);
  assert.equal(r.execution, 'live');
});
test('evaluation rejects duplicate and foreign result IDs and invalid labels', () => {
  assert.throws(() => evaluate(dataset, [goodRows()[0], goodRows()[0]]), /duplicate/);
  assert.throws(() => evaluate(dataset, [{ id: 'foreign-id' }]), /unknown/);
  const bad = structuredClone(dataset); bad.cases[0].expected.category = 'Invented';
  assert.throws(() => validateDataset(bad), /labelled attributes/);
  bad.cases[0] = bad.cases[1]; assert.throws(() => validateDataset(bad), /unique/);
});
test('HTML report escapes customer content and disables scripts and external resources', () => {
  const custom = structuredClone(dataset); custom.name = '<script>alert(1)</script>';
  custom.cases[0].description = '<img src=x onerror=alert(1)>';
  const html = renderReport(evaluate(custom, goodRows()));
  assert.ok(!html.includes('<script>') && !html.includes('<img'));
  assert.ok(html.includes('&lt;script&gt;') && html.includes("default-src 'none'"));
});
test('offline benchmark sends no answer labels and exposes deterministic classifier weaknesses', async t => {
  const { gateway } = setup(t);
  const client = { submit: async (body, key) => {
    const payload = JSON.parse(body.messages[1].content);
    assert.deepEqual(Object.keys(payload.product).sort(), ['description','id']);
    return gateway.submit(body, key).job;
  }, wait: id => gateway.wait(id) };
  const rows = await processCatalogue({ products: dataset.cases.map(({ id, description }) => ({ id, description })), client, model: DEMO_MODEL, runId: 'evaluation-test-v1', taxonomy: dataset.taxonomy });
  const r = evaluate(dataset, rows);
  assert.equal(r.execution, 'simulation');
  assert.equal(r.metrics.schema_accepted.correct, 16);
  assert.equal(r.metrics.category_accuracy.correct, 13);
  assert.equal(r.metrics.exact_match.correct, 12);
  assert.equal(r.cases.find(c => c.id === 'injection').category_correct, true);
});
const now = Date.parse('2026-09-25T12:00:00Z');
const probe = () => ({ observed_at: new Date(now).toISOString(), models: [{ id: 'test-model', x_kerrigan: { drones: ['a'], context_length: 16384 } }], connected_drones: 1, chain: { height: 100, drone_payout_active: false }, errors: [] });
test('healthy discovery never enables payments or claims confidentiality', () => {
  const r = assessReadiness(probe(), { now });
  assert.equal(r.discovery_ready, true); assert.equal(r.live_inference_ready, false); assert.equal(r.spending_enabled, false);
  assert.equal(r.checks.find(c => c.id === 'confidentiality').status, 'unknown');
  assert.equal(r.drone_block_payout_active, false);
});
test('doctor rejects stale and future snapshots and unavailable model scopes', () => {
  for (const observed_at of ['bad', new Date(now - 300001).toISOString(), new Date(now + 60001).toISOString()]) {
    assert.equal(assessReadiness({ ...probe(), observed_at }, { now, snapshot: true }).discovery_ready, false);
  }
  assert.equal(assessReadiness(probe(), { now, model: 'missing' }).discovery_ready, false);
  assert.equal(assessReadiness({ ...probe(), models: null, connected_drones: null, chain: null }, { now }).checks.find(c => c.id === 'model').status, 'unknown');
});
test('benchmark CLI emits reviewable reports and returns exit 2 for a failed quality gate', async t => {
  const dir = mkdtempSync(join(tmpdir(), 'kconnect-eval-')); t.after(() => rmSync(dir, { recursive: true, force: true }));
  const output = join(dir, 'report.json');
  await assert.rejects(exec(process.execPath, ['src/cli.js','benchmark','--output',output,'--min-accuracy','0.9'], { cwd: root }), error => error.code === 2);
  const report = JSON.parse(readFileSync(output, 'utf8'));
  assert.equal(report.execution, 'simulation'); assert.equal(report.quality_gate.passed, false);
  assert.ok(readFileSync(`${output}.html`, 'utf8').includes('SIMULATION'));
  assert.ok(readFileSync(`${output}.csv`, 'utf8').includes('review_required') === false);
  await assert.rejects(exec(process.execPath, ['src/cli.js','benchmark','--min-accuracy','no'], { cwd: root }), error => error.code === 1);
});
