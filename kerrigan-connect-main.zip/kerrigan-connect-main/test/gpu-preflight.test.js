import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { assessGpuPreflight, collectLocalNvidiaInventory, parseNvidiaSmi, renderGpuPreflight, validateGpuInventory } from '../src/gpu-preflight.js';

const inventory = (extra = {}) => ({
  format_version: 1, collected_at: '2026-09-25T21:00:00.000Z', source: 'supplied', os: 'linux', arch: 'x64',
  tooling: { nvidia_smi: 'present' },
  gpus: [{ index: 0, vendor: 'nvidia', product_name: 'Example GPU', memory_total_mb: 12288, driver_version: '580.82.07' }],
  ...extra,
});
const models = (vram = 8192) => ({ observed_at: '2026-09-25T20:00:00.000Z', models: [{ id: 'example/model-q4', x_kerrigan: { vram_required_mb: vram } }] });

test('compares only advertised model memory and leaves operational compatibility unknown', () => {
  const report = assessGpuPreflight(inventory(), { modelSnapshot: models(), generatedAt: '2026-09-25T21:01:00Z' });
  assert.equal(report.diagnostic_status, 'unknown');
  assert.equal(report.checks.model_memory[0].status, 'meets_advertised_memory');
  assert.match(report.checks.model_memory[0].source, /kerrigan-network\/kerrigan-sdk\/blob\/ae6ca83/);
  assert.deepEqual(report.checks.model_memory[0].matching_gpu_indexes, [0]);
  assert.ok(report.checks.operational_compatibility.every(check => check.status === 'unknown'));
  assert.match(renderGpuPreflight(report), /not proof of provider readiness/i);
});

test('known absent GPU and insufficient advertised memory are blockers', () => {
  const absent = assessGpuPreflight(inventory({ gpus: [], tooling: { nvidia_smi: 'not_checked' } }), { modelSnapshot: models() });
  assert.equal(absent.checks.gpu_inventory.status, 'blocked');
  assert.equal(absent.diagnostic_status, 'blocked');
  const small = assessGpuPreflight(inventory({ gpus: [{ index: 0, vendor: 'nvidia', product_name: 'Small GPU', memory_total_mb: 4096, driver_version: null }] }), { modelSnapshot: models(8192) });
  assert.equal(small.checks.model_memory[0].status, 'blocked');
  assert.equal(small.diagnostic_status, 'blocked');
});

test('missing tool is unknown rather than proof no GPU exists', () => {
  const calls = [];
  const result = collectLocalNvidiaInventory({ spawn: (command, args, options) => {
    calls.push({ command, args, options });
    return { error: Object.assign(new Error('missing'), { code: 'ENOENT' }) };
  }, collectedAt: '2026-09-25T21:00:00Z', os: 'linux', arch: 'x64' });
  assert.equal(result.tooling.nvidia_smi, 'absent');
  assert.equal(assessGpuPreflight(result).checks.gpu_inventory.status, 'unknown');
  assert.deepEqual(calls[0].args, ['--query-gpu=index,name,memory.total,driver_version', '--format=csv,noheader,nounits']);
  assert.equal(calls[0].options.shell, false);
  assert.equal(calls[0].options.timeout, 5000);
});

test('parses documented nvidia-smi CSV and rejects malformed or empty reports', () => {
  const parsed = parseNvidiaSmi('0, NVIDIA RTX Example, 24576, 580.82.07\n', { collectedAt: '2026-09-25T21:00:00Z', os: 'linux', arch: 'x64' });
  assert.equal(parsed.gpus[0].memory_total_mb, 24576);
  assert.throws(() => parseNvidiaSmi('0, incomplete\n'), { code: 'invalid_gpu_inventory' });
  assert.throws(() => parseNvidiaSmi(''), { code: 'invalid_gpu_inventory' });
});

test('inventory rejects identifiers and sensitive or unexpected fields', () => {
  for (const bad of [
    { ...inventory(), hostname: 'private-host' },
    { ...inventory(), gpus: [{ ...inventory().gpus[0], uuid: 'GPU-secret' }] },
    { ...inventory(), gpus: [{ ...inventory().gpus[0], product_name: 'GPU\nSECRET' }] },
    { ...inventory(), gpus: [{ ...inventory().gpus[0], memory_total_mb: 1.5 }] },
    { ...inventory(), collected_at: 0 },
  ]) assert.throws(() => validateGpuInventory(bad), { code: 'invalid_gpu_inventory' });
});

test('missing advertised VRAM remains unknown and is not converted to zero', () => {
  const report = assessGpuPreflight(inventory(), { modelSnapshot: models(null) });
  assert.equal(report.checks.model_memory[0].advertised_vram_required_mb, null);
  assert.equal(report.checks.model_memory[0].status, 'unknown');
});

test('redacted report omits unsupported identity, network and wallet fields', () => {
  const report = assessGpuPreflight(inventory(), { modelSnapshot: models() });
  const exported = JSON.stringify(report);
  for (const secret of ['private-host', '192.0.2.1', 'GPU-secret', 'Kwalletsecret']) assert.doesNotMatch(exported, new RegExp(secret));
  assert.deepEqual(Object.keys(report.inventory.gpus[0]), ['index', 'vendor', 'product_name', 'memory_total_mb', 'driver_version']);
});

test('CLI writes bounded JSON and Markdown reports without touching inputs', t => {
  const dir = mkdtempSync(join(tmpdir(), 'kconnect-gpu-'));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const inventoryPath = join(dir, 'inventory.json');
  const modelsPath = join(dir, 'models.json');
  const outputPath = join(dir, 'report.json');
  writeFileSync(inventoryPath, JSON.stringify(inventory()));
  writeFileSync(modelsPath, JSON.stringify(models()));
  const before = readFileSync(inventoryPath, 'utf8');
  execFileSync(process.execPath, ['src/cli.js', 'gpu-preflight', '--input', inventoryPath, '--models', modelsPath, '--output', outputPath], { cwd: new URL('..', import.meta.url), encoding: 'utf8' });
  const report = JSON.parse(readFileSync(outputPath, 'utf8'));
  assert.equal(report.checks.model_memory[0].status, 'meets_advertised_memory');
  assert.match(readFileSync(`${outputPath}.md`, 'utf8'), /Operational requirements/);
  assert.equal(readFileSync(inventoryPath, 'utf8'), before);
});
