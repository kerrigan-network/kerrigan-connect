import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { CoordinatorClient, fetchJson } from '../src/coordinator.js';
import { normalizeRequest, sats } from '../src/validation.js';
import { parseCsv, exportCsv, validateCatalogueOutput, DEFAULT_TAXONOMY } from '../src/catalogue.js';
import { readConfig } from '../src/config.js';
import { acquireLock } from '../src/lock.js';
import { request } from './helpers.js';

const drone = 'a'.repeat(40);
const model = { id: 'test-model', name: 'Test Model', context_length: 16384, drones: [drone], quant: 'Q4', vram_required_mb: 4096, rate_sat_per_token: 500, in_rate_sat_per_token: 50 };
const invoice = { amount_sat: 2500, max_tokens: 128, drone_pubkey_hash: drone, pay_to_address: `K${'a'.repeat(33)}`, model_hash: 'b'.repeat(16), expires_block: 200000 };

test('coordinator adapter pins a model provider and sends the original payment/sampling parameters', async () => {
  const calls = [];
  const fetchImpl = async (url, options) => {
    const body = options.body ? JSON.parse(options.body) : null; calls.push({ url, body });
    return Response.json(url.endsWith('/v1/models') ? { models: [model] } : url.endsWith('/v1/invoice') ? invoice : { response: 'test response', commitment: { hash: 'unverified' } });
  };
  const provider = new CoordinatorClient({ fetchImpl });
  const req = normalizeRequest(request({ model: 'test-model', temperature: 0, top_p: 0.8, seed: 123 }));
  const quote = await provider.quote(req);
  const result = await provider.infer(req, quote, 'd'.repeat(64));
  assert.equal(calls[1].body.drone_pubkey_hash, drone);
  assert.equal(calls[2].body.payment_txid, 'd'.repeat(64));
  assert.equal(calls[2].body.temperature, 0); assert.equal(calls[2].body.top_p, 0.8); assert.equal(calls[2].body.seed, 123);
  assert.equal(result.verification, 'not_performed');
});

test('coordinator refuses changed provider and fractional invoice amounts', async () => {
  for (const [bad, code] of [[{ ...invoice, drone_pubkey_hash: 'f'.repeat(40) }, 'provider_changed'], [{ ...invoice, amount_sat: 1.1 }, 'invalid_amount']]) {
    const provider = new CoordinatorClient({ fetchImpl: async url => Response.json(url.endsWith('/v1/models') ? { models: [model] } : bad) });
    await assert.rejects(provider.quote(normalizeRequest(request({ model: 'test-model' }))), { code });
  }
});

test('coordinator preserves bounded advertised VRAM and rejects invalid values', async () => {
  const valid = new CoordinatorClient({ fetchImpl: async () => Response.json({ models: [model] }) });
  assert.equal((await valid.models())[0].x_kerrigan.vram_required_mb, 4096);
  const invalid = new CoordinatorClient({ fetchImpl: async () => Response.json({ models: [{ ...model, vram_required_mb: 1.5 }] }) });
  await assert.rejects(invalid.models(), { code: 'invalid_upstream_response' });
});

test('probe uses GET only, reports unavailable sources and no fake zero counts', async () => {
  const methods = [];
  const provider = new CoordinatorClient({ fetchImpl: async (url, options) => {
    methods.push(options.method);
    if (url.includes('network-stats')) throw new Error('offline');
    return Response.json(url.endsWith('/v1/models') ? { models: [{ ...model, drones: undefined, providers: [drone] }] } : { connected_drones: 1 });
  } });
  const report = await provider.probe();
  assert.deepEqual(methods, ['GET','GET','GET']); assert.equal(report.connected_drones, 1);
  assert.equal(report.chain, null); assert.equal(report.errors[0].source, 'explorer');
  assert.equal(report.models[0].x_kerrigan.simulated, false);
  assert.equal(report.models[0].x_kerrigan.vram_required_mb, 4096);
});

test('upstream errors are sanitised and redirects/response size are bounded', async () => {
  await assert.rejects(fetchJson('https://example.test', { fetchImpl: async () => Response.json({ error: 'PRIVATE_PROMPT' }) }), error => error.code === 'upstream_rejected' && !error.message.includes('PRIVATE_PROMPT'));
  await assert.rejects(fetchJson('https://example.test', { fetchImpl: async (_url, options) => {
    assert.equal(options.redirect, 'error'); assert.ok(options.signal); return new Response('x'.repeat(2_000_001));
  } }), { code: 'upstream_response_too_large' });
});

test('CSV preserves commas, escaped quotes and quoted newlines; malformed and duplicate rows are rejected', () => {
  const products = parseCsv('id,description\r\nA,"A, \"\"quoted\"\"\nproduct"\r\n');
  assert.equal(products[0].description, 'A, "quoted"\nproduct');
  assert.throws(() => parseCsv('id,description\nA,"open'), { code: 'invalid_csv' });
  assert.throws(() => parseCsv('id,description\nA,one\nA,two'), { code: 'invalid_csv' });
  assert.throws(() => parseCsv('id,description\nA,one,extra'), { code: 'invalid_csv' });
  assert.match(exportCsv([{ id: '=HYPERLINK("bad")', description: ' +SUM(1)' }]), /'=HYPERLINK/);
  assert.match(exportCsv([{ description: ' +SUM(1)' }]), /' \+SUM/);
});

test('catalogue rejects hallucinated attributes and invalid taxonomy', () => {
  const product = { id: '1', description: 'White ceramic mug, 350 ml' };
  const valid = { category: 'Home & Kitchen', attributes: { colour: 'white', material: 'ceramic', size: '350 ml' }, flags: [] };
  assert.equal(validateCatalogueOutput(JSON.stringify(valid), product, DEFAULT_TAXONOMY).accepted, true);
  assert.equal(validateCatalogueOutput(JSON.stringify({ ...valid, attributes: { ...valid.attributes, material: 'gold' } }), product, DEFAULT_TAXONOMY).reason, 'unsupported_attribute');
  assert.equal(validateCatalogueOutput(JSON.stringify({ ...valid, category: 'Made-up category' }), product, DEFAULT_TAXONOMY).reason, 'invalid_schema');
  assert.equal(validateCatalogueOutput('not json', product, DEFAULT_TAXONOMY).reason, 'invalid_json');
});

test('configuration refuses live mode, unsafe network binding, default secrets and bad endpoints', () => {
  const env = { KCONNECT_API_KEY: 'random-test-value-123456789' };
  assert.equal(readConfig(env).mode, 'demo');
  for (const extra of [{ KCONNECT_MODE: 'live' }, { KCONNECT_HOST: '0.0.0.0' }, { KCONNECT_COORDINATOR_URL: 'http://example.test' }, { KCONNECT_DAILY_BUDGET_SATS: '1.2' }, { KCONNECT_API_KEY: 'short' }]) {
    assert.throws(() => readConfig({ ...env, ...extra }), { code: 'invalid_config' });
  }
});

test('integer amounts and unsupported model options are rejected before work', () => {
  for (const value of [1.1, -1, true, null, NaN, '1e3', '9007199254740993']) assert.throws(() => sats(value));
  assert.equal(sats('1234'), 1234);
  assert.throws(() => normalizeRequest(request({ tools: [] })), { code: 'unsupported_parameter' });
  assert.throws(() => normalizeRequest(request({ messages: [{ role: 'user', content: [{ type: 'image' }] }] })), { code: 'invalid_messages' });
});

test('data-directory lock prevents two workers and preserves an unreadable lock', t => {
  const dir = mkdtempSync(join(tmpdir(), 'kconnect-lock-'));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const release = acquireLock(dir);
  assert.throws(() => acquireLock(dir), { code: 'ledger_locked' });
  release();
  writeFileSync(join(dir, 'gateway.lock'), 'broken');
  assert.throws(() => acquireLock(dir), { code: 'ledger_locked' });
});
