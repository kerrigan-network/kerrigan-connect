import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { createServer } from 'node:http';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { setTimeout as delay } from 'node:timers/promises';
import { ConnectClient } from '../src/client.js';
import { createGatewayServer } from '../src/server.js';
import { setup, request } from './helpers.js';
const exec = promisify(execFile);
const apiKey = 'integration-test-only-key-123456';
async function listen(t, server) {
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  t.after(async () => { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); });
  return `http://127.0.0.1:${server.address().port}`;
}
async function fixture(t) {
  const state = setup(t);
  const baseUrl = await listen(t, createGatewayServer(state.gateway, { apiKey }));
  const delayed = createGatewayServer(state.gateway, { apiKey });
  delayed.prependListener('request', (req, res) => {
    if (req.method === 'POST') {
      const end = res.end.bind(res);
      res.end = (...args) => { setTimeout(() => end(...args), 250).unref(); return res; };
    }
  });
  const slowSubmitUrl = await listen(t, delayed);
  const slow = setup(t);
  const models = slow.gateway.models.bind(slow.gateway);
  slow.gateway.models = async () => { await delay(250); return models(); };
  const slowUrl = await listen(t, createGatewayServer(slow.gateway, { apiKey }));
  let redirected = 0;
  const faultUrl = await listen(t, createServer((req, res) => {
    if (req.url.startsWith('/large/')) { res.end(JSON.stringify({ data: 'x'.repeat(1000) })); }
    else if (req.url.startsWith('/invalid/')) res.end('not JSON');
    else if (req.url.startsWith('/redirect/')) { res.writeHead(302, { location: '/target/v1/models' }); res.end(); }
    else if (req.url.startsWith('/target/')) { redirected++; res.end('{}'); }
    else {
      res.writeHead(200, { 'content-type': 'application/json' }); res.write('{');
      const timer = setInterval(() => res.write(' '), 15);
      res.on('close', () => clearInterval(timer));
      setTimeout(() => { clearInterval(timer); res.end('}'); }, 500).unref();
    }
  }));
  return { ...state, baseUrl, slowUrl, slowSubmitUrl, faultUrl, redirected: () => redirected };
}
test('JavaScript client contract over real HTTP, with bounded failure paths', async t => {
  const { baseUrl, slowUrl, slowSubmitUrl, faultUrl, payments, redirected } = await fixture(t);
  const client = new ConnectClient({ baseUrl, apiKey });
  assert.equal((await client.models()).object, 'list');
  const job = await client.submit(request(), 'js-contract-001');
  assert.equal((await client.wait(job.id)).status, 'completed');
  assert.equal((await client.submit(request(), 'js-contract-001')).id, job.id);
  assert.equal(payments.payCalls, 1);
  await assert.rejects(client.submit(request({ temperature: 1 }), 'js-contract-001'), { code: 'idempotency_conflict', status: 409 });
  await assert.rejects(client.submit(request({ tools: [] }), 'js-tools-001'), { code: 'unsupported_parameter' });
  await assert.rejects(new ConnectClient({ baseUrl, apiKey: 'wrong' }).models(), { code: 'unauthorized', status: 401 });
  const start = performance.now();
  await assert.rejects(new ConnectClient({ baseUrl: slowUrl, apiKey, timeoutMs: 50 }).models(), { code: 'deadline_exceeded' });
  assert.ok(performance.now() - start < 1000);
  for (const [route, code] of [['large', 'response_too_large'], ['invalid', 'invalid_response'], ['redirect', 'transport_error'], ['dribble', 'deadline_exceeded']]) {
    await assert.rejects(new ConnectClient({ baseUrl: `${faultUrl}/${route}`, apiKey, timeoutMs: 100, maxResponseBytes: 100 }).models(), { code });
  }
  await assert.rejects(new ConnectClient({ baseUrl: `${faultUrl}/dribble`, apiKey }).wait(job.id, { timeoutMs: 50 }), { code: 'deadline_exceeded' });
  assert.equal(redirected(), 0);
  assert.throws(() => client.submit(request()), { code: 'invalid_idempotency_key' });
  assert.equal(payments.payCalls, 1);
  await assert.rejects(new ConnectClient({ baseUrl: slowSubmitUrl, apiKey, timeoutMs: 50 }).submit(request(), 'js-lost-response-001'), { code: 'deadline_exceeded' });
  const recovered = await client.submit(request(), 'js-lost-response-001');
  assert.equal((await client.wait(recovered.id)).status, 'completed');
  assert.equal(payments.payCalls, 2);
});
test('Python standard-library client executes against real disposable gateways', async t => {
  const { baseUrl, slowUrl, slowSubmitUrl, faultUrl, payments, redirected } = await fixture(t);
  const result = await exec('python3', ['test/integration-python.py'], { env: { ...process.env, KCONNECT_URL: baseUrl, KCONNECT_API_KEY: apiKey, SLOW_URL: slowUrl, SLOW_SUBMIT_URL: slowSubmitUrl, FAULT_URL: faultUrl }, timeout: 15000 });
  assert.match(result.stdout, /passed/); assert.equal(payments.payCalls, 2); assert.equal(redirected(), 0);
});
test('JS, Python and curl examples run and replay with environment-only credentials', async t => {
  const { baseUrl, payments } = await fixture(t);
  for (const [command, args, label] of [['node', ['examples/integration/job.mjs'], 'js'], ['python3', ['examples/integration/job.py'], 'python'], ['sh', ['examples/integration/chat.sh'], 'curl']]) {
    const env = { ...process.env, KCONNECT_URL: baseUrl, KCONNECT_API_KEY: apiKey, KCONNECT_INTENT_KEY: `example-${label}-001` };
    const first = JSON.parse((await exec(command, args, { env, timeout: 15000 })).stdout);
    const before = payments.payCalls;
    const second = JSON.parse((await exec(command, args, { env, timeout: 15000 })).stdout);
    assert.equal(first.id, second.id); assert.equal(payments.payCalls, before);
    if (label === 'curl') assert.equal(first.x_kerrigan.simulated, true);
    else assert.equal(first.status, 'completed');
  }
  assert.equal(payments.payCalls, 3);
});
