import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn, execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { createServer } from 'node:net';
import { once } from 'node:events';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { ConnectClient } from '../src/client.js';

const exec = promisify(execFile);
const root = fileURLToPath(new URL('../', import.meta.url));

test('CLI server and catalogue survive a process restart with no additional simulated spend', { timeout: 15000 }, async t => {
  const dir = mkdtempSync(join(tmpdir(), 'kconnect-cli-'));
  const socket = createServer(); socket.listen(0, '127.0.0.1'); await once(socket, 'listening');
  const port = socket.address().port; await new Promise(resolve => socket.close(resolve));
  const env = { ...process.env, KCONNECT_API_KEY: 'cli-test-key-123456789012345', KCONNECT_PORT: String(port), KCONNECT_DATA_DIR: join(dir, 'data'), KCONNECT_MODE: 'demo' };
  let child;
  async function stop() {
    if (child && child.exitCode === null) { const exited = once(child, 'exit'); child.kill('SIGTERM'); await exited; }
  }
  t.after(async () => { await stop(); rmSync(dir, { recursive: true, force: true }); });
  async function start() {
    child = spawn(process.execPath, ['src/cli.js', 'serve'], { cwd: root, env, stdio: ['ignore','pipe','pipe'] });
    await new Promise((resolve, reject) => {
      let output = '';
      const timer = setTimeout(() => reject(new Error('CLI did not start.')), 4000);
      child.stdout.on('data', data => { output += data; if (output.includes('No GPU or real KRGN')) { clearTimeout(timer); resolve(); } });
      child.once('error', error => { clearTimeout(timer); reject(error); });
      child.once('exit', () => { clearTimeout(timer); reject(new Error('CLI exited before readiness.')); });
    });
  }
  await start();
  const client = new ConnectClient({ baseUrl: `http://127.0.0.1:${port}`, apiKey: env.KCONNECT_API_KEY });
  const args = ['src/cli.js', 'catalogue', '--input', 'examples/catalogue.csv', '--output', join(dir, 'results.csv'), '--run-id', 'restart-cli-run', '--url', `http://127.0.0.1:${port}`];
  await exec(process.execPath, args, { cwd: root, env });
  const benchmarkArgs = ['src/cli.js', 'benchmark', '--url', `http://127.0.0.1:${port}`, '--model', 'demo/catalogue-v1', '--output', join(dir, 'benchmark.json')];
  await exec(process.execPath, benchmarkArgs, { cwd: root, env });
  assert.equal(JSON.parse(readFileSync(join(dir, 'benchmark.json'), 'utf8')).metrics.category_accuracy.correct, 13);
  const before = await client.request('/connect/status');
  assert.equal(JSON.parse(readFileSync(join(dir, 'results.csv.report.json'), 'utf8')).accepted, 6);
  const review = JSON.parse(readFileSync(join(dir, 'results.csv.review.json'), 'utf8'));
  assert.equal(review.decisions.length, 6);
  assert.ok(review.decisions.every(d => d.state === 'pending'));
  assert.ok(readFileSync(join(dir, 'results.csv.review.html'), 'utf8').includes('Catalogue review'));
  assert.equal(JSON.parse(readFileSync(join(dir, 'benchmark.json.review.json'), 'utf8')).decisions.length, 16);
  const firstIds = (await client.request('/connect/jobs')).jobs.map(j => j.id);
  // A second process cannot acquire the active ledger, even on a different port.
  await assert.rejects(exec(process.execPath, ['src/cli.js', 'serve'], { cwd: root, env: { ...env, KCONNECT_PORT: String(port + 1) } }), error => error.stderr.includes('ledger_locked'));
  await stop(); await start();
  await exec(process.execPath, args, { cwd: root, env });
  await exec(process.execPath, benchmarkArgs, { cwd: root, env });
  const after = await client.request('/connect/status');
  assert.equal(after.accounting.total_paid_sats, before.accounting.total_paid_sats);
  assert.deepEqual((await client.request('/connect/jobs')).jobs.map(j => j.id), firstIds);
  assert.equal(JSON.parse(readFileSync(join(dir, 'results.csv.report.json'), 'utf8')).simulated, true);
});
