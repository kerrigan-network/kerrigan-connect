import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { readFileSync } from 'node:fs';
import { createGatewayServer } from '../src/server.js';
import { firstUseStatus } from '../src/first-use.js';
import { setup } from './helpers.js';

const key = 'synthetic-first-use-key-123456';

async function serverFor(t, options = {}) {
  const state = setup(t, options);
  const server = createGatewayServer(state.gateway, { apiKey: key });
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  t.after(async () => {
    server.closeAllConnections();
    await new Promise(resolve => server.close(resolve));
  });
  const base = `http://127.0.0.1:${server.address().port}`;
  return { ...state, base };
}

test('first-use assets are local, credential-free and root redirects to the guide', async t => {
  const { base } = await serverFor(t);
  const root = await fetch(base + '/', { redirect: 'manual' });
  assert.equal(root.status, 302);
  assert.equal(root.headers.get('location'), '/start');
  for (const path of ['/start', '/start/', '/start/app.js', '/start/style.css']) {
    const response = await fetch(base + path);
    assert.equal(response.status, 200);
    assert.match(response.headers.get('content-security-policy'), /default-src 'none'/);
    assert.ok(!(await response.text()).includes(key));
  }
  assert.equal((await fetch(base + '/connect/first-use')).status, 401);
  assert.equal((await fetch(base + '/start/unknown.js')).status, 401);
});

test('demo first-use status labels supplied simulation and enables the Studio handoff', async t => {
  const { base, payments } = await serverFor(t);
  const response = await fetch(base + '/connect/first-use', { headers: { Authorization: `Bearer ${key}` } });
  assert.equal(response.status, 200);
  const status = await response.json();
  assert.deepEqual(status.gateway, { status: 'available', mode: 'demo', live_spending: false });
  assert.equal(status.models.source, 'supplied_demo');
  assert.equal(status.models.availability, 'available');
  assert.equal(status.models.data[0].simulated, true);
  assert.equal(status.processing.status, 'available_simulated');
  assert.equal(status.next.studio_path, '/studio');
  assert.equal(status.next.studio_ready, true);
  assert.equal(payments.payCalls, 0);
});

test('read-only first-use status separates observed discovery from unavailable processing', async t => {
  const provider = { models: async () => [{ id: 'observed/model', x_kerrigan: { context_length: 8192 } }] };
  const { base, payments } = await serverFor(t, { mode: 'read-only', provider });
  const response = await fetch(base + '/connect/first-use', { headers: { Authorization: `Bearer ${key}` } });
  const status = await response.json();
  assert.equal(status.models.source, 'observed_get');
  assert.equal(status.models.availability, 'available');
  assert.deepEqual(status.models.data, [{ id: 'observed/model', simulated: false, context_length: 8192 }]);
  assert.equal(status.processing.status, 'unavailable');
  assert.equal(status.next.studio_ready, false);
  assert.equal(payments.payCalls, 0);
});

test('discovery failures stay unknown and do not expose upstream error details', async () => {
  const gateway = {
    mode: 'read-only',
    models: async () => { throw new Error('SECRET upstream routing detail'); },
  };
  const status = await firstUseStatus(gateway);
  assert.equal(status.models.availability, 'unknown');
  assert.equal(status.models.error.code, 'discovery_unavailable');
  assert.ok(!JSON.stringify(status).includes('SECRET'));
  assert.equal(status.next.studio_ready, false);
});

test('first-use browser source has required controls, parses and never persists the key', () => {
  const html = readFileSync(new URL('../src/first-use/index.html', import.meta.url), 'utf8');
  const source = readFileSync(new URL('../src/first-use/app.js', import.meta.url), 'utf8');
  for (const id of ['gateway-key', 'connect', 'gateway-status', 'model-status', 'processing-status', 'open-studio']) {
    assert.match(html, new RegExp(`id="${id}"`));
  }
  assert.doesNotThrow(() => new Function(source));
  assert.doesNotMatch(source, /localStorage|sessionStorage|document\.cookie/);
});
