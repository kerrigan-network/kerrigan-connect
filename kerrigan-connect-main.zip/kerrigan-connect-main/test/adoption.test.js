import test from 'node:test';
import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { promisify } from 'node:util';
import { aggregateAdoptionEvents, appendAdoptionEvent, deduplicateAdoptionEvents, parseAdoptionJsonl, renderAdoptionSummary,
  renderAdoptionSummaryHtml, serializeAdoptionEvents, validateAdoptionEvent } from '../src/adoption.js';

const exec = promisify(execFile);
const root = new URL('../', import.meta.url).pathname;
const hash = character => `sha256:${character.repeat(64)}`;

function event(id, stage, extra = {}) {
  const evidence = {
    first_run_pass: 'quickstart_receipt',
    first_useful_workflow: 'reviewed_workflow',
    return_workflow: 'return_workflow_receipt',
    verified_live_request: 'live_receipt_hash',
  }[stage];
  return { format_version: 1, event_id: id, journey_id: 'journey-001', occurred_at: '2026-09-26T00:00:00Z', stage,
    activity: stage === 'verified_live_request' ? 'live' : 'simulated', evidence: { kind: evidence, reference: hash('a') }, ...extra };
}

test('strict opt-in event schema rejects prompt, device and personal fields', () => {
  assert.equal(validateAdoptionEvent(event('event-0001', 'first_run_pass')).stage, 'first_run_pass');
  for (const field of ['prompt', 'device_id', 'ip_address', 'wallet_address', 'email']) {
    assert.throws(() => validateAdoptionEvent({ ...event('event-0001', 'first_run_pass'), [field]: 'secret' }), { code: 'invalid_adoption_event' });
  }
});

test('verified live evidence cannot be created from simulation or another evidence kind', () => {
  assert.throws(() => validateAdoptionEvent(event('event-live1', 'verified_live_request', { activity: 'simulated' })), { code: 'invalid_adoption_event' });
  assert.throws(() => validateAdoptionEvent(event('event-live1', 'verified_live_request', { evidence: { kind: 'quickstart_receipt', reference: hash('b') } })), { code: 'invalid_adoption_event' });
});

test('deduplication is deterministic and changed reuse conflicts', () => {
  const first = event('event-0001', 'first_run_pass');
  const later = event('event-0002', 'first_useful_workflow', { occurred_at: '2026-09-26T00:01:00Z' });
  const result = deduplicateAdoptionEvents([later, first, structuredClone(first)]);
  assert.deepEqual(result.events.map(item => item.event_id), ['event-0001', 'event-0002']);
  assert.equal(result.exact_duplicates, 1);
  assert.throws(() => deduplicateAdoptionEvents([first, { ...first, activity: 'local_only' }]), { code: 'adoption_event_conflict' });
});

test('append is idempotent and serialisation is stable', () => {
  const first = event('event-0001', 'first_run_pass');
  const added = appendAdoptionEvent([], first);
  assert.equal(added.outcome, 'added');
  const duplicate = appendAdoptionEvent(added.events, structuredClone(first));
  assert.equal(duplicate.outcome, 'duplicate');
  assert.equal(serializeAdoptionEvents(added.events), serializeAdoptionEvents(duplicate.events));
});

test('aggregate separates simulation, local and supplied live evidence without exporting identifiers', () => {
  const input = [
    event('event-0001', 'first_run_pass'),
    event('event-0002', 'first_useful_workflow', { occurred_at: '2026-09-26T00:01:00Z', activity: 'local_only', evidence: { kind: 'reviewed_workflow', reference: hash('b') } }),
    event('event-0003', 'return_workflow', { occurred_at: '2026-09-26T00:02:00Z', activity: 'local_only', evidence: { kind: 'return_workflow_receipt', reference: hash('c') } }),
    event('event-0004', 'verified_live_request', { occurred_at: '2026-09-26T00:03:00Z', evidence: { kind: 'live_receipt_hash', reference: hash('d') } }),
  ];
  const report = aggregateAdoptionEvents(input, { generatedAt: '2026-09-26T00:04:00Z' });
  assert.deepEqual(report.activity, { simulated: 1, local_only: 2, live: 1 });
  assert.equal(report.stages.return_workflow.journeys, 1);
  assert.equal(report.verified_live_evidence.supplied_events, 1);
  assert.equal(report.claims.conversion_lift, null);
  assert.equal(report.claims.unique_people, null);
  assert.doesNotMatch(JSON.stringify(report), /journey-001|event-0001|sha256:dddd/);
});

test('sequence gaps are counted without leaking journey identifiers or inventing conversion', () => {
  const report = aggregateAdoptionEvents([event('event-0003', 'return_workflow')]);
  assert.equal(report.quality.journeys_with_sequence_gaps, 1);
  assert.equal(report.claims.measured_adoption, false);
  const reversed = aggregateAdoptionEvents([
    event('event-0002', 'first_useful_workflow', { occurred_at: '2026-09-26T00:00:00Z' }),
    event('event-0001', 'first_run_pass', { occurred_at: '2026-09-26T00:01:00Z' }),
  ]);
  assert.equal(reversed.quality.journeys_with_sequence_gaps, 1);
});

test('JSONL parsing is strict and reports remain static and privacy-labelled', () => {
  const first = event('event-0001', 'first_run_pass');
  const parsed = parseAdoptionJsonl(`${JSON.stringify(first)}\n${JSON.stringify(first)}\n`);
  const report = aggregateAdoptionEvents(parsed);
  assert.equal(report.records.exact_duplicates, 1);
  assert.match(renderAdoptionSummary(report), /not users, market adoption or conversion lift/i);
  const rendered = renderAdoptionSummaryHtml(report);
  assert.match(rendered, /<!doctype html>/i);
  assert.doesNotMatch(rendered, /<script/i);
});

test('record and report CLI preserve inputs, deduplicate and write JSON, Markdown and HTML', async t => {
  const dir = mkdtempSync(join(tmpdir(), 'kconnect-adoption-')); t.after(() => rmSync(dir, { recursive: true, force: true }));
  const input = join(dir, 'event.json'), log = join(dir, 'events.jsonl'), output = join(dir, 'summary.json');
  writeFileSync(input, JSON.stringify(event('event-0001', 'first_run_pass')));
  const before = readFileSync(input, 'utf8');
  await exec(process.execPath, ['src/cli.js', 'adoption-record', '--input', input, '--output', log], { cwd: root });
  const duplicate = await exec(process.execPath, ['src/cli.js', 'adoption-record', '--input', input, '--output', log], { cwd: root });
  assert.match(duplicate.stdout, /"outcome": "duplicate"/);
  assert.equal(readFileSync(log, 'utf8').trim().split('\n').length, 1);
  assert.equal(readFileSync(input, 'utf8'), before);
  await exec(process.execPath, ['src/cli.js', 'adoption-report', '--input', log, '--output', output], { cwd: root });
  assert.equal(JSON.parse(readFileSync(output, 'utf8')).records.unique_events, 1);
  assert.match(readFileSync(`${output}.md`, 'utf8'), /local pilot evidence summary/i);
  assert.match(readFileSync(`${output}.html`, 'utf8'), /<!doctype html>/i);
});

test('committed synthetic fixture reproduces its aggregate exactly and contains no live claim', () => {
  const events = parseAdoptionJsonl(readFileSync(new URL('../fixtures/adoption-v0.11.0/events.jsonl', import.meta.url), 'utf8'));
  const expected = JSON.parse(readFileSync(new URL('../fixtures/adoption-v0.11.0/summary.json', import.meta.url), 'utf8'));
  const report = aggregateAdoptionEvents(events, { generatedAt: expected.generated_at });
  assert.deepEqual(report, expected);
  assert.equal(report.verified_live_evidence.supplied_events, 0);
  assert.equal(report.claims.measured_adoption, false);
});
