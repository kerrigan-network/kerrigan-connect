import test from 'node:test';
import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { promisify } from 'node:util';
import { captureCapabilitySnapshot, diffCapabilitySnapshots, normalizeCapabilitySnapshot, renderCapabilityDiff, renderCapabilityDiffHtml, renderCapabilitySnapshot, renderCapabilitySnapshotHtml } from '../src/capability-tracker.js';

const exec = promisify(execFile);
const root = new URL('../', import.meta.url).pathname;
const at = '2026-09-25T22:00:00.000Z';
const providerA = 'a'.repeat(40);
const providerB = 'b'.repeat(40);
const providerC = 'c'.repeat(40);

function model(id, providers = [providerA], extra = {}) {
  return { id, x_kerrigan: { drones: providers, context_length: 16384, quant: 'Q4_K_M', vram_required_mb: 8192,
    advertised_capabilities: { chat: true, tools: false }, in_rate_sat_per_token: 10, rate_sat_per_token: 20, ...extra } };
}

function probe(extra = {}) {
  return { observed_at: at, coordinator: 'https://coordinator.jskitty.com', scope: 'One configured coordinator; not a census of the entire network.',
    models: [model('alpha/model', [providerA, providerB]), model('beta/model', [providerC])], connected_drones: 3,
    chain: { height: 123456, drone_payout_active: false }, errors: [], ...extra };
}

function snapshot(value = probe(), capturedAt = '2026-09-25T22:01:00.000Z') {
  return normalizeCapabilitySnapshot(value, { capturedAt });
}

test('snapshot is bounded, sorted, scoped and exports stable provider references instead of raw ids', () => {
  const report = snapshot();
  assert.equal(report.freshness.state, 'fresh');
  assert.equal(report.source.coordinator_scope_only, true);
  assert.deepEqual(report.models.map(item => item.id), ['alpha/model', 'beta/model']);
  assert.equal(report.models[0].advertised_provider_count, 2);
  assert.ok(report.models[0].provider_refs.every(ref => /^sha256:[a-f0-9]{16}$/.test(ref)));
  assert.doesNotMatch(JSON.stringify(report), new RegExp(providerA));
  assert.match(renderCapabilitySnapshot(report), /not a census/i);
  assert.match(renderCapabilitySnapshotHtml(report), /one configured coordinator only/i);
  assert.doesNotMatch(renderCapabilitySnapshotHtml(report), new RegExp(providerA));
});

test('endpoint failure, empty catalogue, zero providers and stale observation remain distinct', () => {
  const failed = snapshot({ ...probe(), models: null, errors: [{ source: 'models', code: 'upstream_unavailable' }] });
  const empty = snapshot({ ...probe(), models: [] });
  const zero = snapshot({ ...probe(), connected_drones: 0 });
  const stale = snapshot(probe(), '2026-09-25T22:10:01.000Z');
  assert.equal(failed.endpoints.models.state, 'endpoint_failure');
  assert.equal(empty.endpoints.models.state, 'empty_advertised_list');
  assert.equal(zero.endpoints.coordinator.state, 'zero_connected_reported');
  assert.equal(stale.freshness.state, 'stale');
});

test('comparable observations report model, capability and provider advertisement changes stably', () => {
  const baseline = snapshot();
  const current = snapshot({ ...probe(), observed_at: '2026-09-25T22:02:00.000Z', connected_drones: 2, models: [
    model('alpha/model', [providerB, providerC], { context_length: 32768 }), model('gamma/model', [providerA]),
  ] }, '2026-09-25T22:03:00.000Z');
  const diff = diffCapabilitySnapshots(baseline, current, { generatedAt: '2026-09-25T22:04:00.000Z' });
  assert.equal(diff.comparison_state, 'comparable');
  assert.deepEqual(diff.changes.models_added, ['gamma/model']);
  assert.deepEqual(diff.changes.models_removed, ['beta/model']);
  assert.deepEqual(diff.changes.capabilities_changed, [{ model_id: 'alpha/model', fields: ['context_length'] }]);
  assert.equal(diff.changes.providers_added.length, 1);
  assert.equal(diff.changes.providers_removed.length, 1);
  assert.match(renderCapabilityDiff(diff), /Models removed.*beta\/model/s);
  assert.match(renderCapabilityDiffHtml(diff), /Models removed.*beta\/model/s);
});

test('failed, stale and empty current observations suppress removal events with explicit states', () => {
  const baseline = snapshot();
  const cases = [
    [snapshot({ ...probe(), models: null, errors: [{ source: 'models', code: 'upstream_unavailable' }] }), 'unknown_current_endpoint_failure'],
    [snapshot(probe({ models: [model('alpha/model')] }), '2026-09-25T22:10:01.000Z'), 'unknown_current_stale_or_invalid'],
    [snapshot({ ...probe(), models: [] }), 'empty_current_advertised_list'],
  ];
  for (const [current, expected] of cases) {
    const diff = diffCapabilitySnapshots(baseline, current);
    assert.equal(diff.comparison_state, expected);
    assert.deepEqual(diff.changes.models_removed, []);
    assert.deepEqual(diff.changes.providers_removed, []);
    assert.match(diff.note, /suppressed/);
  }
});

test('recovery from an explicitly empty list reports additions without inventing removals', () => {
  const baseline = snapshot({ ...probe(), models: [] });
  const current = snapshot(probe({ models: [model('alpha/model')] }));
  const diff = diffCapabilitySnapshots(baseline, current);
  assert.equal(diff.comparison_state, 'recovered_from_empty_advertised_list');
  assert.deepEqual(diff.changes.models_added, ['alpha/model']);
  assert.deepEqual(diff.changes.models_removed, []);
});

test('live capture retries failed GET observations within the hard attempt limit', async () => {
  let calls = 0; const delays = [];
  const report = await captureCapabilitySnapshot(async () => {
    calls += 1;
    return calls === 1 ? { ...probe(), models: null, errors: [{ source: 'models', code: 'upstream_unavailable' }] } : probe();
  }, { maxAttempts: 3, retryDelayMs: 25, now: () => '2026-09-25T22:01:00.000Z', sleep: async ms => delays.push(ms) });
  assert.equal(calls, 2);
  assert.deepEqual(delays, [25]);
  assert.deepEqual(report.retry, { attempts_used: 2, max_attempts: 3 });
  assert.equal(report.endpoints.models.state, 'observed');
  let failedCalls = 0;
  const failed = await captureCapabilitySnapshot(async () => { failedCalls += 1; return { ...probe(), models: null, errors: [{ source: 'models', code: 'unavailable' }] }; },
    { maxAttempts: 2, retryDelayMs: 0, now: () => '2026-09-25T22:01:00.000Z', sleep: async () => {} });
  assert.equal(failedCalls, 2);
  assert.equal(failed.retry.attempts_used, 2);
});

test('CLI normalises a saved probe and writes stable JSON/Markdown diffs while protecting inputs', async t => {
  const dir = mkdtempSync(join(tmpdir(), 'kconnect-tracker-')); t.after(() => rmSync(dir, { recursive: true, force: true }));
  const probePath = join(dir, 'probe.json');
  const snapshotPath = join(dir, 'snapshot.json');
  writeFileSync(probePath, JSON.stringify(probe({ observed_at: new Date().toISOString() })));
  const before = readFileSync(probePath, 'utf8');
  await exec(process.execPath, ['src/cli.js', 'snapshot', '--input', probePath, '--output', snapshotPath], { cwd: root });
  const first = JSON.parse(readFileSync(snapshotPath, 'utf8'));
  assert.equal(first.endpoints.models.state, 'observed');
  assert.match(readFileSync(`${snapshotPath}.md`, 'utf8'), /one configured coordinator only/i);
  assert.match(readFileSync(`${snapshotPath}.html`, 'utf8'), /<!doctype html>/i);
  assert.equal(readFileSync(probePath, 'utf8'), before);
  const currentPath = join(dir, 'current.json');
  const current = structuredClone(first); current.captured_at = new Date(Date.now() + 1000).toISOString(); current.observed_at = current.captured_at;
  writeFileSync(currentPath, JSON.stringify(current));
  const diffPath = join(dir, 'diff.json');
  await exec(process.execPath, ['src/cli.js', 'snapshot-diff', '--baseline', snapshotPath, '--input', currentPath, '--output', diffPath], { cwd: root });
  assert.equal(JSON.parse(readFileSync(diffPath, 'utf8')).comparison_state, 'comparable');
  assert.match(readFileSync(`${diffPath}.md`, 'utf8'), /Kerrigan capability change report/);
  assert.match(readFileSync(`${diffPath}.html`, 'utf8'), /Kerrigan capability change report/);
});

test('invalid provider ids, excessive retries and output overwrite fail closed', async () => {
  assert.throws(() => snapshot(probe({ models: [model('bad', ['not-a-provider'])] })), { code: 'invalid_snapshot' });
  await assert.rejects(captureCapabilitySnapshot(async () => probe(), { maxAttempts: 4 }), { code: 'invalid_snapshot' });
  await assert.rejects(exec(process.execPath, ['src/cli.js', 'snapshot', '--input', 'same.json', '--output', 'same.json'], { cwd: root }), error => error.code === 1);
});
