import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { readFileSync } from 'node:fs';
import { createGatewayServer } from '../src/server.js';
import { ConnectClient } from '../src/client.js';
import { parseCsv, processCatalogue } from '../src/catalogue.js';
import { DEMO_MODEL } from '../src/demo.js';
import { request, setup, budgets } from './helpers.js';

const API_KEY = 'test-only-api-key-1234567890';
async function serverFor(t, options = {}) {
  const state = setup(t, options);
  const server = createGatewayServer(state.gateway, { apiKey: API_KEY });
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  t.after(async () => { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); });
  const baseUrl = `http://127.0.0.1:${server.address().port}`;
  const call = (path, options = {}) => fetch(`${baseUrl}${path}`, {
    ...options, headers: { authorization: `Bearer ${API_KEY}`, ...options.headers },
  });
  return { ...state, baseUrl, call, client: new ConnectClient({ baseUrl, apiKey: API_KEY }) };
}
const post = (body, key = 'http-key-0001') => ({ method: 'POST', headers: { 'content-type': 'application/json', 'Idempotency-Key': key }, body: JSON.stringify(body) });

test('health is public; API routes require authentication; config secrets never appear in status', async t => {
  const { baseUrl, call } = await serverFor(t, { budgets: { ...budgets, apiKey: 'NEVER_RETURN_THIS_SECRET' } });
  assert.equal((await fetch(`${baseUrl}/healthz`)).status, 200);
  assert.equal((await fetch(`${baseUrl}/v1/models`)).status, 401);
  const response = await call('/connect/status');
  const body = await response.text();
  assert.ok(!body.includes('NEVER_RETURN_THIS_SECRET')); assert.ok(!body.includes(API_KEY));
  assert.equal(response.headers.get('cache-control'), 'no-store');
  assert.equal((await call('/v1/models', { headers: { origin: 'https://malicious.example' } })).status, 403);
});

test('compatible completion has usage, simulation receipt and stable replay', async t => {
  const { call, payments } = await serverFor(t);
  const first = await call('/v1/chat/completions', post(request()));
  assert.equal(first.status, 200);
  const body = await first.json();
  assert.equal(body.object, 'chat.completion'); assert.equal(body.choices[0].message.role, 'assistant');
  assert.equal(body.x_kerrigan.simulated, true); assert.equal(body.x_kerrigan.verification, 'not_performed');
  const replay = await (await call('/v1/chat/completions', post(request()))).json();
  assert.equal(replay.id, body.id); assert.equal(payments.payCalls, 1);
  assert.equal((await call(`/connect/jobs/${body.x_kerrigan.job_id}`)).status, 200);
});

test('buffered SSE follows chat chunk format and terminates with DONE', async t => {
  const { call } = await serverFor(t);
  const response = await call('/v1/chat/completions', post(request({ stream: true }), 'sse-key-0001'));
  assert.equal(response.headers.get('x-kerrigan-stream-mode'), 'buffered');
  assert.match(response.headers.get('content-type'), /text\/event-stream/);
  const frames = (await response.text()).trim().split('\n\n').map(s => s.slice(6));
  assert.equal(frames.at(-1), '[DONE]');
  assert.equal(JSON.parse(frames[0]).object, 'chat.completion.chunk');
  assert.equal(JSON.parse(frames[1]).x_kerrigan.simulated, true);
});

test('validation rejects unsupported tools, invalid JSON, content type and unkeyed jobs', async t => {
  const { call, payments } = await serverFor(t);
  assert.equal((await call('/connect/jobs', post({ ...request(), tools: [] }))).status, 400);
  const invalid = { ...post(request()), body: '{broken' };
  assert.equal((await call('/connect/jobs', invalid)).status, 400);
  assert.equal((await call('/connect/jobs', { method: 'POST', body: '{}' })).status, 415);
  assert.equal((await call('/connect/jobs', { ...post(request()), headers: { 'content-type': 'application/json' } })).status, 400);
  assert.equal(payments.payCalls, 0);
});

test('catalogue CSV completes over the real HTTP API and reruns without duplicate payments', async t => {
  const { client, payments } = await serverFor(t);
  const products = parseCsv(readFileSync(new URL('../examples/catalogue.csv', import.meta.url), 'utf8'));
  const params = { products, client, model: DEMO_MODEL, runId: 'http-catalogue-e2e' };
  const rows = await processCatalogue(params);
  assert.equal(rows.length, 6); assert.ok(rows.every(r => r.status === 'accepted' && r.simulated));
  assert.equal(rows[2].category, 'Home & Kitchen'); assert.equal(rows[2].size, '350 ml');
  const replay = await processCatalogue(params);
  assert.deepEqual(replay.map(r => r.job_id), rows.map(r => r.job_id)); assert.equal(payments.payCalls, 6);
});

test('async job routes return Location, enforce conflicts and protect completed jobs from cancellation', async t => {
  const { call, client } = await serverFor(t);
  const response = await call('/connect/jobs', post(request(), 'async-key-0001'));
  assert.equal(response.status, 202);
  const job = await response.json();
  assert.equal(response.headers.get('location'), `/connect/jobs/${job.id}`);
  await client.wait(job.id);
  assert.equal((await call(`/connect/jobs/${job.id}/cancel`, { method: 'POST' })).status, 409);
  assert.equal((await call('/connect/jobs', post(request({ seed: 55 }), 'async-key-0001'))).status, 409);
  assert.equal((await call('/unknown')).status, 404);
});

test('n8n example produces a valid request and can parse a real gateway response', async t => {
  const { call } = await serverFor(t);
  const workflow = JSON.parse(readFileSync(new URL('../integrations/n8n/catalogue-demo.json', import.meta.url), 'utf8'));
  const code = workflow.nodes.find(n => n.name === 'Prepare request').parameters.jsCode;
  const input = new Function(code)()[0].json;
  const response = await (await call('/v1/chat/completions', post(input.request, input.idempotencyKey))).json();
  const output = new Function('items', workflow.nodes.find(n => n.name === 'Inspect result').parameters.jsCode)([{ json: response }]);
  assert.equal(output[0].json.catalogue.category, 'Home & Kitchen'); assert.equal(output[0].json.receipt.simulated, true);
  assert.equal(workflow.active, false);
});
