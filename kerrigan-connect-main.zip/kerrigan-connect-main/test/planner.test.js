import test from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync, spawnSync } from 'node:child_process';
import { mkdtempSync, readFileSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { planWorkload, renderPlan, readPlanJson } from '../src/planner.js';
import { CoordinatorClient } from '../src/coordinator.js';
const now = Date.parse('2026-09-25T19:30:00Z');
const workload = { input_tokens: 1000, output_tokens: 256, context_overhead_tokens: 128, jobs: 10 };
const probe = () => ({ observed_at: new Date(now).toISOString(), coordinator: 'https://coordinator.example.test', errors: [], models: [{ id: 'fixture-model', x_kerrigan: { simulated: false, context_length: 16384, drones: ['a'.repeat(40)], rate_sat_per_token: 500, in_rate_sat_per_token: 50, rates_observed: { input: true, output: true }, advertised_capabilities: { chat: true, tools: false } } }] });
const plan = (p = probe(), w = workload) => planWorkload(p, w, { now });

test('planner computes exact per-job and batch advertised scenarios with unknown invoices and fees', () => {
  const r = plan(); assert.deepEqual(r.advertised_fits, ['fixture-model']);
  const c = r.candidates[0]; assert.equal(c.required_context_tokens, '1384');
  assert.equal(c.scenarios[2].advertised_compute_sats_per_job, '184400');
  assert.equal(c.scenarios[2].advertised_compute_sats_batch, '1844000');
  assert.equal(c.scenarios[2].advertised_compute_krgn_batch, '0.01844000');
  assert.equal(c.scenarios[0].output_tokens, '64');
  assert.equal(c.scenarios[2].fees_sats, null); assert.equal(c.scenarios[2].final_invoice_sats, null);
  assert.equal(r.spending_enabled, false); assert.equal(r.live_inference_ready, false);
});
test('context equality fits; excess or missing context cannot be confirmed', () => {
  const p = probe(); p.models[0].x_kerrigan.context_length = 1384;
  assert.equal(plan(p).candidates[0].status, 'advertised_fit');
  p.models[0].x_kerrigan.context_length--;
  assert.equal(plan(p).candidates[0].status, 'blocked');
  delete p.models[0].x_kerrigan.context_length;
  assert.equal(plan(p).candidates[0].context_fits, null);
});
test('stale, future, invalid and failed observations never confirm availability; empty is separate', () => {
  for (const [date, state] of [[now - 300001, 'stale'], [now + 1, 'future_timestamp'], ['bad', 'invalid_timestamp']]) {
    const p = probe(); p.observed_at = typeof date === 'number' ? new Date(date).toISOString() : date;
    assert.equal(plan(p).freshness, state); assert.deepEqual(plan(p).advertised_fits, []);
  }
  assert.equal(plan({ ...probe(), models: [] }).catalogue, 'empty');
  assert.equal(plan({ ...probe(), models: null }).catalogue, 'unavailable');
  assert.equal(plan({ ...probe(), errors: [{ source: 'models', code: 'unavailable' }] }).candidates[0].status, 'unknown');
  assert.equal(planWorkload(probe(), workload, { now, model: 'missing' }).candidates.length, 0);
});
test('required capabilities use advertisements not adapter assumptions, and never prove confidentiality', () => {
  const p = probe(); const x = p.models[0].x_kerrigan;
  assert.equal(plan(p, { ...workload, required_capabilities: ['chat'] }).candidates[0].status, 'advertised_fit');
  assert.equal(plan(p, { ...workload, required_capabilities: ['tools'] }).candidates[0].status, 'blocked');
  delete x.advertised_capabilities; x.capabilities = { chat: true };
  assert.equal(plan(p, { ...workload, required_capabilities: ['chat'] }).candidates[0].status, 'unknown');
  x.advertised_capabilities = { confidentiality: true };
  assert.equal(plan(p, { ...workload, required_capabilities: ['confidentiality'] }).candidates[0].status, 'unknown');
  assert.throws(() => plan(p, { ...workload, required_capabilities: ['magic'] }));
});
test('missing, malformed and legacy zero rates remain unknown; explicitly observed zero remains zero', () => {
  for (const value of [null, undefined, -1, 1.2, true, '1e2', Number.MAX_SAFE_INTEGER + 1]) {
    const p = probe(); p.models[0].x_kerrigan.in_rate_sat_per_token = value;
    assert.equal(plan(p).candidates[0].scenarios[2].advertised_compute_sats_batch, null);
    assert.equal(plan(p, { ...workload, max_advertised_compute_sats: '9999999' }).candidates[0].status, 'unknown');
  }
  const p = probe(); const x = p.models[0].x_kerrigan; x.in_rate_sat_per_token = 0; delete x.rates_observed;
  assert.equal(plan(p).candidates[0].input_sats_per_token, null);
  x.rates_observed = { input: true }; assert.equal(plan(p).candidates[0].input_sats_per_token, '0');
});
test('BigInt avoids unsafe sum/product rounding; compute ceiling excludes unknown fees', () => {
  const p = probe(); const x = p.models[0].x_kerrigan;
  x.context_length = Number.MAX_SAFE_INTEGER; x.in_rate_sat_per_token = '999999999999999999999999999999';
  const w = { input_tokens: Number.MAX_SAFE_INTEGER - 1, output_tokens: 1, jobs: Number.MAX_SAFE_INTEGER };
  const r = plan(p, w); const expected = ((BigInt(w.input_tokens) * BigInt(x.in_rate_sat_per_token)) + 500n) * BigInt(w.jobs);
  assert.equal(r.candidates[0].scenarios[2].advertised_compute_sats_batch, expected.toString());
  assert.doesNotThrow(() => JSON.stringify(r));
  assert.equal(plan(p, { ...w, context_overhead_tokens: 1 }).candidates[0].status, 'blocked');
  assert.equal(plan(probe(), { ...workload, max_advertised_compute_sats: '1843999' }).candidates[0].status, 'blocked');
  assert.equal(plan(probe(), { ...workload, max_advertised_compute_sats: '1844000' }).candidates[0].status, 'advertised_fit');
});
test('invalid workload/model/source shape fails closed; missing provider and simulation cannot confirm fit', () => {
  for (const w of [{ ...workload, input_tokens: 1.2 }, { ...workload, jobs: 0 }, { ...workload, output_tokens: Number.MAX_SAFE_INTEGER + 1 }, { ...workload, prompt: 'not accepted' }]) assert.throws(() => plan(probe(), w));
  assert.throws(() => plan({ ...probe(), coordinator: 'https://secret@example.test' }));
  assert.throws(() => plan({ ...probe(), models: [...probe().models, ...probe().models] }));
  const p = probe(); p.models[0].x_kerrigan.drones = [];
  assert.equal(plan(p).candidates[0].status, 'blocked');
  p.models[0].x_kerrigan.drones = null; assert.equal(plan(p).candidates[0].status, 'unknown');
  p.models[0].x_kerrigan.drones = ['a'.repeat(40)]; p.models[0].x_kerrigan.simulated = true;
  assert.equal(plan(p).candidates[0].status, 'unknown');
});
test('discovery preserves absent rates and separates advertised capability from gateway policy', async () => {
  const provider = new CoordinatorClient({ fetchImpl: async () => Response.json({ models: [{ id: 'fixture', context_length: 4096, drones: ['a'.repeat(40)] }] }) });
  const [m] = await provider.models();
  assert.equal(m.x_kerrigan.in_rate_sat_per_token, null); assert.equal(m.x_kerrigan.rate_sat_per_token, null);
  assert.deepEqual(m.x_kerrigan.rates_observed, { input: false, output: false });
  assert.deepEqual(m.x_kerrigan.advertised_capabilities, {});
});
test('CLI creates JSON/Markdown, rejects overwrite, reports stale snapshots and bounds input', t => {
  const dir = mkdtempSync(join(tmpdir(), 'kconnect-plan-')); t.after(() => rmSync(dir, { recursive: true, force: true }));
  const input = join(dir, 'probe.json'), task = join(dir, 'workload.json'), output = join(dir, 'plan.json');
  writeFileSync(input, JSON.stringify({ ...probe(), observed_at: new Date().toISOString() })); writeFileSync(task, JSON.stringify(workload));
  const args = ['src/cli.js', 'plan', '--input', input, '--workload', task, '--output', output];
  const r = JSON.parse(execFileSync(process.execPath, args, { encoding: 'utf8' }));
  assert.equal(r.outcome, 'advertised_candidates'); assert.equal(JSON.parse(readFileSync(output)).format_version, 1);
  assert.match(readFileSync(`${output}.md`, 'utf8'), /not invoices/);
  assert.match(renderPlan(r), /0.01844000/);
  assert.notEqual(spawnSync(process.execPath, [...args.slice(0, -1), input]).status, 0);
  writeFileSync(input, JSON.stringify({ ...probe(), observed_at: '2000-01-01T00:00:00Z' }));
  const stale = spawnSync(process.execPath, args, { encoding: 'utf8' }); assert.equal(stale.status, 2); assert.equal(JSON.parse(stale.stdout).freshness, 'stale');
  writeFileSync(input, ' '.repeat(2_000_001)); assert.throws(() => readPlanJson(input));
});
