import test from 'node:test';
import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { existsSync, mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { promisify } from 'node:util';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { once } from 'node:events';

const exec = promisify(execFile);
const root = fileURLToPath(new URL('..', import.meta.url));

test('installed CLI completes quickstart and an unlabelled task through restart, review and export', async t => {
  // npm supplies its JS entry point. Run it with this Node executable rather
  // than execFile("npm.cmd"), which cannot launch batch files on Windows.
  assert.ok(process.env.npm_execpath, 'Run the install check through npm test or npm run test:install.');
  const dir = mkdtempSync(join(tmpdir(), 'kconnect install-é-'));
  let stop = async () => {};
  t.after(async () => { await stop(); rmSync(dir, { recursive: true, force: true }); });
  const app = join(dir, 'app');
  mkdirSync(app);
  writeFileSync(join(app, 'package.json'), '{"private":true}\n');

  const env = { ...process.env, npm_config_audit: 'false', npm_config_fund: 'false',
    npm_config_offline: 'true', npm_config_update_notifier: 'false' };
  const npm = (args, cwd = app) => exec(process.execPath, [process.env.npm_execpath, ...args], {
    cwd, env, timeout: 60_000,
  });
  const packed = await npm(['pack', root, '--ignore-scripts', '--pack-destination', dir, '--json'], dir);
  const pack = JSON.parse(packed.stdout);
  assert.equal(pack.length, 1);
  const tarball = join(dir, pack[0].filename);

  await npm(['install', '--ignore-scripts', '--no-audit', '--no-fund', tarball]);
  const installed = JSON.parse(readFileSync(join(app, 'node_modules/kerrigan-connect/package.json'), 'utf8'));
  assert.equal(installed.bin['kerrigan-connect'], './src/cli.js');

  const bin = process.platform === 'win32'
    ? join(app, 'node_modules/.bin/kerrigan-connect.cmd')
    : join(app, 'node_modules/.bin/kerrigan-connect');
  assert.ok(existsSync(bin), 'npm must generate the CLI shim');
  // npm exec handles its platform-specific shim; --offline prevents fetching a
  // missing command from a registry. All workflow inputs are synthetic/local.
  const cli = args => npm(['exec', '--offline', '--', 'kerrigan-connect', ...args]);
  const run = await cli(['quickstart']);
  const receipt = JSON.parse(run.stdout);
  assert.equal(receipt.tool, 'kerrigan-connect-quickstart');
  assert.equal(receipt.passed, true);
  assert.equal(receipt.mode, 'demo');
  assert.equal(receipt.real_krgn_spent, 0);

  // Load the installed server implementation, not checkout modules. An
  // ephemeral loopback listener avoids reserving a shared fixed port.
  const load = name => import(pathToFileURL(join(app, 'node_modules/kerrigan-connect/src', name)).href);
  const [{ Ledger }, { Gateway }, { DemoProvider, DemoPayments, DEMO_MODEL }, { createGatewayServer }] =
    await Promise.all(['ledger.js', 'gateway.js', 'demo.js', 'server.js'].map(load));
  env.KCONNECT_API_KEY = 'install-workflow-synthetic-key-123456';
  const database = join(dir, 'workflow.sqlite');
  let running;
  stop = async () => {
    if (!running) return;
    const { server, gateway, ledger } = running; running = null;
    server.closeAllConnections();
    await new Promise(resolve => server.close(resolve));
    await gateway.stop(); ledger.close();
  };
  const start = async () => {
    const ledger = new Ledger(database);
    const payments = new DemoPayments();
    const gateway = new Gateway({ ledger, provider: new DemoProvider(), payments,
      budgets: { dailyBudgetSats: 1_000_000, jobBudgetSats: 100_000, maxNetworkFeeSats: 1000 } });
    const server = createGatewayServer(gateway, { apiKey: env.KCONNECT_API_KEY });
    running = { server, gateway, ledger, payments };
    server.listen(0, '127.0.0.1'); await once(server, 'listening');
    return `http://127.0.0.1:${server.address().port}`;
  };
  let url = await start();
  for (const path of ['/start', '/start/style.css', '/start/app.js']) {
    assert.equal((await fetch(url + path)).status, 200, `${path} must be installed`);
  }
  const installedStatusResponse = await fetch(url + '/connect/first-use', {
    headers: { Authorization: `Bearer ${env.KCONNECT_API_KEY}` },
  });
  assert.equal(installedStatusResponse.status, 200);
  const installedStatus = await installedStatusResponse.json();
  assert.equal(installedStatus.processing.status, 'available_simulated');
  assert.equal(installedStatus.next.studio_ready, true);
  assert.equal(running.payments.payCalls, 0);
  const input = join(dir, 'support input.json');
  const dataset = JSON.parse(readFileSync(join(app, 'node_modules/kerrigan-connect/examples/task-packs/support-input.json'), 'utf8'));
  assert.ok(dataset.cases.every(item => !Object.hasOwn(item, 'expected')));
  writeFileSync(input, JSON.stringify(dataset));
  const result = join(dir, 'result.json'), replay = join(dir, 'replay.json');
  const runTask = output => cli(['task-run', '--input', input, '--output', output,
    '--run-id', 'installed-support-001', '--url', url, '--model', DEMO_MODEL]);
  await runTask(result);
  const first = JSON.parse(readFileSync(result, 'utf8'));
  assert.ok(first.rows.every(row => row.expected === null && row.validation.accepted && row.execution.simulated));
  assert.equal(running.payments.payCalls, dataset.cases.length);
  await stop(); url = await start();
  await runTask(replay);
  assert.deepEqual(JSON.parse(readFileSync(replay, 'utf8')).rows.map(row => row.job_id), first.rows.map(row => row.job_id));
  assert.equal(running.payments.payCalls, 0, 'restart replay must not pay again, even in simulation');
  const changed = structuredClone(dataset); changed.cases[0].source += ' A changed request.';
  writeFileSync(input, JSON.stringify(changed));
  await assert.rejects(runTask(join(dir, 'conflict.json')), error => /idempotency_conflict/.test(error.stderr));
  assert.equal(running.payments.payCalls, 0);

  const review = join(dir, 'review.json'), approved = join(dir, 'approved.json');
  const decided = join(dir, 'decided.json'), exported = join(dir, 'approved.jsonl');
  await cli(['task-review', '--input', result, '--output', review]);
  await assert.rejects(cli(['task-export', '--input', review, '--output', exported]), error => /nothing_approved/.test(error.stderr));
  assert.equal(existsSync(exported), false);
  await cli(['task-decide', '--input', review, '--output', approved, '--case-id', dataset.cases[0].id,
    '--decision', 'approved', '--reviewer', 'Install Reviewer']);
  await cli(['task-decide', '--input', approved, '--output', decided, '--case-id', dataset.cases[1].id,
    '--decision', 'rejected', '--reviewer', 'Install Reviewer']);
  await cli(['task-export', '--input', decided, '--output', exported]);
  const lines = readFileSync(exported, 'utf8').trim().split('\n').map(JSON.parse);
  assert.deepEqual(lines.map(row => row.id), [dataset.cases[0].id]);
  assert.equal(lines[0].provenance.job_id, first.rows[0].job_id);
  assert.equal(lines[0].provenance.simulated, true);
  assert.ok(lines.every(row => !Object.hasOwn(row, 'source') && !Object.hasOwn(row, 'expected')));

  // Exercise Studio from the installed tarball, including all browser modules
  // and durable batch recovery. This is HTTP evidence, not native rendering.
  for (const path of ['/studio', '/studio/style.css', '/studio/app.js', '/studio/review-core.js', '/studio/review-browser.js']) {
    assert.equal((await fetch(url + path)).status, 200, `${path} must be installed`);
  }
  const post = async (path, body, extra = {}) => {
    const response = await fetch(url + path, { method: 'POST', headers: {
      Authorization: `Bearer ${env.KCONNECT_API_KEY}`, 'Content-Type': 'application/json', ...extra,
    }, body: JSON.stringify(body) });
    assert.ok(response.ok, `${path}: HTTP ${response.status}`); return response.json();
  };
  const batch = await post('/studio/api/prepare', { format: 'kconnect-studio-batch', version: 1,
    run_id: 'installed-studio-1', model: DEMO_MODEL, taxonomy: ['Clothing', 'Uncategorised'],
    csv: 'id,description\nshirt-1,Blue cotton shirt size M\n' });
  const intent = batch.intents[0];
  const job = await post('/connect/jobs', intent.request, { 'Idempotency-Key': intent.key });
  await running.gateway.wait(job.id);
  const studioBefore = await post('/studio/api/review', { checkpoint: batch.checkpoint, job_ids: [job.id] });
  await stop(); url = await start();
  const recovered = await post('/studio/api/prepare', JSON.parse(JSON.stringify(batch.checkpoint)));
  assert.deepEqual(recovered.intents, batch.intents);
  const sameJob = await post('/connect/jobs', recovered.intents[0].request, { 'Idempotency-Key': recovered.intents[0].key });
  assert.equal(sameJob.id, job.id); assert.equal(running.payments.payCalls, 0);
  const studioAfter = await post('/studio/api/review', { checkpoint: recovered.checkpoint, job_ids: [sameJob.id] });
  assert.deepEqual(studioAfter, studioBefore);
  const { reviewLogic } = await load('review-core.js');
  reviewLogic().decide(studioAfter.session, 'shirt-1', 'approved');
  assert.match(reviewLogic().csv(studioAfter.session), /Blue cotton shirt/);
  await stop();
});
