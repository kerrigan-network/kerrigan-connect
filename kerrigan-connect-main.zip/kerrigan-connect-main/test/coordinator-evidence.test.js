import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { once } from 'node:events';
import { CoordinatorClient } from '../src/coordinator.js';

const txid = 'a'.repeat(64);
const blockHash = 'b'.repeat(64);
const drone = 'c'.repeat(40);
const modelHash = 'd'.repeat(16);
const refund = 'e'.repeat(64);
const invoice = { drone_pubkey_hash: drone, model_hash: modelHash, max_tokens: 128 };

async function coordinator(t, overrides = {}) {
  const calls = [];
  const server = createServer(async (req, res) => {
    calls.push({ method: req.method, path: req.url });
    res.setHeader('content-type', 'application/json');
    const base = req.url === '/v1/block/current' ? { height: 199990, hash: blockHash }
      : req.url === `/v1/tx/${txid}` ? { txid, hex: '01020304', confirmations: 2 }
      : req.url === `/v1/inference/${txid}` ? {
        payment_txid: txid, drone_pubkey_hash: drone, model_hash: modelHash,
        max_tokens: 128, params_hash: 'f'.repeat(8), block_height: 199980,
        change_txid: refund, escalation_txid: null, verdict_txid: null,
      } : { error: 'not found' };
    res.end(JSON.stringify({ ...base, ...(overrides[req.url] ?? {}) }));
  });
  server.listen(0, '127.0.0.1'); await once(server, 'listening');
  t.after(() => new Promise(resolve => { server.closeAllConnections(); server.close(resolve); }));
  return { calls, client: new CoordinatorClient({ coordinatorUrl: `http://127.0.0.1:${server.address().port}` }) };
}

test('GET-only chain evidence binds tip, exact transaction and invoice lifecycle', async t => {
  const { client, calls } = await coordinator(t);
  assert.deepEqual(await client.currentBlock(), { height: 199990, hash: blockHash });
  assert.deepEqual(await client.transaction(txid), { txid, hex: '01020304', confirmations: 2 });
  assert.equal(await client.rawTransaction(txid), '01020304');
  assert.deepEqual(await client.inferenceLifecycle(txid, invoice), {
    payment_txid: txid, block_height: 199980, params_hash: 'f'.repeat(8),
    refund_txid: refund, escalation_txid: null, verdict_txid: null,
    verification: 'coordinator_index_observation',
  });
  assert.ok(calls.every(x => x.method === 'GET'));
  assert.deepEqual(calls.map(x => x.path), [
    '/v1/block/current', `/v1/tx/${txid}`, `/v1/tx/${txid}`, `/v1/inference/${txid}`,
  ]);
});

test('malformed references and missing invoice cause no HTTP request', async t => {
  const { client, calls } = await coordinator(t);
  for (const bad of ['', 'A'.repeat(64), 'a'.repeat(63), '../block/current']) {
    await assert.rejects(client.transaction(bad), { code: 'invalid_payment_reference' });
    await assert.rejects(client.inferenceLifecycle(bad, invoice), { code: 'invalid_payment_reference' });
  }
  await assert.rejects(client.inferenceLifecycle(txid), { code: 'invalid_invoice' });
  assert.equal(calls.length, 0);
});

test('transaction evidence rejects mismatched identity, malformed hex and confirmations', async t => {
  for (const patch of [{ txid: 'f'.repeat(64) }, { hex: 'xyz' }, { confirmations: -1 }, { confirmations: 1.5 }]) {
    const { client } = await coordinator(t, { [`/v1/tx/${txid}`]: patch });
    await assert.rejects(client.transaction(txid), { code: 'invalid_upstream_response' });
  }
});

test('lifecycle mismatches never become refund or payment evidence', async t => {
  const cases = [
    { payment_txid: 'f'.repeat(64) }, { drone_pubkey_hash: 'f'.repeat(40) },
    { model_hash: 'f'.repeat(16) }, { max_tokens: 127 }, { params_hash: 'bad' },
    { block_height: -1 }, { change_txid: 'not-a-txid' },
  ];
  for (const patch of cases) {
    const { client } = await coordinator(t, { [`/v1/inference/${txid}`]: patch });
    await assert.rejects(client.inferenceLifecycle(txid, invoice), { code: 'lifecycle_mismatch' });
  }
});

test('invalid chain tip is not treated as an expiry observation', async t => {
  for (const patch of [{ height: -1 }, { height: 1.5 }, { hash: 'bad' }]) {
    const { client } = await coordinator(t, { '/v1/block/current': patch });
    await assert.rejects(client.currentBlock(), { code: 'invalid_upstream_response' });
  }
});
