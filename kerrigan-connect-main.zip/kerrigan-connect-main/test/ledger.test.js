import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { Ledger } from '../src/ledger.js';
import { Gateway } from '../src/gateway.js';
import { DemoProvider, DemoPayments } from '../src/demo.js';
import { normalizeRequest } from '../src/validation.js';
import { request, setup, budgets } from './helpers.js';

test('repeated concurrent submissions make one job and one simulated payment', async t => {
  const { gateway, payments, ledger } = setup(t);
  const first = gateway.submit(request(), 'same-key-0001');
  const repeated = Array.from({ length: 12 }, () => gateway.submit(request({ stream: true }), 'same-key-0001'));
  assert.ok(repeated.every(r => r.job.id === first.job.id && !r.created));
  const job = await gateway.wait(first.job.id);
  assert.equal(job.status, 'completed'); assert.equal(payments.payCalls, 1);
  assert.equal(job.result.simulated, true); assert.equal(job.result.verification, 'not_performed');
  assert.ok(job.refunded_sats > 0);
  assert.equal(ledger.budget().daily_committed_sats, job.paid_sats + job.network_fee_sats);
});

test('a changed request cannot reuse an idempotency key', async t => {
  const { gateway } = setup(t);
  gateway.submit(request(), 'conflict-0001');
  assert.throws(() => gateway.submit(request({ temperature: 1 }), 'conflict-0001'), { code: 'idempotency_conflict' });
});

test('per-job ceilings include the maximum network fee and block payment', async t => {
  const { gateway, payments, ledger } = setup(t);
  const { job } = gateway.submit(request({ budget_sats: 1500 }), 'small-budget-1');
  const result = await gateway.wait(job.id);
  assert.equal(result.status, 'failed'); assert.equal(result.error.code, 'job_budget_exceeded');
  assert.equal(payments.payCalls, 0); assert.equal(ledger.budget().reserved_sats, 0);
});

test('budget reservation is atomic across separate database connections', async t => {
  const dir = mkdtempSync(join(tmpdir(), 'kconnect-'));
  const path = join(dir, 'ledger.sqlite');
  const a = new Ledger(path), b = new Ledger(path);
  t.after(() => { a.close(); b.close(); rmSync(dir, { recursive: true, force: true }); });
  const one = a.create('reserve-0001', normalizeRequest(request())).job;
  const two = b.create('reserve-0002', normalizeRequest(request())).job;
  const limits = { ...budgets, dailyBudgetSats: 1500, maxNetworkFeeSats: 100 };
  a.reserve(one.id, { amount_sat: 1000 }, limits);
  assert.throws(() => b.reserve(two.id, { amount_sat: 1000 }, limits), { code: 'daily_budget_exceeded' });
  assert.equal(b.budget().daily_committed_sats, 1100);
});

test('outstanding reservations survive midnight; gross spend is not restored by refunds', t => {
  let now = new Date('2026-09-25T23:59:00Z');
  const ledger = new Ledger(':memory:', { now: () => now }); t.after(() => ledger.close());
  const j = ledger.create('midnight-0001', normalizeRequest(request())).job;
  ledger.reserve(j.id, { amount_sat: 1000 }, { ...budgets, maxNetworkFeeSats: 100 });
  ledger.beginPayment(j.id);
  now = new Date('2026-09-26T00:01:00Z');
  assert.equal(ledger.budget().daily_committed_sats, 1100);
  ledger.recordPayment(j.id, { txid: 'a'.repeat(64), amount_sats: 1000, fee_sats: 50 });
  ledger.confirmRefund(j.id, { txid: 'b'.repeat(64), amount_sats: 500 });
  assert.equal(ledger.budget().daily_committed_sats, 1050);
  assert.equal(ledger.view(j.id).net_cost_sats, 550);
});

test('an inference failure retries the recorded payment, never repays', async t => {
  class FlakyProvider extends DemoProvider {
    ids = [];
    async infer(req, invoice, txid) {
      this.ids.push(txid);
      if (this.ids.length === 1) throw new Error('connection lost with PRIVATE_PROMPT');
      return super.infer(req, invoice, txid);
    }
  }
  const provider = new FlakyProvider();
  const { gateway, payments } = setup(t, { provider });
  const { job } = gateway.submit(request(), 'retry-paid-0001');
  const failed = await gateway.wait(job.id);
  assert.equal(failed.status, 'needs_reconciliation');
  assert.ok(!JSON.stringify(failed.error).includes('PRIVATE_PROMPT'));
  gateway.retry(job.id);
  assert.equal((await gateway.wait(job.id)).status, 'completed');
  assert.equal(payments.payCalls, 1); assert.equal(new Set(provider.ids).size, 1);
});

test('unknown payment outcome remains reserved and refuses retry', async t => {
  const payments = { pay: async () => { throw new Error('broadcast timeout'); } };
  const { gateway, ledger } = setup(t, { payments });
  const { job } = gateway.submit(request(), 'unknown-pay-0001');
  assert.equal((await gateway.wait(job.id)).status, 'needs_reconciliation');
  assert.ok(ledger.budget().reserved_sats > 0);
  assert.throws(() => gateway.retry(job.id), { code: 'reconciliation_required' });
});

test('restart distinguishes unsubmitted quotes, unknown payments and paid execution', async t => {
  const dir = mkdtempSync(join(tmpdir(), 'kconnect-recovery-'));
  const path = join(dir, 'ledger.sqlite');
  let ledger = new Ledger(path);
  const provider = new DemoProvider();
  const req = normalizeRequest(request());
  const invoice = await provider.quote(req);
  const quoted = ledger.create('restart-quoted', req).job.id;
  ledger.reserve(quoted, invoice, budgets);
  const ambiguous = ledger.create('restart-pending', req).job.id;
  ledger.reserve(ambiguous, invoice, budgets); ledger.beginPayment(ambiguous);
  const paid = ledger.create('restart-running', req).job.id;
  ledger.reserve(paid, invoice, budgets); ledger.beginPayment(paid);
  ledger.recordPayment(paid, { txid: 'a'.repeat(64), amount_sats: invoice.amount_sat, fee_sats: 100 });
  ledger.beginInference(paid); ledger.close();
  ledger = new Ledger(path);
  const payments = new DemoPayments();
  const gateway = new Gateway({ ledger, provider, payments, budgets, autoStart: false });
  t.after(async () => { await gateway.stop(); ledger.close(); rmSync(dir, { recursive: true, force: true }); });
  assert.equal(ledger.get(quoted).status, 'queued');
  assert.equal(ledger.get(ambiguous).status, 'needs_reconciliation');
  assert.equal(ledger.get(paid).status, 'paid');
  gateway.kick();
  assert.equal((await gateway.wait(paid)).payment_txid, 'a'.repeat(64));
  assert.equal((await gateway.wait(quoted)).status, 'completed');
  assert.equal(payments.payCalls, 1);
});

test('refunds are unique, idempotent and cannot exceed the payment', async t => {
  const { gateway, ledger } = setup(t);
  const { job } = gateway.submit(request(), 'refund-0001');
  const done = await gateway.wait(job.id);
  const remaining = done.paid_sats - done.refunded_sats;
  const receipt = { txid: 'f'.repeat(64), amount_sats: remaining };
  ledger.confirmRefund(job.id, receipt); ledger.confirmRefund(job.id, receipt);
  assert.equal(ledger.get(job.id).refunded_sats, done.paid_sats);
  assert.throws(() => ledger.confirmRefund(job.id, { txid: 'e'.repeat(64), amount_sats: 1 }), { code: 'invalid_refund' });
  assert.throws(() => ledger.confirmRefund(job.id, { ...receipt, amount_sats: remaining - 1 }), { code: 'refund_conflict' });
});

test('cancel while quote is in flight prevents payment', async t => {
  let finishQuote, started;
  const startedPromise = new Promise(resolve => { started = resolve; });
  const finish = new Promise(resolve => { finishQuote = resolve; });
  class SlowProvider extends DemoProvider { async quote(req) { started(); await finish; return super.quote(req); } }
  const { gateway, ledger, payments } = setup(t, { provider: new SlowProvider() });
  const { job } = gateway.submit(request(), 'cancel-quote-01');
  await startedPromise; ledger.cancel(job.id); finishQuote();
  await gateway.active;
  assert.equal(ledger.get(job.id).status, 'cancelled'); assert.equal(payments.payCalls, 0);
});

test('purging content retains idempotency, spend and unresolved jobs', async t => {
  let now = new Date('2026-09-01T00:00:00Z');
  const ledger = new Ledger(':memory:', { now: () => now });
  const { gateway, payments } = setup(t, { ledger });
  const { job } = gateway.submit(request(), 'purge-0001');
  await gateway.wait(job.id);
  const paid = ledger.budget().total_paid_sats;
  now = new Date('2026-09-25T00:00:00Z');
  assert.equal(ledger.purgeContent(7), 1);
  const same = gateway.submit(request(), 'purge-0001');
  assert.equal(same.job.id, job.id); assert.equal(same.job.result, null);
  assert.equal(ledger.budget().total_paid_sats, paid); assert.equal(payments.payCalls, 1);
});

test('read-only mode cannot quote, spend or persist an inference request', async t => {
  const ledger = new Ledger(':memory:', { mode: 'read-only' });
  let quotes = 0;
  const { gateway } = setup(t, { ledger, mode: 'read-only', provider: { quote: async () => { quotes++; } } });
  assert.throws(() => gateway.submit(request(), 'read-only-01'), { code: 'live_spending_disabled' });
  assert.equal(quotes, 0); assert.equal(ledger.list().length, 0);
});

test('payment receipt must match the authorised invoice and fee ceiling', t => {
  const ledger = new Ledger(); t.after(() => ledger.close());
  const { job } = ledger.create('receipt-0001', normalizeRequest(request()));
  ledger.reserve(job.id, { amount_sat: 1000 }, { ...budgets, maxNetworkFeeSats: 100 }); ledger.beginPayment(job.id);
  assert.throws(() => ledger.recordPayment(job.id, { txid: 'a'.repeat(64), amount_sats: 1000, fee_sats: 101 }), { code: 'invalid_receipt' });
  assert.equal(ledger.get(job.id).status, 'payment_pending');
});
