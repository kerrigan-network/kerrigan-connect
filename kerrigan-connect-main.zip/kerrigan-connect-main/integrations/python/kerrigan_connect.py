"""Standard-library client for Connect's local gateway, not Kerrigan's wallet SDK."""
import http.client
import json
import math
import queue
import re
import threading
import time
from urllib.parse import urlsplit


class ConnectError(Exception):
    def __init__(self, code, status=None, job_id=None):
        super().__init__(f"Connect request failed: {code}. Preserve the intent key before retrying.")
        self.code, self.status, self.job_id = code, status, job_id


# A stalled DNS resolver must not create unlimited background threads.
_WORKERS = threading.BoundedSemaphore(8)


def _positive(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0 or value > 2147483647:
        raise ValueError("Limits must be finite positive numbers.")
    return value


class ConnectClient:
    def __init__(self, *, api_key, base_url="http://127.0.0.1:8787", timeout=15, max_response_bytes=2_000_000):
        url = urlsplit(base_url)
        if url.scheme not in ("http", "https") or not url.hostname or url.username or url.password or url.query or url.fragment:
            raise ValueError("Invalid gateway URL.")
        if url.scheme == "http" and url.hostname not in ("localhost", "127.0.0.1", "::1"):
            raise ValueError("Remote gateways require HTTPS.")
        if not isinstance(api_key, str) or not re.fullmatch(r"[\x21-\x7e]+", api_key):
            raise ValueError("A printable gateway API key is required.")
        if not isinstance(max_response_bytes, int):
            raise ValueError("Response size must be an integer.")
        self._url, self._api_key = url, api_key
        self.timeout = _positive(timeout)
        self.max_response_bytes = _positive(max_response_bytes)

    def _request(self, path, *, body=None, key=None, timeout=None):
        deadline = time.monotonic() + _positive(self.timeout if timeout is None else timeout)
        output = queue.Queue(maxsize=1)
        cancelled = threading.Event()
        if not _WORKERS.acquire(blocking=False):
            raise ConnectError("client_busy")

        def run():
            connection = None
            try:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise ConnectError("deadline_exceeded")
                cls = http.client.HTTPSConnection if self._url.scheme == "https" else http.client.HTTPConnection
                connection = cls(self._url.hostname, self._url.port, timeout=remaining)
                # Explicit connect lets us check the deadline after DNS/TLS, before sending credentials or a POST.
                connection.connect()
                if cancelled.is_set() or time.monotonic() >= deadline:
                    raise ConnectError("deadline_exceeded")
                connection.sock.settimeout(max(.001, deadline - time.monotonic()))
                headers = {"Authorization": f"Bearer {self._api_key}"}
                data = None
                if body is not None:
                    headers["Content-Type"] = "application/json"
                    data = json.dumps(body, allow_nan=False).encode("utf-8")
                if key is not None:
                    headers["Idempotency-Key"] = key
                connection.request("POST" if body is not None else "GET", self._url.path.rstrip("/") + path, data, headers)
                response = connection.getresponse()
                # http.client never follows redirects; do not relay credentials elsewhere.
                if 300 <= response.status < 400:
                    raise ConnectError("redirect_rejected", response.status)
                chunks, size = [], 0
                while True:
                    if cancelled.is_set() or time.monotonic() >= deadline:
                        raise ConnectError("deadline_exceeded")
                    chunk = response.read1(min(65536, self.max_response_bytes + 1 - size))
                    if not chunk:
                        break
                    size += len(chunk)
                    if size > self.max_response_bytes:
                        raise ConnectError("response_too_large")
                    chunks.append(chunk)
                try:
                    value = json.loads(b"".join(chunks))
                except (ValueError, UnicodeError):
                    raise ConnectError("invalid_response", response.status) from None
                if not isinstance(value, dict):
                    raise ConnectError("invalid_response", response.status)
                if not 200 <= response.status < 300:
                    error = value.get("error")
                    error = error if isinstance(error, dict) else {}
                    code = error.get("code")
                    code = code if isinstance(code, str) and re.fullmatch(r"[a-z_]{1,64}", code) else "http_error"
                    job_id = error.get("job_id")
                    job_id = job_id if isinstance(job_id, str) and re.fullmatch(r"job_[a-f0-9-]{36}", job_id) else None
                    raise ConnectError(code, response.status, job_id)
                output.put((value, None))
            except ConnectError as error:
                output.put((None, error))
            except TimeoutError:
                output.put((None, ConnectError("deadline_exceeded")))
            except Exception:
                output.put((None, ConnectError("transport_error")))
            finally:
                if connection:
                    connection.close()
                _WORKERS.release()

        # A daemon bounds caller wall time even during a stalled OS resolver/header read.
        # The worker checks expiry before sending and is capped globally; no retries occur.
        threading.Thread(target=run, daemon=True).start()
        try:
            value, error = output.get(timeout=max(.001, deadline - time.monotonic()))
        except queue.Empty:
            cancelled.set()
            raise ConnectError("deadline_exceeded") from None
        if time.monotonic() >= deadline:
            raise ConnectError("deadline_exceeded")
        if error:
            raise error
        return value

    def models(self):
        return self._request("/v1/models")

    def submit(self, request, intent_key):
        if not isinstance(intent_key, str) or not re.fullmatch(r"[A-Za-z0-9._:-]{8,160}", intent_key):
            raise ValueError("Supply an intent key of 8-160 letters, numbers, dots, underscores, colons or hyphens.")
        if not isinstance(request, dict):
            raise ValueError("A request object is required.")
        return self._request("/connect/jobs", body=request, key=intent_key)

    def job(self, job_id, *, timeout=None):
        if not isinstance(job_id, str) or not re.fullmatch(r"job_[a-f0-9-]{36}", job_id):
            raise ValueError("Invalid job ID.")
        return self._request(f"/connect/jobs/{job_id}", timeout=timeout)

    def wait(self, job_id, *, timeout=180, interval=.1):
        deadline = time.monotonic() + _positive(timeout)
        _positive(interval)
        while time.monotonic() < deadline:
            job = self.job(job_id, timeout=min(self.timeout, max(.001, deadline - time.monotonic())))
            if job.get("status") in ("completed", "failed", "cancelled", "needs_reconciliation"):
                return job
            time.sleep(min(interval, max(0, deadline - time.monotonic())))
        raise ConnectError("deadline_exceeded", job_id=job_id)
