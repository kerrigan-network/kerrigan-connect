# Kerrigan Connect for n8n

This directory is an installable, private n8n community-node package. It wraps the existing local Connect API; it does not implement a wallet, payment flow, inference client or alternate ledger.

## Install locally

Use Node 24.14–24.x and a local n8n installation. From this directory:

```sh
npm pack
mkdir -p "$N8N_USER_FOLDER/.n8n/nodes"
cd "$N8N_USER_FOLDER/.n8n/nodes"
npm install /absolute/path/to/n8n-nodes-kerrigan-connect-0.1.0.tgz
```

For an unpublished private package, point n8n's supported custom-extension loader at the installed package:

```sh
export N8N_CUSTOM_EXTENSIONS="$N8N_USER_FOLDER/.n8n/nodes/node_modules/n8n-nodes-kerrigan-connect"
n8n start
```

When loaded this way, imported workflow JSON uses `CUSTOM.kerriganConnect`; installation through n8n's community-package manager uses `n8n-nodes-kerrigan-connect.kerriganConnect`. The committed examples use the eventual package-manager name and the runtime verifier performs the private custom-extension translation explicitly. This is necessary because publication is outside the authorised build phase. Restart n8n after installation. The editor should list **Kerrigan Connect**.

Create a **Kerrigan Connect API** credential with the gateway origin and API key. Plain HTTP is accepted only for `localhost`, `127.0.0.1` or `[::1]`; a remote gateway must use HTTPS. An n8n Docker container has its own loopback, so `127.0.0.1` will not reach a gateway on the host. Do not work around that with a public tunnel.

## Operations

| Operation | Purpose | Recovery rule |
| --- | --- | --- |
| Discover Models | GET the models advertised by this configured gateway | Discovery is read-only; advertised is not proof of live availability. |
| Submit Job | POST an async job | The workflow owner must supply and persist the intent key before the first attempt. |
| Get Status | Read one durable job | Use the returned job ID; this never starts another job. |
| Get Result | Poll one job with bounded time and interval | A timeout means “still unknown”, not “submit again”. |
| Recover Intent | Replay the exact request and original intent key | A changed request deliberately returns `idempotency_conflict`. Never mint a replacement key to conceal an uncertain outcome. |

Each successful item includes `_kerrigan_n8n` with the operation, HTTP status, replay indication and returned location. With n8n’s **Continue On Fail**, errors are bounded objects containing only `code`, `message`, `status`, `job_id` and `retryable`; credentials and request bodies are not echoed.

Limits are explicit: 500 input items per node execution, 200,000 request bytes, 5 MB maximum response, 100–180,000 ms request/result deadlines, and 100–10,000 ms polling intervals. Redirects are refused. This node never chooses an upstream provider URL and never handles keys or payment transactions.

## Workflows

Import the disabled examples in `workflows/`:

- `catalogue-job.json` submits one simulated catalogue job with a fixed, retained demonstration intent and polls that job to a terminal state.
- `recover-intent.json` shows the lost-response path: replay the exact request with the original intent key, then inspect the returned durable job.

After import, select your own Kerrigan credential on every Kerrigan Connect node. The older `catalogue-demo.json` remains as the HTTP Request baseline. All examples are disabled and use Connect’s simulated demo model. No real GPU work, KRGN spend or live-network validation is implied.
