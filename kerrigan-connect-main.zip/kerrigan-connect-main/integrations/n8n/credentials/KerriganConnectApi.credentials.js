class KerriganConnectApi {
  constructor() {
    this.name = 'kerriganConnectApi';
    this.displayName = 'Kerrigan Connect API';
    this.documentationUrl = 'https://github.com/BoltBlew/kerrigan-connect/blob/main/integrations/n8n/README.md';
    this.properties = [
      {
        displayName: 'Gateway URL',
        name: 'baseUrl',
        type: 'string',
        default: 'http://127.0.0.1:8787',
        required: true,
        description: 'Local Connect gateway. Plain HTTP is accepted only for localhost.',
      },
      {
        displayName: 'API Key',
        name: 'apiKey',
        type: 'string',
        typeOptions: { password: true },
        default: '',
        required: true,
      },
    ];
    this.authenticate = {
      type: 'generic',
      properties: { headers: { Authorization: '=Bearer {{$credentials.apiKey}}' } },
    };
    this.test = { request: { baseURL: '={{$credentials.baseUrl}}', url: '/connect/status' } };
  }
}

module.exports = { KerriganConnectApi };
