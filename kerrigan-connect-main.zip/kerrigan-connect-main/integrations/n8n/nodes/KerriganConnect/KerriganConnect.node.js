const { connectRequest, intentKey, jobId, requestBody, waitForResult, KerriganN8nError } = require('../../lib/client');

const operationOptions = [
  { name: 'Discover Models', value: 'models', description: 'Read the models advertised by this configured Connect gateway', action: 'Discover models' },
  { name: 'Submit Job', value: 'submit', description: 'Submit a durable job with a caller-owned intent key', action: 'Submit a job' },
  { name: 'Get Status', value: 'status', description: 'Read the latest durable state of a job', action: 'Get job status' },
  { name: 'Get Result', value: 'result', description: 'Poll a known job until it reaches a terminal state', action: 'Get job result' },
  { name: 'Recover Intent', value: 'recover', description: 'Replay the exact request with its original intent key after an uncertain submission', action: 'Recover an intent' },
];

class KerriganConnect {
  constructor() {
    this.description = {
      displayName: 'Kerrigan Connect',
      name: 'kerriganConnect',
      icon: 'file:kerrigan.svg',
      group: ['transform'],
      version: 1,
      subtitle: '={{$parameter["operation"]}}',
      description: 'Discover, submit, inspect and safely recover local Kerrigan Connect jobs',
      defaults: { name: 'Kerrigan Connect' },
      inputs: ['main'],
      outputs: ['main'],
      usableAsTool: false,
      credentials: [{ name: 'kerriganConnectApi', required: true }],
      properties: [
        { displayName: 'Operation', name: 'operation', type: 'options', noDataExpression: true, options: operationOptions, default: 'models' },
        {
          displayName: 'Intent Key', name: 'intentKey', type: 'string', default: '', required: true,
          description: 'A stable key created by the workflow owner before the first attempt. Keep it unchanged across retries and recovery.',
          displayOptions: { show: { operation: ['submit', 'recover'] } },
        },
        {
          displayName: 'Request JSON', name: 'requestJson', type: 'json', default: '{\n  "model": "demo/catalogue-v1",\n  "messages": [{"role": "user", "content": "Hello"}],\n  "max_tokens": 128\n}', required: true,
          displayOptions: { show: { operation: ['submit', 'recover'] } },
        },
        {
          displayName: 'Job ID', name: 'jobId', type: 'string', default: '', required: true,
          displayOptions: { show: { operation: ['status', 'result'] } },
        },
        {
          displayName: 'Result Timeout (ms)', name: 'resultTimeoutMs', type: 'number', default: 180000,
          typeOptions: { minValue: 100, maxValue: 180000 },
          displayOptions: { show: { operation: ['result'] } },
        },
        {
          displayName: 'Poll Interval (ms)', name: 'pollIntervalMs', type: 'number', default: 500,
          typeOptions: { minValue: 100, maxValue: 10000 },
          displayOptions: { show: { operation: ['result'] } },
        },
        {
          displayName: 'Request Timeout (ms)', name: 'requestTimeoutMs', type: 'number', default: 15000,
          typeOptions: { minValue: 100, maxValue: 180000 },
        },
      ],
    };
  }

  async execute() {
    const items = this.getInputData();
    if (items.length > 500) throw new Error('Kerrigan Connect accepts at most 500 n8n input items per execution. Split larger batches.');
    const credentials = await this.getCredentials('kerriganConnectApi');
    const output = [];
    for (let index = 0; index < items.length; index++) {
      try {
        const operation = this.getNodeParameter('operation', index);
        const requestTimeoutMs = this.getNodeParameter('requestTimeoutMs', index, 15000);
        let response;
        if (operation === 'models') {
          response = await connectRequest(credentials, '/v1/models', { timeoutMs: requestTimeoutMs });
        } else if (operation === 'submit' || operation === 'recover') {
          const key = intentKey(this.getNodeParameter('intentKey', index));
          const body = requestBody(this.getNodeParameter('requestJson', index));
          response = await connectRequest(credentials, '/connect/jobs', { method: 'POST', body, key, timeoutMs: requestTimeoutMs });
        } else if (operation === 'status') {
          const id = jobId(this.getNodeParameter('jobId', index));
          response = await connectRequest(credentials, `/connect/jobs/${id}`, { timeoutMs: requestTimeoutMs });
        } else if (operation === 'result') {
          response = await waitForResult(credentials, this.getNodeParameter('jobId', index), {
            timeoutMs: this.getNodeParameter('resultTimeoutMs', index, 180000),
            pollIntervalMs: this.getNodeParameter('pollIntervalMs', index, 500),
          });
        } else {
          throw new KerriganN8nError('invalid_operation', 'Unsupported Kerrigan Connect operation.');
        }
        output.push({ json: { ...response.body, _kerrigan_n8n: { operation, http_status: response.status, replayed: response.replayed, location: response.location || null } }, pairedItem: { item: index } });
      } catch (error) {
        const safe = error instanceof KerriganN8nError ? error.json() : { code: 'node_error', message: 'Kerrigan Connect node failed.', status: null, job_id: null, retryable: false };
        if (this.continueOnFail()) output.push({ json: { error: safe }, pairedItem: { item: index } });
        else {
          const wrapped = new Error(`${safe.code}: ${safe.message}`);
          wrapped.cause = error;
          throw wrapped;
        }
      }
    }
    return [output];
  }
}

module.exports = { KerriganConnect };
