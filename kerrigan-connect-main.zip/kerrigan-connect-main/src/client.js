import { setTimeout as delay } from 'node:timers/promises';
import { performance } from 'node:perf_hooks';
import { idempotencyKey } from './validation.js';

export class ClientError extends Error {
  constructor(code, status = null, jobId = undefined) {
    super(`Connect request failed: ${code}. Preserve the intent key before retrying.`);
    this.name = 'ClientError'; this.code = code; this.status = status; this.jobId = jobId;
  }
}
function positive(value) {
  if (!Number.isSafeInteger(value) || value < 1 || value > 2_147_483_647) throw new Error('Limits must be positive bounded integers.');
  return value;
}

/** Small client for the local gateway, not the Swarm wire protocol. */
export class ConnectClient {
  constructor({ baseUrl = 'http://127.0.0.1:8787', apiKey, fetchImpl = fetch, timeoutMs = 15_000, maxResponseBytes = 2_000_000 } = {}) {
    const url = new URL(baseUrl);
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) throw new Error('Invalid gateway URL.');
    if (url.protocol === 'http:' && !['localhost', '127.0.0.1', '[::1]'].includes(url.hostname)) throw new Error('Remote gateways require HTTPS.');
    if (typeof apiKey !== 'string' || !/^[\x21-\x7e]+$/.test(apiKey)) throw new Error('A printable gateway API key is required.');
    this.baseUrl = baseUrl.replace(/\/$/, ''); this.apiKey = apiKey; this.fetchImpl = fetchImpl; this.timeoutMs = positive(timeoutMs);
    this.maxResponseBytes = positive(maxResponseBytes);
  }
  async request(path, { method = 'GET', body, key, timeoutMs = this.timeoutMs } = {}) {
    if (!/^\/(?:v1|connect)\/[A-Za-z0-9_/-]+$/.test(path)) throw new Error('Invalid gateway path.');
    const signal = AbortSignal.timeout(positive(timeoutMs));
    try {
      const response = await this.fetchImpl(`${this.baseUrl}${path}`, {
        method, redirect: 'error', signal,
        headers: { authorization: `Bearer ${this.apiKey}`, ...(body ? { 'content-type': 'application/json' } : {}), ...(key ? { 'Idempotency-Key': key } : {}) },
        ...(body ? { body: JSON.stringify(body) } : {}),
      });
      const chunks = []; let bytes = 0;
      for await (const chunk of response.body) {
        bytes += chunk.length;
        if (bytes > this.maxResponseBytes) throw new ClientError('response_too_large');
        chunks.push(chunk);
      }
      let value;
      try { value = JSON.parse(Buffer.concat(chunks).toString('utf8')); }
      catch { throw new ClientError('invalid_response', response.status); }
      if (!value || typeof value !== 'object' || Array.isArray(value)) throw new ClientError('invalid_response', response.status);
      if (!response.ok) {
        const code = /^[a-z_]{1,64}$/.test(value.error?.code) ? value.error.code : 'http_error';
        const jobId = /^job_[a-f0-9-]{36}$/.test(value.error?.job_id) ? value.error.job_id : undefined;
        throw new ClientError(code, response.status, jobId);
      }
      return value;
    } catch (error) {
      if (signal.aborted) throw new ClientError('deadline_exceeded');
      if (error instanceof ClientError) throw error;
      throw new ClientError('transport_error');
    }
  }
  models() { return this.request('/v1/models'); }
  submit(request, key) { return this.request('/connect/jobs', { method: 'POST', body: request, key: idempotencyKey(key) }); }
  job(id) { return this.request(`/connect/jobs/${encodeURIComponent(id)}`); }
  async wait(id, { timeoutMs = 180_000, intervalMs = 100 } = {}) {
    const deadline = performance.now() + positive(timeoutMs); positive(intervalMs);
    while (performance.now() < deadline) {
      const job = await this.request(`/connect/jobs/${encodeURIComponent(id)}`, { timeoutMs: Math.max(1, Math.ceil(Math.min(this.timeoutMs, deadline - performance.now()))) });
      if (['completed', 'failed', 'cancelled', 'needs_reconciliation'].includes(job.status)) return job;
      await delay(Math.min(intervalMs, Math.max(0, deadline - performance.now())));
    }
    throw new ClientError('deadline_exceeded', null, id);
  }
}
