import { createHash } from 'node:crypto';
import { ConnectError, requireThat } from './errors.js';
import { sats } from './validation.js';

// Public Kerrigan SDK revision inspected when this adapter was implemented.
// This is provenance, not a runtime attestation of an injected module.
export const KERRIGAN_SDK_REVISION = 'ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29';

const hex = (value, bytes) => typeof value === 'string'
  && new RegExp(`^[a-f0-9]{${bytes * 2}}$`).test(value);
const uint32 = value => Number.isInteger(value) && value >= 0 && value <= 0xffffffff;

function validateInvoice(invoice) {
  requireThat(invoice && typeof invoice === 'object' && !Array.isArray(invoice)
    && typeof invoice.pay_to_address === 'string' && /^K[1-9A-HJ-NP-Za-km-z]{25,34}$/.test(invoice.pay_to_address)
    && sats(invoice.amount_sat, 'Invoice amount') > 0
    && hex(invoice.drone_pubkey_hash, 20) && hex(invoice.model_hash, 8)
    && Number.isInteger(invoice.max_tokens) && invoice.max_tokens > 0 && invoice.max_tokens <= 0xffff,
  'invalid_invoice', 'Invoice is incompatible with the maintained SDK payment builder.', 502);
  return {
    pay_to_address: invoice.pay_to_address,
    amount_sat: sats(invoice.amount_sat, 'Invoice amount'),
    drone_pubkey_hash: invoice.drone_pubkey_hash,
    model_hash: invoice.model_hash,
    max_tokens: invoice.max_tokens,
  };
}

function validateParams(request, invoice) {
  requireThat(request && typeof request === 'object' && request.max_tokens === invoice.max_tokens
    && typeof request.temperature === 'number' && Number.isFinite(request.temperature)
    && typeof request.top_p === 'number' && Number.isFinite(request.top_p)
    && Number.isSafeInteger(request.seed) && request.seed >= 0
    && Number.isInteger(request.k) && request.k >= 0 && request.k <= 0xff,
  'invoice_binding_changed', 'Sampling parameters or token limit differ from the saved invoice.', 409);
  // The maintained wrapper calls this field topP; the coordinator wire uses top_p.
  return { temperature: request.temperature, topP: request.top_p, seed: request.seed, k: request.k };
}

function validateSession(session) {
  requireThat(session && typeof session === 'object' && Array.isArray(session.utxos)
    && session.utxos.length > 0 && session.utxos.length <= 1000
    && session.seed instanceof Uint8Array && session.seed.length >= 16 && session.seed.length <= 128
    && uint32(session.account ?? 0) && uint32(session.index ?? 0),
  'invalid_wallet_session', 'Wallet session is missing bounded UTXOs, seed bytes or derivation indices.');
  const seen = new Set();
  const utxos = session.utxos.map(value => {
    requireThat(value && typeof value === 'object' && hex(value.txid, 32) && uint32(value.vout)
      && sats(value.amount, 'UTXO amount') > 0 && typeof value.script_pubkey === 'string'
      && /^(?:[a-f0-9]{2}){1,10000}$/.test(value.script_pubkey),
    'invalid_wallet_session', 'Wallet session contains an invalid UTXO.');
    const key = `${value.txid}:${value.vout}`;
    requireThat(!seen.has(key), 'invalid_wallet_session', 'Wallet session contains duplicate UTXOs.');
    seen.add(key);
    return { txid: value.txid, vout: value.vout, amount: sats(value.amount, 'UTXO amount'), script_pubkey: value.script_pubkey };
  });
  return { utxos, seed: session.seed, account: session.account ?? 0, index: session.index ?? 0, available: seen };
}

function transactionId(txHex) {
  const first = createHash('sha256').update(Buffer.from(txHex, 'hex')).digest();
  return Buffer.from(createHash('sha256').update(first).digest()).reverse().toString('hex');
}

function validateResult(result, available) {
  requireThat(result && typeof result === 'object' && hex(result.txid, 32)
    && typeof result.tx_hex === 'string' && /^(?:[a-f0-9]{2}){1,100000}$/.test(result.tx_hex)
    && transactionId(result.tx_hex) === result.txid
    && Array.isArray(result.spent_utxos) && result.spent_utxos.length > 0 && result.spent_utxos.length <= 1000,
  'invalid_prepared_payment', 'Maintained SDK returned an invalid or inconsistent payment transaction.', 502);
  const seen = new Set();
  const spent_utxos = result.spent_utxos.map(input => {
    requireThat(Array.isArray(input) && input.length === 2 && hex(input[0], 32) && uint32(input[1]),
      'invalid_prepared_payment', 'Maintained SDK returned an invalid spent input.', 502);
    const key = `${input[0]}:${input[1]}`;
    requireThat(available.has(key) && !seen.has(key), 'invalid_prepared_payment',
      'Maintained SDK returned an unavailable or duplicate spent input.', 502);
    seen.add(key);
    return [input[0], input[1]];
  });
  return { txid: result.txid, tx_hex: result.tx_hex, fee: sats(result.fee, 'Prepared fee'), spent_utxos };
}

/**
 * Adapts Kerrigan webwallet's maintained buildInferencePaymentTx interface to
 * PreparedPaymentRecovery.prepare. The wallet host owns the signing session:
 * this object never derives, serialises or retains mnemonic/private-key data.
 */
export class MaintainedSdkPaymentPreparer {
  constructor({ sdk, withSigningSession }) {
    requireThat(sdk && typeof sdk.init === 'function' && typeof sdk.buildInferencePaymentTx === 'function'
      && typeof withSigningSession === 'function', 'invalid_config',
    'SDK preparation requires the maintained wrapper and an owner-controlled signing session.');
    this.sdk = sdk;
    this.withSigningSession = withSigningSession;
    this.initializing = null;
  }

  async initialize() {
    if (!this.initializing) {
      this.initializing = Promise.resolve().then(() => this.sdk.init()).catch(error => {
        this.initializing = null;
        throw error;
      });
    }
    try { await this.initializing; }
    catch { throw new ConnectError('sdk_unavailable', 'Kerrigan SDK could not be initialized; no payment was prepared.', 503); }
  }

  async prepare({ invoice, request }) {
    const sdkInvoice = validateInvoice(invoice);
    const params = validateParams(request, sdkInvoice);
    await this.initialize();
    let calls = 0;
    let available = null;
    try {
      const output = await this.withSigningSession(async supplied => {
        calls++;
        requireThat(calls === 1, 'invalid_wallet_session', 'Signing session invoked the payment callback more than once.');
        const session = validateSession(supplied);
        available = session.available;
        const result = await this.sdk.buildInferencePaymentTx(
          structuredClone(session.utxos), structuredClone(sdkInvoice), structuredClone(params),
          session.seed, session.account, session.index,
        );
        return validateResult(result, session.available);
      });
      requireThat(calls === 1, 'invalid_wallet_session', 'Signing session did not invoke the payment callback.');
      return validateResult(output, available);
    } catch (error) {
      if (error instanceof ConnectError) throw error;
      throw new ConnectError('payment_preparation_failed', 'Kerrigan SDK did not prepare a payment; no transaction was saved or broadcast.', 502);
    }
  }
}
