import { createHash } from 'node:crypto';
import { requireThat } from './errors.js';

export const DEMO_MODEL = 'demo/catalogue-v1';
const txhash = text => createHash('sha256').update(text).digest('hex');
function supportDemo(source) {
  const urgent = /locked out|security|fraud|charged twice|cannot access/i.test(source);
  const category = /invoice|charged|refund|payment/i.test(source) ? 'billing' : /login|password|account|locked out/i.test(source) ? 'account'
    : /error|crash|sync|upload|download/i.test(source) ? 'technical' : /delivery|parcel|shipping|arrive/i.test(source) ? 'shipping' : 'other';
  const evidence = source.match(/[^.!?]*(?:locked out|security|fraud|charged twice|cannot access|invoice|refund|payment|login|password|account|error|crash|sync|upload|download|delivery|parcel|shipping|arrive)[^.!?]*[.!?]?/i)?.[0]?.trim() || source.slice(0, 200);
  return { priority: urgent ? 'urgent' : /today|soon|failed|overdue/i.test(source) ? 'high' : 'medium', category,
    summary: `Review ${category} support request.`, evidence, next_action: `Route to a human ${category} reviewer; do not contact the customer automatically.`, needs_human: true };
}
function documentDemo(source) {
  const type = /invoice/i.test(source) ? 'invoice' : /purchase order|\bPO\b/i.test(source) ? 'purchase_order' : /receipt/i.test(source) ? 'receipt' : 'unknown';
  const match = pattern => source.match(pattern)?.[1] ?? null;
  const fields = {
    document_number: match(/(?:Invoice(?: number| no\.?| #)?|Purchase Order|PO(?: number| no\.?| #)?|Receipt(?: number| no\.?| #)?)\s*[:#-]?\s*([A-Za-z0-9_-]+)/i),
    date: match(/(?:Date)\s*[:#-]?\s*(\d{4}-\d{2}-\d{2}|\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4})/i),
    total: match(/(?:Total)\s*[:#-]?\s*([£$€]?\s?\d{1,3}(?:,\d{3})*(?:\.\d{2})?|[£$€]?\s?\d+(?:[,.]\d{2})?)/i),
    currency: match(/(?:Currency)\s*[:#-]?\s*([A-Z]{3})/),
    supplier: match(/(?:Supplier)\s*[:#-]?\s*([^\n\r]+)/i),
  };
  const evidence = Object.fromEntries(Object.entries(fields).map(([key, value]) => [key, value]));
  return { document_type: type, fields, evidence, missing_fields: Object.keys(fields).filter(k => fields[k] === null) };
}

export class DemoProvider {
  async models() {
    return [{
      id: DEMO_MODEL, object: 'model', created: 0, owned_by: 'kerrigan-connect-demo',
      x_kerrigan: {
        simulated: true, context_length: 16384, drones: ['d'.repeat(40)],
        capabilities: { chat: true, tools: false, embeddings: false, confidentiality: 'local_demo' },
      },
    }];
  }
  async quote(request) {
    requireThat(request.model === DEMO_MODEL, 'model_unavailable', 'Use demo/catalogue-v1 in demo mode.', 404);
    const promptTokens = Math.ceil(request.messages.reduce((n, m) => n + m.content.length, 0) / 4);
    return {
      amount_sat: promptTokens + request.max_tokens * 10,
      prompt_tokens: promptTokens, max_tokens: request.max_tokens, rate_sat_per_token: 10,
      pay_to_address: 'DEMO-NO-REAL-ADDRESS', drone_pubkey_hash: 'd'.repeat(40),
      model_hash: '0'.repeat(16), expires_block: 200000, simulated: true,
    };
  }
  async infer(request, invoice) {
    const user = request.messages.filter(m => m.role === 'user').at(-1).content;
    let content;
    try {
      const payload = JSON.parse(user);
      if (payload.task === 'support-triage' && typeof payload.source === 'string') {
        content = JSON.stringify(supportDemo(payload.source));
      } else if (payload.task === 'document-extraction' && typeof payload.source === 'string') {
        content = JSON.stringify(documentDemo(payload.source));
      } else {
      requireThat(payload.task === 'catalogue' && payload.product && Array.isArray(payload.taxonomy), 'demo_input', 'Unknown demo payload.');
      const product = payload.product;
      const description = String(product.description || '');
      const rules = [
        ['Electronics', /\b(usb|headphone|keyboard|charger|bluetooth|speaker)\b/i],
        ['Clothing', /\b(shirt|jacket|trouser|cotton|hoodie|socks)\b/i],
        ['Home & Kitchen', /\b(mug|bottle|pan|plate|kettle|towel)\b/i],
        ['Sports & Outdoors', /\b(yoga|tent|camping|football|dumbbell)\b/i],
      ];
      const category = rules.find(([name, pattern]) => payload.taxonomy.includes(name) && pattern.test(description))?.[0] || 'Uncategorised';
      const colour = description.match(/\b(black|white|blue|red|green|silver|grey|yellow)\b/i)?.[0]?.toLowerCase() || null;
      const material = description.match(/\b(stainless steel|cotton|ceramic|aluminium|plastic|leather)\b/i)?.[0]?.toLowerCase() || null;
      const size = description.match(/\b\d+(?:\.\d+)?\s?(?:ml|litre|litres|cm|kg|inch|inches)\b/i)?.[0] || null;
      const missing = ['colour', 'material', 'size'].filter(k => ({ colour, material, size })[k] === null);
      content = JSON.stringify({ category, attributes: { colour, material, size }, flags: missing.map(k => `missing_${k}`) });
      }
    } catch {
      content = 'Simulated response from Kerrigan Connect. No GPU was used and no KRGN was spent. Use the catalogue example to exercise structured batch processing.';
    }
    const tokenCount = Math.ceil(content.length / 4);
    const truncated = tokenCount > request.max_tokens;
    if (truncated) content = content.slice(0, request.max_tokens * 4);
    return {
      content, finish_reason: truncated ? 'length' : 'stop', simulated: true, verification: 'not_performed',
      usage: { prompt_tokens: invoice.prompt_tokens, completion_tokens: Math.min(tokenCount, request.max_tokens), total_tokens: invoice.prompt_tokens + Math.min(tokenCount, request.max_tokens) },
      usage_estimated: true,
    };
  }
}

export class DemoPayments {
  constructor() { this.payCalls = 0; }
  async pay({ jobId, invoice }) {
    requireThat(invoice.simulated === true, 'live_spending_disabled', 'The demo backend refuses real invoices.', 503);
    this.payCalls++;
    return { txid: txhash(`demo-payment:${jobId}`), amount_sats: invoice.amount_sat, fee_sats: 100, simulated: true };
  }
  async refund({ jobId, invoice, result }) {
    const amount = (invoice.max_tokens - result.usage.completion_tokens) * invoice.rate_sat_per_token;
    return amount > 0 ? { txid: txhash(`demo-refund:${jobId}`), amount_sats: amount, simulated: true } : null;
  }
}
