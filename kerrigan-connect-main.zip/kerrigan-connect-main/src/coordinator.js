import { ConnectError, requireThat } from './errors.js';
import { sats, fingerprint } from './validation.js';

const validModelName = name => typeof name === 'string' && name.trim().length > 0
  && name.length <= 256 && !/[\u0000-\u001f\u007f]/.test(name);
const validTxid = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
const nullableTxid = value => value == null || validTxid(value);

export async function fetchJson(url, { method = 'GET', body, fetchImpl = fetch, timeoutMs = 15_000 } = {}) {
  let response;
  try {
    response = await fetchImpl(url, {
      method, redirect: 'error', signal: AbortSignal.timeout(timeoutMs),
      headers: { accept: 'application/json', ...(body ? { 'content-type': 'application/json' } : {}) },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
    requireThat(response.ok, 'upstream_unavailable', `Coordinator request failed with HTTP ${response.status}.`, 502);
    let bytes = 0;
    const chunks = [];
    for await (const chunk of response.body) {
      bytes += chunk.length;
      if (bytes > 2_000_000) throw new ConnectError('upstream_response_too_large', 'Upstream response exceeded 2 MB.', 502);
      chunks.push(chunk);
    }
    const value = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    requireThat(value && typeof value === 'object' && !Array.isArray(value), 'invalid_upstream_response', 'Expected an upstream JSON object.', 502);
    requireThat(!value.error, 'upstream_rejected', 'The provider rejected the request.', 502);
    return value;
  } catch (error) {
    if (error instanceof ConnectError) throw error;
    throw new ConnectError('upstream_unavailable', 'Upstream connection timed out or returned invalid JSON.', 502);
  }
}

export class CoordinatorClient {
  constructor({ coordinatorUrl = 'https://coordinator.jskitty.com', explorerUrl = 'https://explorer.kerrigan.network', fetchImpl = fetch } = {}) {
    this.coordinatorUrl = coordinatorUrl;
    this.explorerUrl = explorerUrl;
    this.fetchImpl = fetchImpl;
  }
  get(path) { return fetchJson(`${this.coordinatorUrl}${path}`, { fetchImpl: this.fetchImpl }); }
  post(path, body) { return fetchJson(`${this.coordinatorUrl}${path}`, { method: 'POST', body, fetchImpl: this.fetchImpl, timeoutMs: 120_000 }); }
  async models() {
    const body = await this.get('/v1/models');
    requireThat(Array.isArray(body.models) && body.models.length <= 1000, 'invalid_upstream_response', 'Invalid model catalogue.', 502);
    return body.models.map(model => {
      const drones = model.drones ?? model.providers;
      requireThat(model.name == null || validModelName(model.name),
        'invalid_upstream_response', 'Model name is invalid.', 502);
      requireThat(typeof model.id === 'string' && /^[A-Za-z0-9_.:/-]{1,180}$/.test(model.id)
        && Array.isArray(drones) && drones.every(x => typeof x === 'string' && /^[a-f0-9]{40}$/.test(x))
        && Number.isInteger(model.context_length) && model.context_length > 0,
        'invalid_upstream_response', 'Model capability data is incomplete.', 502);
      return {
        id: model.id, object: 'model', created: 0, owned_by: 'kerrigan-swarm',
        x_kerrigan: {
          simulated: false, context_length: model.context_length, drones,
          // The maintained wallet uses name on the wire, not the catalogue ID.
          model_name: model.name ?? null,
          quant: typeof model.quant === 'string' ? model.quant : null,
          // Advertised catalogue metadata; useful for memory planning, not proof of host compatibility.
          vram_required_mb: model.vram_required_mb == null ? null : (() => {
            requireThat(Number.isInteger(model.vram_required_mb) && model.vram_required_mb > 0 && model.vram_required_mb <= 1_000_000,
              'invalid_upstream_response', 'Model VRAM requirement is invalid.', 502);
            return model.vram_required_mb;
          })(),
          rate_sat_per_token: model.rate_sat_per_token == null ? null : sats(model.rate_sat_per_token, 'Output rate'),
          in_rate_sat_per_token: model.in_rate_sat_per_token == null ? null : sats(model.in_rate_sat_per_token, 'Input rate'),
          rates_observed: { input: model.in_rate_sat_per_token != null, output: model.rate_sat_per_token != null },
          advertised_capabilities: Object.fromEntries(['chat', 'tools', 'embeddings', 'vision', 'structured_output', 'streaming', 'confidentiality']
            .filter(key => typeof model.capabilities?.[key] === 'boolean').map(key => [key, model.capabilities[key]])),
          // The historical gateway compatibility flags below are adapter policy, not provider evidence.
          capabilities_source: 'connect_adapter_assumptions',
          capabilities: { chat: true, tools: false, embeddings: false, confidentiality: 'unverified' },
        },
      };
    });
  }
  async probe() {
    // Read-only, no prompts, invoices, signing or transaction broadcasting.
    const results = await Promise.allSettled([
      this.models(), this.get('/v1/node-id'),
      fetchJson(`${this.explorerUrl}/api/network-stats`, { fetchImpl: this.fetchImpl }),
    ]);
    const [models, node, chain] = results;
    return {
      observed_at: new Date().toISOString(), coordinator: this.coordinatorUrl,
      scope: 'One configured coordinator; not a census of the entire network.',
      models: models.status === 'fulfilled' ? models.value : null,
      connected_drones: node.status === 'fulfilled' ? node.value.connected_drones ?? null : null,
      chain: chain.status === 'fulfilled' ? {
        height: chain.value.height, version: chain.value.subversion,
        drone_payout_active: chain.value.subsidy?.drone_payout_active ?? null,
      } : null,
      errors: results.flatMap((r, i) => r.status === 'rejected' ? [{ source: ['models','coordinator','explorer'][i], code: r.reason.code || 'unavailable' }] : []),
    };
  }
  async currentBlock() {
    const value = await this.get('/v1/block/current');
    requireThat(Number.isSafeInteger(value.height) && value.height >= 0 && validTxid(value.hash),
      'invalid_upstream_response', 'Coordinator returned an invalid chain tip.', 502);
    return { height: value.height, hash: value.hash };
  }
  async transaction(txid) {
    requireThat(validTxid(txid), 'invalid_payment_reference', 'Transaction lookup requires a lowercase 64-character reference.');
    const value = await this.get(`/v1/tx/${txid}`);
    requireThat(value.txid === txid && typeof value.hex === 'string'
      && /^(?:[a-f0-9]{2}){1,100000}$/.test(value.hex)
      && (value.confirmations == null || (Number.isSafeInteger(value.confirmations) && value.confirmations >= 0)),
      'invalid_upstream_response', 'Coordinator returned invalid transaction evidence.', 502);
    return { txid, hex: value.hex, confirmations: value.confirmations ?? null };
  }
  async rawTransaction(txid) { return (await this.transaction(txid)).hex; }
  async inferenceLifecycle(txid, invoice) {
    requireThat(validTxid(txid), 'invalid_payment_reference', 'Lifecycle lookup requires a lowercase 64-character reference.');
    requireThat(invoice && typeof invoice === 'object', 'invalid_invoice', 'A saved invoice is required for lifecycle binding.');
    const value = await this.get(`/v1/inference/${txid}`);
    requireThat(value.payment_txid === txid && value.drone_pubkey_hash === invoice.drone_pubkey_hash
      && value.model_hash === invoice.model_hash && value.max_tokens === invoice.max_tokens
      && /^[a-f0-9]{8}$/.test(value.params_hash) && Number.isSafeInteger(value.block_height) && value.block_height >= 0
      && nullableTxid(value.change_txid) && nullableTxid(value.escalation_txid) && nullableTxid(value.verdict_txid),
      'lifecycle_mismatch', 'On-chain lifecycle data does not match the saved invoice.', 409);
    return {
      payment_txid: txid, block_height: value.block_height, params_hash: value.params_hash,
      refund_txid: value.change_txid ?? null, escalation_txid: value.escalation_txid ?? null,
      verdict_txid: value.verdict_txid ?? null,
      verification: 'coordinator_index_observation',
    };
  }
  // Integration seam, deliberately not reachable through the read-only gateway.
  // This adapter has contract tests; a live paid call has not been verified.
  async quote(request) {
    // Snapshot before the first await so caller mutation cannot change the quote.
    request = structuredClone(request);
    const model = (await this.models()).find(m => m.id === request.model);
    requireThat(model && model.x_kerrigan.drones.length, 'model_unavailable', 'No connected provider advertises this model.', 503);
    const modelName = model.x_kerrigan.model_name;
    requireThat(validModelName(modelName), 'model_name_unavailable', 'The catalogue does not advertise a wire model name; refresh discovery before quoting.', 503);
    requireThat(request.max_tokens < model.x_kerrigan.context_length, 'context_limit', 'Output limit leaves no room for the prompt.');
    const drone = model.x_kerrigan.drones[0];
    const raw = await this.post('/v1/invoice', {
      model: modelName, messages: request.messages, max_tokens: request.max_tokens, drone_pubkey_hash: drone,
    });
    requireThat(raw.drone_pubkey_hash === drone, 'provider_changed', 'Invoice provider differs from the pinned model provider; request a fresh quote.', 409);
    requireThat(typeof raw.pay_to_address === 'string' && /^K[1-9A-HJ-NP-Za-km-z]{25,34}$/.test(raw.pay_to_address)
      && typeof raw.model_hash === 'string' && /^[a-f0-9]{16}$/.test(raw.model_hash)
      && Number.isSafeInteger(raw.expires_block) && raw.expires_block > 0
      && raw.max_tokens === request.max_tokens,
      'invalid_invoice', 'Invoice is missing payment binding or expiry fields.', 502);
    const amount = sats(raw.amount_sat, 'Invoice amount');
    requireThat(amount > 0, 'invalid_invoice', 'Invoice amount must be positive.', 502);
    // Local consistency metadata, not a signature or proof of model/payment identity.
    const { x_connect_binding: ignored, ...fields } = raw;
    const invoice = { ...fields, amount_sat: amount };
    return { ...invoice, x_connect_binding: {
      version: 1, model_id: request.model, model_name: modelName,
      request_fingerprint: fingerprint(request), invoice_fingerprint: fingerprint(invoice),
    } };
  }
  async infer(request, invoice, paymentTxid) {
    requireThat(validTxid(paymentTxid),
      'invalid_payment_reference', 'Inference requires a valid transaction reference; this does not verify payment.');
    const { x_connect_binding: binding, ...fields } = invoice ?? {};
    requireThat(binding?.version === 1 && binding.model_id === request.model
      && validModelName(binding.model_name) && binding.request_fingerprint === fingerprint(request)
      && binding.invoice_fingerprint === fingerprint(fields),
      'invoice_binding_changed', 'The request or invoice differs from the saved quote, or its binding is missing; do not submit inference.', 409);
    const body = await this.post('/v1/chat', {
      drone_pubkey_hash: invoice.drone_pubkey_hash, payment_txid: paymentTxid,
      model: binding.model_name, messages: request.messages, max_tokens: request.max_tokens,
      temperature: request.temperature, top_p: request.top_p, seed: request.seed, k: request.k,
    });
    const content = body.response ?? body.choices?.[0]?.message?.content;
    requireThat(typeof content === 'string', 'invalid_upstream_response', 'Provider returned no text response.', 502);
    return {
      content, finish_reason: 'stop', usage: body.usage ?? null,
      verification: 'not_performed', simulated: false,
      // A commitment is evidence to verify later, not proof of correctness.
      commitment: body.commitment ?? body.x_kerrigan?.commitment ?? null,
    };
  }
}
