import { readFileSync } from 'node:fs';
import { parseCsv, validateTaxonomy, catalogueRequest, validateCatalogueOutput } from './catalogue.js';
import { fingerprint, normalizeRequest } from './validation.js';
import { requireThat } from './errors.js';
import { TERMINAL } from './ledger.js';
import { createReview } from './review.js';

const assets = new Map([
  ['/studio', ['studio/index.html', 'text/html']],
  ['/studio/', ['studio/index.html', 'text/html']],
  ['/studio/app.js', ['studio/app.js', 'text/javascript']],
  ['/studio/style.css', ['studio/style.css', 'text/css']],
  ['/studio/icon.svg', ['studio/icon.svg', 'image/svg+xml']],
  ['/studio/review-core.js', ['review-core.js', 'text/javascript']],
  ['/studio/review-browser.js', ['review-browser.js', 'text/javascript']],
].map(([route, [file, type]]) => [route, { type, content: readFileSync(new URL(file, import.meta.url), 'utf8') }]));

export function serveStudio(path, res) {
  const asset = assets.get(path);
  if (!asset) return false;
  res.writeHead(200, {
    'content-type': `${asset.type}; charset=utf-8`, 'cache-control': 'no-store',
    'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer',
    'content-security-policy': "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'",
  });
  res.end(asset.content); return true;
}

// A downloaded batch contains source data and stable intent, never credentials.
// Resume requires exactly the original batch: changes deliberately conflict.
export function prepareStudioBatch(input) {
  requireThat(input && input.format === 'kconnect-studio-batch' && input.version === 1,
    'invalid_batch', 'Choose a version 1 Catalogue Studio batch.');
  const products = parseCsv(input.csv);
  const taxonomy = [...validateTaxonomy(input.taxonomy)];
  requireThat(typeof input.run_id === 'string' && /^[A-Za-z0-9._:-]{1,160}$/.test(input.run_id),
    'invalid_run_id', 'A stable batch ID of 1–160 letters, digits, dots, underscores, colons or hyphens is required.');
  const checkpoint = { format: 'kconnect-studio-batch', version: 1, run_id: input.run_id, model: input.model, taxonomy, csv: input.csv };
  const intents = products.map(product => {
    const request = catalogueRequest(product, { model: checkpoint.model, taxonomy });
    normalizeRequest(request);
    return { product_id: product.id, key: `catalogue:${fingerprint({ runId: input.run_id, productId: product.id })}`, request };
  });
  return { checkpoint, products, intents };
}

export function studioReview(gateway, input) {
  const batch = prepareStudioBatch(input?.checkpoint);
  requireThat(Array.isArray(input.job_ids) && input.job_ids.length === batch.products.length,
    'invalid_receipts', 'One job receipt is required for each product.');
  const rows = batch.products.map((product, i) => {
    requireThat(typeof input.job_ids[i] === 'string', 'invalid_receipts', 'Job receipts must be job IDs.');
    const record = gateway.ledger.get(input.job_ids[i]);
    const intent = batch.intents[i];
    requireThat(record.idem_key === intent.key && record.request_hash === fingerprint(normalizeRequest(intent.request)),
      'receipt_mismatch', 'A job receipt does not match this batch, product and request.', 409);
    const job = gateway.ledger.view(record.id);
    requireThat(TERMINAL.has(job.status), 'batch_incomplete', 'Wait for each submitted job to finish before review.', 409);
    const checked = job.status === 'completed' && job.result
      ? validateCatalogueOutput(job.result.content, product, batch.checkpoint.taxonomy)
      : { accepted: false, reason: job.error?.code || (job.status === 'completed' ? 'result_unavailable' : job.status) };
    return {
      ...product, status: checked.accepted ? 'accepted' : 'review_required',
      category: checked.value?.category || '', colour: checked.value?.attributes.colour || '',
      material: checked.value?.attributes.material || '', size: checked.value?.attributes.size || '',
      flags: checked.value?.flags.join('; ') || '', error: checked.accepted ? '' : checked.reason,
      job_id: job.id, net_cost_sats: job.status === 'needs_reconciliation' ? null : job.net_cost_sats,
      simulated: gateway.mode === 'demo' ? true : (job.result?.simulated ?? null),
    };
  });
  const known = rows.filter(row => row.net_cost_sats !== null);
  return {
    session: createReview(rows, { runId: batch.checkpoint.run_id, model: batch.checkpoint.model, taxonomy: batch.checkpoint.taxonomy }),
    accounting: { recorded_sats: known.reduce((sum, row) => sum + row.net_cost_sats, 0), unknown_rows: rows.length - known.length, simulated: gateway.mode === 'demo' },
  };
}
