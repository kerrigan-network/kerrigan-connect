import { ConnectError, requireThat } from './errors.js';
import { fingerprint } from './validation.js';

// Development transport only. Production broadcast remains disabled in config
// and Gateway. Numeric loopback avoids DNS-based endpoint surprises.
export class LoopbackPaymentBridge {
  constructor(url, { timeoutMs = 2000 } = {}) {
    const parsed = new URL(url);
    requireThat(parsed.protocol === 'http:' && ['127.0.0.1', '[::1]'].includes(parsed.hostname)
      && !parsed.username && !parsed.password && !parsed.search && !parsed.hash && parsed.pathname === '/',
      'live_spending_disabled', 'Payment transport is restricted to numeric loopback.');
    requireThat(Number.isInteger(timeoutMs) && timeoutMs > 0 && timeoutMs <= 30000, 'invalid_config', 'Invalid bridge timeout.');
    this.url = parsed.origin; this.timeoutMs = timeoutMs;
  }
  async broadcast(txHex) {
    requireThat(typeof txHex === 'string' && /^(?:[a-f0-9]{2}){1,100000}$/.test(txHex), 'invalid_prepared_payment', 'Invalid transaction bytes.');
    try {
      const response = await fetch(`${this.url}/sendrawtransaction`, {
        method: 'POST', headers: { 'content-type': 'text/plain' }, body: txHex,
        redirect: 'error', signal: AbortSignal.timeout(this.timeoutMs),
      });
      requireThat(response.ok, 'broadcast_unknown', 'Broadcast was not acknowledged; reconcile the saved transaction.', 502);
      let result = '';
      for await (const chunk of response.body) {
        result += Buffer.from(chunk).toString('utf8');
        requireThat(result.length <= 128, 'broadcast_unknown', 'Broadcast returned an invalid acknowledgement.', 502);
      }
      const txid = result.trim();
      requireThat(/^[a-f0-9]{64}$/.test(txid), 'broadcast_unknown', 'Broadcast returned an invalid acknowledgement.', 502);
      return txid;
    } catch (error) {
      if (error instanceof ConnectError) throw error;
      throw new ConnectError('broadcast_unknown', 'Broadcast outcome is unknown; reconcile the saved transaction.', 502);
    }
  }
}

// Isolated development backend; prepare supplies the maintained SDK output
// shape and getRawTransaction implements the wallet's raw-hex lookup contract.
// No keys, signer implementation, public endpoint or CLI spending switch here.
export class PreparedPaymentRecovery {
  constructor({ ledger, prepare, bridge, getRawTransaction, getCurrentBlock }) {
    requireThat(bridge instanceof LoopbackPaymentBridge && typeof prepare === 'function'
      && typeof getRawTransaction === 'function' && typeof getCurrentBlock === 'function',
      'invalid_config', 'Recovery requires loopback transport, preparation, chain tip and lookup.');
    this.ledger = ledger; this.prepare = prepare; this.bridge = bridge;
    this.getRawTransaction = getRawTransaction; this.getCurrentBlock = getCurrentBlock;
  }
  async requireUnexpired(invoice) {
    requireThat(Number.isSafeInteger(invoice.expires_block) && invoice.expires_block > 0,
      'invalid_invoice', 'Invoice has no valid block expiry.', 502);
    let tip;
    try { tip = await this.getCurrentBlock(); }
    catch { throw new ConnectError('chain_tip_unavailable', 'Current block is unavailable; payment is not attempted.', 503); }
    const height = typeof tip === 'number' ? tip : tip?.height;
    requireThat(Number.isSafeInteger(height) && height >= 0, 'chain_tip_unavailable', 'Current block is invalid; payment is not attempted.', 503);
    // Treat the boundary as expired. This is conservative client policy;
    // archived Drone source advertises expiry but does not enforce it.
    requireThat(height < invoice.expires_block, 'invoice_expired', 'Invoice is at or past its expiry block; request a fresh quote.', 409);
    return height;
  }
  async pay({ jobId, invoice, request }) {
    const job = this.ledger.get(jobId);
    requireThat(fingerprint(job.invoice) === fingerprint(invoice) && fingerprint(job.request) === fingerprint(request),
      'prepared_payment_conflict', 'Payment arguments differ from the saved job.', 409);
    await this.requireUnexpired(invoice);
    let saved = this.ledger.preparedPayment(jobId);
    if (!saved) {
      const signed = await this.prepare({ invoice: structuredClone(invoice), request: structuredClone(request) });
      saved = this.ledger.stagePayment(jobId, signed);
    }
    // Preparation may take time: close the quote-to-broadcast expiry race.
    await this.requireUnexpired(invoice);
    // Commit attempt before network I/O. Another caller/restart cannot rebroadcast.
    saved = this.ledger.beginPreparedBroadcast(jobId);
    const ack = await this.bridge.broadcast(saved.tx_hex);
    requireThat(ack === saved.txid, 'broadcast_unknown', 'Acknowledged transaction differs from the saved transaction.', 502);
    await this.lookup(saved);
    return { txid: saved.txid, amount_sats: job.invoice.amount_sat, fee_sats: saved.fee_sats, simulated: true };
  }
  async lookup(saved) {
    let raw;
    try { raw = await this.getRawTransaction(saved.txid); }
    catch { throw new ConnectError('payment_not_observed', 'Transaction lookup is unavailable; reservation retained.', 502); }
    requireThat(raw === saved.tx_hex, 'payment_not_observed', 'Lookup did not return the exact saved bytes; reservation retained.', 409);
    return raw;
  }
  async reconcile(jobId) {
    const saved = this.ledger.preparedPayment(jobId);
    requireThat(saved?.broadcast_started, 'reconciliation_required', 'No saved broadcast attempt to look up.', 409);
    const raw = await this.lookup(saved);
    return this.ledger.reconcilePreparedPayment(jobId, raw);
  }
}
