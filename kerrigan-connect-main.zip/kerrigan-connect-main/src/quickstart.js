import { randomBytes } from 'node:crypto';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { once } from 'node:events';
import { performance } from 'node:perf_hooks';
import { Ledger } from './ledger.js';
import { Gateway } from './gateway.js';
import { DemoProvider, DemoPayments, DEMO_MODEL } from './demo.js';
import { createGatewayServer } from './server.js';

/** A disposable, real-HTTP onboarding check. It never reads wallet or gateway env. */
export async function runQuickstart({ fetchImpl = fetch } = {}) {
  const started = performance.now();
  const dir = await mkdtemp(join(tmpdir(), 'kerrigan-quickstart-'));
  const apiKey = randomBytes(32).toString('hex');
  const checks = [];
  let server, gateway, ledger, payments, baseUrl;
  const check = (id, passed, detail) => {
    checks.push({ id, status: passed ? 'pass' : 'fail', detail });
    if (!passed) throw new Error('Quickstart check failed.');
  };
  const stop = async () => {
    if (server?.listening) {
      const closed = new Promise((resolve, reject) => server.close(e => e ? reject(e) : resolve()));
      server.closeAllConnections();
      await closed;
    }
    await gateway?.stop();
    ledger?.close();
    server = gateway = ledger = undefined;
  };
  const start = async () => {
    ledger = new Ledger(join(dir, 'ledger.sqlite'));
    payments = new DemoPayments();
    gateway = new Gateway({ ledger, payments, provider: new DemoProvider(), budgets: {
      dailyBudgetSats: 100_000, jobBudgetSats: 20_000, maxNetworkFeeSats: 1000,
    } });
    server = createGatewayServer(gateway, { apiKey, chatTimeoutMs: 5000 });
    server.listen(0, '127.0.0.1');
    await once(server, 'listening');
    baseUrl = `http://127.0.0.1:${server.address().port}`;
  };
  const request = (path, { body, key, auth = true } = {}) => fetchImpl(`${baseUrl}${path}`, {
    method: body ? 'POST' : 'GET', redirect: 'error', signal: AbortSignal.timeout(8000),
    headers: { ...(auth ? { authorization: `Bearer ${apiKey}` } : {}),
      ...(body ? { 'content-type': 'application/json' } : {}), ...(key ? { 'Idempotency-Key': key } : {}) },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  try {
    await start();
    const health = await request('/healthz', { auth: false });
    const h = await health.json();
    check('local_service', health.ok && h.mode === 'demo' && h.live_spending === false,
      'A disposable loopback gateway reports demo mode and disabled live spending.');
    const unauthorised = await request('/v1/models', { auth: false });
    await unauthorised.arrayBuffer();
    check('authentication', unauthorised.status === 401, 'Model access without the generated local key is rejected.');
    const modelsResponse = await request('/v1/models');
    const models = await modelsResponse.json();
    check('model_discovery', modelsResponse.ok && models.data?.some(m => m.id === DEMO_MODEL && m.x_kerrigan?.simulated),
      'The catalogue model is explicitly advertised as simulated.');
    const body = { model: DEMO_MODEL, messages: [{ role: 'user', content: 'Hello from the first-run check.' }], max_tokens: 128 };
    const key = 'quickstart-chat-v1';
    const firstResponse = await request('/v1/chat/completions', { body, key });
    const first = await firstResponse.json();
    check('chat_completion', firstResponse.ok && typeof first.choices?.[0]?.message?.content === 'string'
      && first.x_kerrigan?.simulated === true && first.x_kerrigan?.verification === 'not_performed',
    'A chat completion traversed the actual HTTP API with simulation disclosure.');
    const replayResponse = await request('/v1/chat/completions', { body, key });
    const replay = await replayResponse.json();
    check('idempotent_replay', replayResponse.ok && replay.id === first.id && payments.payCalls === 1,
      'Repeating the same intent returned the same job without a second simulated payment.');
    const conflict = await request('/v1/chat/completions', { body: { ...body, max_tokens: 129 }, key });
    const conflictBody = await conflict.json();
    check('changed_request_rejected', conflict.status === 409 && conflictBody.error?.code === 'idempotency_conflict',
      'Reusing that key for a changed request is rejected.');
    const unsupported = await request('/v1/chat/completions', { body: { ...body, tools: [] }, key: 'quickstart-tools-v1' });
    const unsupportedBody = await unsupported.json();
    check('capability_boundary', unsupported.status === 400 && unsupportedBody.error?.code === 'unsupported_parameter',
      'Unsupported tool calls fail explicitly.');
    const stream = await request('/v1/chat/completions', { body: { ...body, stream: true }, key: 'quickstart-stream-v1' });
    const text = await stream.text();
    const events = text.split('\n\n').filter(Boolean).map(s => s.replace(/^data: /, ''));
    const chunks = events.filter(s => s !== '[DONE]').map(s => JSON.parse(s));
    check('buffered_stream', stream.ok && stream.headers.get('x-kerrigan-stream-mode') === 'buffered'
      && events.at(-1) === '[DONE]' && chunks.some(c => c.choices?.[0]?.delta?.content)
      && chunks.some(c => c.x_kerrigan?.simulated === true) && payments.payCalls === 2,
    'SSE framing completes successfully and is labelled buffered.');
    const accounting = ledger.budget();
    await stop();
    await start();
    const recoveredResponse = await request('/v1/chat/completions', { body, key });
    const recovered = await recoveredResponse.json();
    check('restart_replay', recoveredResponse.ok && recovered.id === first.id && payments.payCalls === 0
      && ledger.budget().total_paid_sats === accounting.total_paid_sats,
    'A fresh gateway and SQLite connection recovered the intent without another simulated payment.');
  } catch {
    // Do not return exception messages, prompt bodies, auth headers or local paths.
    if (!checks.some(c => c.status === 'fail')) checks.push({ id: 'execution', status: 'fail',
      detail: 'The local check could not finish. Confirm Node 24.14–24.x and loopback/socket/temporary-directory access.' });
  } finally {
    try { await stop(); } finally { await rm(dir, { recursive: true, force: true }); }
  }
  return { format_version: 1, tool: 'kerrigan-connect-quickstart', generated_at: new Date().toISOString(),
    passed: checks.length === 9 && checks.every(c => c.status === 'pass'), mode: 'demo',
    simulated: true, real_krgn_spent: 0, elapsed_ms: Math.round(performance.now() - started), checks,
    privacy: 'Generated key and demo SQLite data are discarded. This receipt contains no prompts, keys or device identifiers.',
    scope: 'Local integration smoke test only; no remote GPU, live payment, model quality or confidentiality claim.',
    next_steps: ['npm run review-demo', 'npm run doctor', 'Read docs/QUICKSTART.md for app connection and live prerequisites.'] };
}
