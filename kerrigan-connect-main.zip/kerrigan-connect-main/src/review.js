import { fingerprint } from './validation.js';
import { requireThat } from './errors.js';
import { reviewLogic } from './review-core.js';
import { renderReviewPage } from './review-page.js';

export function createReview(rows, { runId, model, taxonomy }) {
  const source = { run_id: runId, model, taxonomy, rows: rows.map(row => ({
    id: row.id, description: row.description, status: row.status,
    category: row.category || '', colour: row.colour || '', material: row.material || '', size: row.size || '',
    flags: row.flags || '', error: row.error || '', job_id: row.job_id || '',
    net_cost_sats: row.net_cost_sats ?? null, simulated: row.simulated ?? null,
  })) };
  const session = { format: 'kconnect-review', version: 1, source_hash: fingerprint(source), source,
    decisions: source.rows.map(row => ({ id: row.id, state: 'pending', values: Object.fromEntries(['category','colour','material','size'].map(k => [k,row[k]])), note: '', reviewed_at: null })) };
  return validateReview(session);
}
export function validateReview(session) {
  reviewLogic().validate(session);
  requireThat(fingerprint(session.source) === session.source_hash, 'changed_review_source', 'Source fingerprint differs; regenerate review from the original batch.');
  return session;
}
export function renderReview(session) { return renderReviewPage(validateReview(session)); }
export function exportReviewed(session) { return reviewLogic().csv(validateReview(session)); }
