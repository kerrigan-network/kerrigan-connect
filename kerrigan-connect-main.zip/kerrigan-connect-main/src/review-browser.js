// No imports, network calls, storage, dynamic markup or remote assets in this runtime.
export function browserApp(session, rules) {
  let selected = session.source.rows[0].id, dirty = false, revision = 0, restoreAttempt = 0;
  const $ = id => document.getElementById(id);
  const fieldNames = ['category','colour','material','size'];
  const draft = () => session.decisions.find(d => d.id === selected);
  const row = () => session.source.rows.find(r => r.id === selected);
  const message = text => { $('message').textContent = text; };
  const markDirty = () => { revision++; dirty = true; $('save-status').textContent = 'Unsaved decisions — download a checkpoint to keep them.'; };
  function download(name, content, type) {
    const url = URL.createObjectURL(new Blob([content], { type }));
    const link = document.createElement('a'); link.href = url; link.download = name; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  function visibleRows() {
    const query = $('search').value.toLowerCase();
    return session.source.rows.filter(r => {
      const d = session.decisions.find(d => d.id === r.id);
      return ($('filter').value === 'all' || d.state === $('filter').value) && `${r.id} ${r.description}`.toLowerCase().includes(query);
    });
  }
  function refreshQueue() {
    const counts = { pending: 0, approved: 0, rejected: 0 };
    session.decisions.forEach(d => counts[d.state]++);
    for (const state of Object.keys(counts)) $(`count-${state}`).textContent = counts[state];
    $('export').disabled = counts.approved === 0;
    $('export').textContent = `Export ${counts.approved} approved ${counts.approved === 1 ? 'row' : 'rows'}`;
    const visible = visibleRows(); $('queue').replaceChildren();
    $('queue-count').textContent = `${visible.length} of ${session.source.rows.length} products`;
    for (const r of visible) {
      const d = session.decisions.find(d => d.id === r.id);
      const button = document.createElement('button'); button.className = 'queue-item';
      button.setAttribute('aria-pressed', String(r.id === selected));
      const title = document.createElement('strong'); title.textContent = r.id;
      const summary = document.createElement('span'); summary.textContent = r.description;
      const status = document.createElement('small'); status.textContent = d.state; status.className = d.state;
      button.append(title, summary, status); button.addEventListener('click', () => { selected = r.id; render(); });
      $('queue').append(button);
    }
    if (!visible.length) { const p = document.createElement('p'); p.className = 'muted'; p.textContent = 'No products match this view.'; $('queue').append(p); }
  }
  function feedback() {
    const issues = rules.errors(row(), draft().values, session.source.taxonomy);
    $('validation').textContent = issues.length ? issues.join(' ') : 'Values pass the taxonomy and literal-evidence checks. Review their meaning before approving.';
    $('validation').className = issues.length ? 'warning' : 'muted';
    $('approve').disabled = issues.length > 0;
    $('decision').textContent = draft().state; $('decision').className = `pill ${draft().state}`;
  }
  function render() {
    refreshQueue();
    const r = row(), d = draft();
    $('product-id').textContent = r.id; $('description').textContent = r.description;
    $('original').textContent = `Category: ${r.category || 'None'} · Colour: ${r.colour || 'Unknown'} · Material: ${r.material || 'Unknown'} · Size: ${r.size || 'Unknown'}`;
    $('flags').textContent = [r.status === 'accepted' ? 'Schema accepted; awaiting your review.' : `Needs review: ${r.error || 'no validated result'}`, r.flags].filter(Boolean).join(' ');
    $('receipt').textContent = `${r.simulated === true ? 'Simulated job' : r.simulated === false ? 'Backend reports live job; execution unverified' : 'Execution unknown'} · Recorded cost: ${r.net_cost_sats === null ? 'unknown' : `${r.net_cost_sats} sats`} · ${r.job_id || 'No job receipt'}`;
    for (const name of fieldNames) $(name).value = d.values[name];
    $('note').value = d.note; feedback();
  }
  for (const label of session.source.taxonomy) {
    const option = document.createElement('option'); option.value = label; option.textContent = label; $('category').append(option);
  }
  for (const name of [...fieldNames, 'note']) $(name).addEventListener('input', () => {
    rules.update(session, selected, Object.fromEntries(fieldNames.map(k => [k,$(k).value])), $('note').value);
    markDirty(); feedback(); refreshQueue(); message('Edit saved in this tab. Approval reset to pending.');
  });
  for (const state of ['approved','rejected','pending']) $(state === 'approved' ? 'approve' : state === 'rejected' ? 'reject' : 'reset').addEventListener('click', () => {
    try { rules.decide(session, selected, state); markDirty(); render(); message(`${selected}: ${state}.`); }
    catch (e) { message(e.message); }
  });
  $('next').addEventListener('click', () => {
    const candidates = session.source.rows.filter(r => session.decisions.find(d => d.id === r.id).state === 'pending');
    const currentIndex = session.source.rows.findIndex(r => r.id === selected);
    const next = candidates.find(r => session.source.rows.indexOf(r) > currentIndex) || candidates[0];
    if (next) { selected = next.id; $('filter').value = 'all'; $('search').value = ''; render(); message('Next pending product.'); }
    else message('No pending products remain. Save your checkpoint and export approved rows.');
  });
  $('search').addEventListener('input', refreshQueue); $('filter').addEventListener('change', refreshQueue);
  $('save').addEventListener('click', () => {
    try { rules.validate(session); download('kerrigan-review-decisions.json', JSON.stringify(session, null, 2) + '\n', 'application/json'); dirty = false; $('save-status').textContent = 'Checkpoint download started. Keep that file to resume later.'; message('Your checkpoint contains every decision and the original source batch.'); }
    catch (e) { message(e.message); }
  });
  $('export').addEventListener('click', () => { download('kerrigan-approved.csv', rules.csv(session), 'text/csv;charset=utf-8'); message('Exported approved rows only. Download a checkpoint too if you need to resume.'); });
  $('restore').addEventListener('change', async e => {
    const attempt = ++restoreAttempt, startedAtRevision = revision;
    const file = e.target.files[0]; if (!file) return;
    try {
      if (file.size > 20_000_000) throw new Error('Checkpoint must be at most 20 MB.');
      const text = await file.text();
      // File reads may finish out of order. Never replace a newer selection,
      // edit or decision with the stale checkpoint (including stale approvals).
      if (attempt !== restoreAttempt) return;
      if (revision !== startedAtRevision) throw new Error('Review changed while the checkpoint was loading. Restore cancelled; save your current decisions and try again.');
      const incoming = JSON.parse(text); rules.restore(session, incoming); revision++; dirty = false;
      $('save-status').textContent = 'Checkpoint restored. New edits will need another download.'; render(); message('Restored decisions for this exact source batch.');
    } catch (error) { if (attempt === restoreAttempt) message(error.message); }
    finally { if (attempt === restoreAttempt) e.target.value = ''; }
  });
  addEventListener('beforeunload', e => { if (dirty) { e.preventDefault(); e.returnValue = ''; } });
  $('run').textContent = session.source.run_id;
  $('model').textContent = session.source.model;
  $('mode').textContent = session.source.rows.every(r => r.simulated === true) ? 'SIMULATED RESULTS' : 'REVIEW · EXECUTION UNVERIFIED';
  render();
}

