import { createHash } from 'node:crypto';
import { requireThat } from './errors.js';
import { canonical } from './validation.js';

const MAX_MODELS = 1000;
const ENDPOINT_STATES = new Set(['observed', 'empty_advertised_list', 'zero_connected_reported', 'endpoint_failure']);

function iso(value, field) {
  requireThat(typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(value) && !Number.isNaN(Date.parse(value)), 'invalid_snapshot', `${field} must be an ISO timestamp.`);
  return new Date(value).toISOString();
}

function safeText(value, field, max = 300) {
  requireThat(typeof value === 'string' && value.length > 0 && value.length <= max && /^[\x20-\x7e]+$/.test(value), 'invalid_snapshot', `${field} is invalid.`);
  return value;
}

function sourceUrl(value) {
  const parsed = new URL(safeText(value, 'probe.coordinator', 300));
  requireThat(parsed.protocol === 'https:' && !parsed.username && !parsed.password && parsed.pathname === '/' && !parsed.search && !parsed.hash, 'invalid_snapshot', 'Coordinator source must be an HTTPS origin.');
  return parsed.origin;
}

function integerOrNull(value, field, max = 1_000_000_000_000) {
  if (value == null) return null;
  requireThat(Number.isSafeInteger(value) && value >= 0 && value <= max, 'invalid_snapshot', `${field} is invalid.`);
  return value;
}

function providerRef(value) {
  requireThat(typeof value === 'string' && /^[a-f0-9]{40}$/.test(value), 'invalid_snapshot', 'Provider advertisement identifier is invalid.');
  return `sha256:${createHash('sha256').update(value).digest('hex').slice(0, 16)}`;
}

function errorFor(probe, source) {
  const error = Array.isArray(probe.errors) ? probe.errors.find(item => item?.source === source) : null;
  return error && typeof error.code === 'string' && /^[a-z0-9_-]{1,80}$/.test(error.code) ? error.code : 'unavailable';
}

function freshness(observedAt, capturedAt) {
  const observed = Date.parse(observedAt);
  const captured = Date.parse(capturedAt);
  if (!Number.isFinite(observed)) return { state: 'invalid_timestamp', age_ms_at_capture: null };
  const age = captured - observed;
  if (age < -60_000) return { state: 'future', age_ms_at_capture: age };
  if (age > 300_000) return { state: 'stale', age_ms_at_capture: age };
  return { state: 'fresh', age_ms_at_capture: age };
}

function normalizedModel(model) {
  requireThat(model && typeof model === 'object' && typeof model.id === 'string' && /^[A-Za-z0-9_.:/-]{1,180}$/.test(model.id), 'invalid_snapshot', 'Model advertisement has an invalid id.');
  const details = model.x_kerrigan;
  requireThat(details && typeof details === 'object' && Array.isArray(details.drones) && details.drones.length <= 1000, 'invalid_snapshot', `Model ${model.id} has invalid provider advertisements.`);
  const providers = [...new Set(details.drones.map(providerRef))].sort();
  const advertised = details.advertised_capabilities ?? {};
  requireThat(advertised && typeof advertised === 'object' && !Array.isArray(advertised), 'invalid_snapshot', `Model ${model.id} capabilities are invalid.`);
  const advertisedCapabilities = {};
  for (const key of Object.keys(advertised).sort()) {
    requireThat(/^[a-z][a-z0-9_]{0,63}$/.test(key) && typeof advertised[key] === 'boolean', 'invalid_snapshot', `Model ${model.id} capability is invalid.`);
    advertisedCapabilities[key] = advertised[key];
  }
  const capabilities = {
    context_length: integerOrNull(details.context_length, `${model.id}.context_length`, 10_000_000),
    quant: details.quant == null ? null : safeText(details.quant, `${model.id}.quant`, 80),
    vram_required_mb: integerOrNull(details.vram_required_mb, `${model.id}.vram_required_mb`, 1_000_000),
    advertised_capabilities: advertisedCapabilities,
    input_sats_per_token: integerOrNull(details.in_rate_sat_per_token, `${model.id}.input_rate`),
    output_sats_per_token: integerOrNull(details.rate_sat_per_token, `${model.id}.output_rate`),
  };
  return { id: model.id, capabilities, capability_fingerprint: createHash('sha256').update(canonical(capabilities)).digest('hex'),
    advertised_provider_count: providers.length, provider_refs: providers };
}

export function normalizeCapabilitySnapshot(probe, { capturedAt = new Date().toISOString(), sourceMode = 'supplied_probe', attemptsUsed = 1, maxAttempts = 1 } = {}) {
  requireThat(probe && typeof probe === 'object' && !Array.isArray(probe), 'invalid_snapshot', 'Probe must be an object.');
  const captured = iso(capturedAt, 'captured_at');
  const observedAt = typeof probe.observed_at === 'string' && !Number.isNaN(Date.parse(probe.observed_at)) ? new Date(probe.observed_at).toISOString() : String(probe.observed_at ?? 'invalid');
  requireThat(['live_get', 'supplied_probe'].includes(sourceMode), 'invalid_snapshot', 'Snapshot source mode is invalid.');
  requireThat(Number.isInteger(attemptsUsed) && Number.isInteger(maxAttempts) && attemptsUsed >= 1 && attemptsUsed <= maxAttempts && maxAttempts <= 3, 'invalid_snapshot', 'Retry evidence is invalid.');
  const coordinator = sourceUrl(probe.coordinator);
  const scope = safeText(probe.scope, 'probe.scope');
  const modelFailure = !Array.isArray(probe.models);
  if (!modelFailure) requireThat(probe.models.length <= MAX_MODELS, 'invalid_snapshot', `At most ${MAX_MODELS} models are supported.`);
  const models = modelFailure ? [] : probe.models.map(normalizedModel).sort((a, b) => a.id.localeCompare(b.id));
  requireThat(new Set(models.map(model => model.id)).size === models.length, 'invalid_snapshot', 'Model ids must be unique.');
  const connected = integerOrNull(probe.connected_drones, 'connected_drones', 1_000_000);
  const chainHeight = integerOrNull(probe.chain?.height, 'chain.height');
  const endpoints = {
    models: modelFailure ? { state: 'endpoint_failure', error_code: errorFor(probe, 'models') }
      : models.length === 0 ? { state: 'empty_advertised_list', error_code: null } : { state: 'observed', error_code: null },
    coordinator: connected == null ? { state: 'endpoint_failure', connected_drones: null, error_code: errorFor(probe, 'coordinator') }
      : connected === 0 ? { state: 'zero_connected_reported', connected_drones: 0, error_code: null } : { state: 'observed', connected_drones: connected, error_code: null },
    explorer: chainHeight == null ? { state: 'endpoint_failure', height: null, error_code: errorFor(probe, 'explorer') }
      : { state: 'observed', height: chainHeight, error_code: null },
  };
  return {
    format_version: 1,
    kind: 'kerrigan-capability-snapshot',
    captured_at: captured,
    observed_at: observedAt,
    freshness: freshness(observedAt, captured),
    source: { mode: sourceMode, coordinator, scope, coordinator_scope_only: true },
    retry: { attempts_used: attemptsUsed, max_attempts: maxAttempts },
    endpoints,
    models,
    limitations: [
      'One configured coordinator is not a census of the Kerrigan network.',
      'A timestamped GET observation is not an uptime percentage or service-level measurement.',
      'Advertisements are not proof of successful inference, GPU capacity, confidentiality, invoicing or payment.',
      'Provider references are one-way shortened hashes; raw provider identifiers are not exported.',
    ],
  };
}

export async function captureCapabilitySnapshot(probeFn, { maxAttempts = 2, retryDelayMs = 100, now = () => new Date().toISOString(), sleep = ms => new Promise(resolve => setTimeout(resolve, ms)) } = {}) {
  requireThat(typeof probeFn === 'function' && Number.isInteger(maxAttempts) && maxAttempts >= 1 && maxAttempts <= 3, 'invalid_snapshot', 'Live capture supports one to three attempts.');
  requireThat(Number.isInteger(retryDelayMs) && retryDelayMs >= 0 && retryDelayMs <= 5000, 'invalid_snapshot', 'Retry delay is invalid.');
  let probe;
  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    probe = await probeFn();
    const report = normalizeCapabilitySnapshot(probe, { capturedAt: now(), sourceMode: 'live_get', attemptsUsed: attempt, maxAttempts });
    const failed = Object.values(report.endpoints).some(endpoint => endpoint.state === 'endpoint_failure');
    if (!failed || attempt === maxAttempts) return report;
    await sleep(retryDelayMs * attempt);
  }
  throw new Error('unreachable');
}

export function validateCapabilitySnapshot(snapshot) {
  requireThat(snapshot && snapshot.format_version === 1 && snapshot.kind === 'kerrigan-capability-snapshot', 'invalid_snapshot', 'Capability snapshot format is invalid.');
  const captured = iso(snapshot.captured_at, 'captured_at');
  requireThat(snapshot.freshness && ['fresh', 'stale', 'future', 'invalid_timestamp'].includes(snapshot.freshness.state), 'invalid_snapshot', 'Snapshot freshness is invalid.');
  requireThat(freshness(snapshot.observed_at, captured).state === snapshot.freshness.state, 'invalid_snapshot', 'Snapshot freshness does not match its timestamps.');
  requireThat(snapshot.source && snapshot.source.coordinator_scope_only === true && ['live_get', 'supplied_probe'].includes(snapshot.source.mode), 'invalid_snapshot', 'Snapshot source scope is invalid.');
  sourceUrl(snapshot.source.coordinator);
  requireThat(snapshot.endpoints && Object.values(snapshot.endpoints).every(endpoint => endpoint && ENDPOINT_STATES.has(endpoint.state)), 'invalid_snapshot', 'Snapshot endpoint state is invalid.');
  requireThat(Array.isArray(snapshot.models) && snapshot.models.length <= MAX_MODELS, 'invalid_snapshot', 'Snapshot models are invalid.');
  requireThat((snapshot.endpoints.models.state === 'observed') === (snapshot.models.length > 0), 'invalid_snapshot', 'Models endpoint state does not match the advertised list.');
  const ids = new Set();
  for (const model of snapshot.models) {
    requireThat(model && typeof model.id === 'string' && /^[A-Za-z0-9_.:/-]{1,180}$/.test(model.id)
      && typeof model.capability_fingerprint === 'string' && /^[a-f0-9]{64}$/.test(model.capability_fingerprint)
      && Array.isArray(model.provider_refs) && model.provider_refs.every(ref => /^sha256:[a-f0-9]{16}$/.test(ref)), 'invalid_snapshot', 'Snapshot model entry is invalid.');
    requireThat(!ids.has(model.id) && model.advertised_provider_count === model.provider_refs.length
      && new Set(model.provider_refs).size === model.provider_refs.length
      && createHash('sha256').update(canonical(model.capabilities)).digest('hex') === model.capability_fingerprint,
    'invalid_snapshot', 'Snapshot model evidence is inconsistent.');
    ids.add(model.id);
  }
  return snapshot;
}

function changedFields(before, after) {
  return [...new Set([...Object.keys(before), ...Object.keys(after)])].filter(key => canonical(before[key]) !== canonical(after[key])).sort();
}

export function diffCapabilitySnapshots(baselineInput, currentInput, { generatedAt = new Date().toISOString() } = {}) {
  const baseline = validateCapabilitySnapshot(baselineInput);
  const current = validateCapabilitySnapshot(currentInput);
  const baseModels = new Map(baseline.models.map(model => [model.id, model]));
  const currentModels = new Map(current.models.map(model => [model.id, model]));
  let comparisonState = 'comparable';
  if (current.endpoints.models.state === 'endpoint_failure') comparisonState = 'unknown_current_endpoint_failure';
  else if (current.freshness.state !== 'fresh') comparisonState = 'unknown_current_stale_or_invalid';
  else if (current.endpoints.models.state === 'empty_advertised_list') comparisonState = 'empty_current_advertised_list';
  else if (baseline.endpoints.models.state === 'endpoint_failure' || baseline.freshness.state !== 'fresh') comparisonState = 'unknown_baseline';
  else if (baseline.endpoints.models.state === 'empty_advertised_list') comparisonState = 'recovered_from_empty_advertised_list';
  const comparable = ['comparable', 'recovered_from_empty_advertised_list'].includes(comparisonState);
  const added = comparable ? [...currentModels.keys()].filter(id => !baseModels.has(id)).sort() : [];
  const removed = comparisonState === 'comparable' ? [...baseModels.keys()].filter(id => !currentModels.has(id)).sort() : [];
  const capabilityChanged = [];
  const providersAdded = [];
  const providersRemoved = [];
  const unchanged = [];
  if (comparable) {
    for (const [id, after] of currentModels) {
      const before = baseModels.get(id);
      if (!before) continue;
      if (before.capability_fingerprint !== after.capability_fingerprint) capabilityChanged.push({ model_id: id, fields: changedFields(before.capabilities, after.capabilities) });
      const beforeProviders = new Set(before.provider_refs);
      const afterProviders = new Set(after.provider_refs);
      for (const ref of afterProviders) if (!beforeProviders.has(ref)) providersAdded.push({ model_id: id, provider_ref: ref });
      for (const ref of beforeProviders) if (!afterProviders.has(ref)) providersRemoved.push({ model_id: id, provider_ref: ref });
      if (before.capability_fingerprint === after.capability_fingerprint && before.provider_refs.length === after.provider_refs.length
        && before.provider_refs.every(ref => afterProviders.has(ref))) unchanged.push(id);
    }
  }
  for (const list of [capabilityChanged, providersAdded, providersRemoved]) list.sort((a, b) => canonical(a).localeCompare(canonical(b)));
  return {
    format_version: 1,
    kind: 'kerrigan-capability-diff',
    generated_at: iso(generatedAt, 'generated_at'),
    comparison_state: comparisonState,
    baseline: { captured_at: baseline.captured_at, observed_at: baseline.observed_at, models_state: baseline.endpoints.models.state },
    current: { captured_at: current.captured_at, observed_at: current.observed_at, models_state: current.endpoints.models.state },
    changes: { models_added: added, models_removed: removed, capabilities_changed: capabilityChanged, providers_added: providersAdded, providers_removed: providersRemoved, models_unchanged: unchanged.sort() },
    note: comparable
      ? 'Changes are differences between two bounded advertisements from one configured coordinator, not whole-network capacity or uptime.'
      : 'Removal events are suppressed because the observations are not safely comparable. Inspect comparison_state.',
  };
}

function md(value) { return String(value).replace(/[\\`|<>*_{}\[\]#]/g, '\\$&'); }
function html(value) { return String(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]); }

export function renderCapabilitySnapshot(snapshot) {
  const models = snapshot.models.length ? snapshot.models.map(model => `| ${md(model.id)} | ${model.advertised_provider_count} | ${model.capabilities.context_length ?? 'unknown'} | ${model.capabilities.vram_required_mb ?? 'unknown'} |`).join('\n') : '| — | — | — | — |';
  return `# Kerrigan capability snapshot\n\nCaptured: ${snapshot.captured_at}  \nObserved: ${md(snapshot.observed_at)}  \nSource: ${md(snapshot.source.coordinator)}  \nScope: one configured coordinator only\n\n## Observation state\n\n| Check | State |\n| --- | --- |\n| Freshness | ${snapshot.freshness.state} |\n| Models endpoint | ${snapshot.endpoints.models.state} |\n| Coordinator endpoint | ${snapshot.endpoints.coordinator.state} |\n| Explorer endpoint | ${snapshot.endpoints.explorer.state} |\n| GET attempts | ${snapshot.retry.attempts_used}/${snapshot.retry.max_attempts} |\n\n## Advertised models\n\n| Model | Provider advertisements | Context | VRAM MB |\n| --- | ---: | ---: | ---: |\n${models}\n\n## Boundaries\n\n${snapshot.limitations.map(item => `- ${md(item)}`).join('\n')}\n`;
}

export function renderCapabilityDiff(diff) {
  const lines = [
    ['Models added', diff.changes.models_added], ['Models removed', diff.changes.models_removed],
    ['Capabilities changed', diff.changes.capabilities_changed.map(item => `${item.model_id} (${item.fields.join(', ')})`)],
    ['Provider advertisements added', diff.changes.providers_added.map(item => `${item.model_id}: ${item.provider_ref}`)],
    ['Provider advertisements removed', diff.changes.providers_removed.map(item => `${item.model_id}: ${item.provider_ref}`)],
  ].map(([label, values]) => `- **${label}:** ${values.length ? values.map(md).join(', ') : 'none'}`).join('\n');
  return `# Kerrigan capability change report\n\nGenerated: ${diff.generated_at}  \nComparison: **${diff.comparison_state}**  \nBaseline observed: ${md(diff.baseline.observed_at)}  \nCurrent observed: ${md(diff.current.observed_at)}\n\n${lines}\n\n${md(diff.note)}\n`;
}

function htmlPage(title, body) {
  return `<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${html(title)}</title><style>body{font:16px/1.5 system-ui,sans-serif;max-width:900px;margin:2rem auto;padding:0 1rem;color:#17212b}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ccd3da;padding:.45rem;text-align:left}code{background:#eef2f5;padding:.1rem .25rem}small{color:#53606c}</style></head><body>${body}</body></html>\n`;
}

export function renderCapabilitySnapshotHtml(snapshot) {
  const endpointRows = Object.entries(snapshot.endpoints).map(([name, value]) => `<tr><td>${html(name)}</td><td>${html(value.state)}</td></tr>`).join('');
  const modelRows = snapshot.models.length
    ? snapshot.models.map(model => `<tr><td><code>${html(model.id)}</code></td><td>${model.advertised_provider_count}</td><td>${html(model.capabilities.context_length ?? 'unknown')}</td><td>${html(model.capabilities.vram_required_mb ?? 'unknown')}</td></tr>`).join('')
    : '<tr><td colspan="4">No advertised models in this observation.</td></tr>';
  const limits = snapshot.limitations.map(item => `<li>${html(item)}</li>`).join('');
  return htmlPage('Kerrigan capability snapshot', `<h1>Kerrigan capability snapshot</h1><p><strong>Captured:</strong> ${html(snapshot.captured_at)}<br><strong>Observed:</strong> ${html(snapshot.observed_at)}<br><strong>Source:</strong> ${html(snapshot.source.coordinator)}<br><strong>Scope:</strong> one configured coordinator only</p><h2>Observation state</h2><table><thead><tr><th>Check</th><th>State</th></tr></thead><tbody><tr><td>freshness</td><td>${html(snapshot.freshness.state)}</td></tr>${endpointRows}<tr><td>GET attempts</td><td>${snapshot.retry.attempts_used}/${snapshot.retry.max_attempts}</td></tr></tbody></table><h2>Advertised models</h2><table><thead><tr><th>Model</th><th>Provider advertisements</th><th>Context</th><th>VRAM MB</th></tr></thead><tbody>${modelRows}</tbody></table><h2>Boundaries</h2><ul>${limits}</ul>`);
}

export function renderCapabilityDiffHtml(diff) {
  const rows = [
    ['Models added', diff.changes.models_added], ['Models removed', diff.changes.models_removed],
    ['Capabilities changed', diff.changes.capabilities_changed.map(item => `${item.model_id} (${item.fields.join(', ')})`)],
    ['Provider advertisements added', diff.changes.providers_added.map(item => `${item.model_id}: ${item.provider_ref}`)],
    ['Provider advertisements removed', diff.changes.providers_removed.map(item => `${item.model_id}: ${item.provider_ref}`)],
  ].map(([label, values]) => `<tr><th>${html(label)}</th><td>${values.length ? values.map(value => `<code>${html(value)}</code>`).join(', ') : 'none'}</td></tr>`).join('');
  return htmlPage('Kerrigan capability change report', `<h1>Kerrigan capability change report</h1><p><strong>Generated:</strong> ${html(diff.generated_at)}<br><strong>Comparison:</strong> ${html(diff.comparison_state)}<br><strong>Baseline observed:</strong> ${html(diff.baseline.observed_at)}<br><strong>Current observed:</strong> ${html(diff.current.observed_at)}</p><table><tbody>${rows}</tbody></table><p><small>${html(diff.note)}</small></p>`);
}
