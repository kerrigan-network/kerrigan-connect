import { ConnectError } from './errors.js';

export function parseNodeVersion(version) {
  const match = /^(\d+)\.(\d+)\.(\d+)(?:[-+].*)?$/.exec(String(version || ''));
  if (!match) {
    throw new ConnectError('unsupported_runtime',
      'Unable to determine the Node.js runtime version. Kerrigan Connect requires Node 24.14+ in the 24.x line.');
  }
  return match.slice(1, 4).map(Number);
}

export function assertSupportedRuntime(version = process.versions.node) {
  const [major, minor] = parseNodeVersion(version);
  if (major !== 24 || minor < 14) {
    throw new ConnectError('unsupported_runtime',
      `Unsupported Node.js ${version}. Kerrigan Connect requires Node 24.14+ in the 24.x line.`);
  }
}
