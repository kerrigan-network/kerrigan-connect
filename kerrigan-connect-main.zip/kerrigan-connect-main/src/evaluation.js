import { requireThat } from './errors.js';
import { fingerprint } from './validation.js';
import { validateTaxonomy } from './catalogue.js';

const fields = ['colour', 'material', 'size'];
const normal = value => value == null || value === '' ? null : String(value).trim().toLowerCase().replace(/\s+/g, ' ');
export function validateDataset(data) {
  requireThat(data?.version === 1 && typeof data.name === 'string' && data.name.trim(), 'invalid_dataset', 'Dataset requires version 1 and a name.');
  validateTaxonomy(data.taxonomy);
  requireThat(Array.isArray(data.cases) && data.cases.length >= 1 && data.cases.length <= 1000, 'invalid_dataset', 'Dataset requires 1–1000 cases.');
  const ids = new Set();
  for (const c of data.cases) {
    requireThat(typeof c.id === 'string' && c.id.trim() && c.id.length <= 200 && !ids.has(c.id)
      && typeof c.description === 'string' && c.description.trim() && c.description.length <= 10000
      && data.taxonomy.includes(c.expected?.category) && c.expected?.attributes
      && fields.every(k => c.expected.attributes[k] === null || (typeof c.expected.attributes[k] === 'string' && c.expected.attributes[k].trim())),
    'invalid_dataset', 'Each case requires a unique ID, description, category and three labelled attributes.');
    ids.add(c.id);
  }
  return data;
}

export function evaluate(dataset, rows, { model, runId } = {}) {
  validateDataset(dataset);
  requireThat(Array.isArray(rows), 'invalid_results', 'Results must be an array.');
  const ids = new Set(dataset.cases.map(c => c.id));
  const byId = new Map();
  for (const row of rows) {
    requireThat(ids.has(row.id) && !byId.has(row.id), 'invalid_results', 'Results contain duplicate or unknown case IDs.');
    byId.set(row.id, row);
  }
  const cases = dataset.cases.map(c => {
    const row = byId.get(c.id);
    const accepted = row?.status === 'accepted';
    const categoryCorrect = accepted && row.category === c.expected.category;
    const attributes = Object.fromEntries(fields.map(k => [k, !!accepted && normal(row[k]) === normal(c.expected.attributes[k])]));
    return { id: c.id, description: c.description, expected: c.expected,
      actual: accepted ? { category: row.category, attributes: Object.fromEntries(fields.map(k => [k, normal(row[k])])) } : null,
      status: row?.status || 'missing', error: row?.error || null,
      category_correct: !!categoryCorrect, attributes_correct: attributes,
      exact_match: !!categoryCorrect && Object.values(attributes).every(Boolean),
      job_id: row?.job_id || null, simulated: row?.simulated ?? null };
  });
  const total = cases.length;
  const metric = correct => ({ correct, total, rate: correct / total });
  const confusion = dataset.taxonomy.map(label => ({ expected: label, counts: Object.fromEntries(
    [...dataset.taxonomy, '(failed/missing)'].map(actual => [actual, cases.filter(c => c.expected.category === label && (c.actual?.category || '(failed/missing)') === actual).length])
  ) }));
  const perCategory = dataset.taxonomy.map(label => {
    const group = cases.filter(c => c.expected.category === label);
    return { category: label, total: group.length, correct: group.filter(c => c.category_correct).length,
      recall: group.length ? group.filter(c => c.category_correct).length / group.length : null };
  });
  const knownCosts = rows.filter(r => Number.isSafeInteger(r.net_cost_sats) && r.net_cost_sats >= 0);
  return {
    format_version: 1, generated_at: new Date().toISOString(), dataset: dataset.name,
    dataset_sha256: fingerprint(dataset), model: model || null, run_id: runId || null,
    execution: cases.every(c => c.simulated === true) ? 'simulation' : cases.every(c => c.simulated === false) ? 'live' : 'mixed_or_unknown',
    note: 'Small synthetic regression set, not a representative commercial benchmark. Execution labels reflect backend receipts, not proof of GPU execution. Simulation scores evaluate deterministic rules, not Kerrigan model quality. All cases, including failed or missing jobs, remain in denominators.',
    metrics: { schema_accepted: metric(cases.filter(c => c.actual).length), category_accuracy: metric(cases.filter(c => c.category_correct).length),
      exact_match: metric(cases.filter(c => c.exact_match).length),
      attributes: Object.fromEntries(fields.map(k => [k, metric(cases.filter(c => c.attributes_correct[k]).length)])),
      populated_attribute_accuracy: (() => {
        const slots = cases.flatMap(c => fields.filter(k => c.expected.attributes[k] !== null).map(k => c.attributes_correct[k]));
        const correct = slots.filter(Boolean).length;
        return { correct, total: slots.length, rate: slots.length ? correct / slots.length : null };
      })(), per_category: perCategory },
    cost: { known_net_sats: knownCosts.reduce((sum, r) => sum + r.net_cost_sats, 0),
      unknown_cases: total - knownCosts.length, complete: knownCosts.length === total },
    confusion, cases,
  };
}

const escape = text => String(text ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export function renderReport(report) {
  const percent = metric => `${(metric.rate * 100).toFixed(1)}% (${metric.correct}/${metric.total})`;
  return `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'"><title>Kerrigan Connect evaluation</title><style>body{font:16px/1.5 system-ui;background:#0f1620;color:#e4edf5;margin:0;padding:40px;max-width:1200px}h1{font-size:36px}small,p{color:#bccad6}.badge{padding:8px 16px;background:#263e51;border-radius:8px;display:inline-block}table{width:100%;border-collapse:collapse;margin:24px 0}th,td{text-align:left;padding:12px;border-bottom:1px solid #405263;vertical-align:top}th{color:#8ed9c7}code{overflow-wrap:anywhere}.pass{color:#8ed9c7}.fail{color:#ffb394}@media(max-width:650px){body{padding:16px}table{font-size:13px}th,td{padding:6px}}</style><main><p>KERRIGAN CONNECT / EVALUATION</p><h1>${escape(report.dataset)}</h1><strong class="badge">${escape(report.execution.toUpperCase())}</strong><p>${escape(report.note)}</p><p>Model: ${escape(report.model)} · Run: ${escape(report.run_id)}</p><table><tr><th>Schema accepted</th><th>Category accuracy</th><th>Full exact match</th></tr><tr>${['schema_accepted','category_accuracy','exact_match'].map(k => `<td>${percent(report.metrics[k])}</td>`).join('')}</tr></table><p>${report.execution === 'simulation' ? 'Simulated' : 'Recorded'} known net cost: ${report.cost.known_net_sats} sats · Unknown costs: ${report.cost.unknown_cases}. Cost totals may include replayed jobs and are not incremental spending.</p><p>Category quality gate: ${report.quality_gate?.threshold == null ? 'Not configured' : `${report.quality_gate.passed ? 'Passed' : 'Failed'} at ${(report.quality_gate.threshold * 100).toFixed(1)}% threshold`}.</p><h2>Case results</h2><table><thead><tr><th>Case</th><th>Expected</th><th>Actual</th><th>Exact match</th></tr></thead><tbody>${report.cases.map(c => `<tr><td><b>${escape(c.id)}</b><br>${escape(c.description)}</td><td>${escape(c.expected.category)}<br><small>${escape(JSON.stringify(c.expected.attributes))}</small></td><td>${escape(c.actual?.category || c.error || c.status)}<br><small>${escape(c.actual ? JSON.stringify(c.actual.attributes) : '')}</small></td><td class="${c.exact_match ? 'pass' : 'fail'}">${c.exact_match ? 'Pass' : 'Review'}</td></tr>`).join('')}</tbody></table><p>Dataset fingerprint: <code>${escape(report.dataset_sha256)}</code></p><p>Generated ${escape(report.generated_at)}. Labels are author-authored expectations; review them before using this set for acceptance decisions. Reports contain product descriptions; keep private catalogues local.</p></main></html>`;
}
