const byId = id => document.getElementById(id);
let apiKey = '';

function text(id, value) { byId(id).textContent = value; }
function label(value) { return String(value || 'unknown').replaceAll('_', ' '); }

async function connect() {
  const candidate = byId('gateway-key').value;
  text('error', '');
  if (!candidate) { text('error', 'Enter the key printed by your local gateway.'); return; }
  apiKey = candidate;
  byId('gateway-key').value = '';
  byId('connect').disabled = true;
  try {
    const response = await fetch('/connect/first-use', { headers: { Authorization: `Bearer ${apiKey}` } });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error?.message || `Status check failed (${response.status}).`);
    text('gateway-status', label(payload.gateway.status));
    text('gateway-detail', `${label(payload.gateway.mode)} mode · live spending disabled`);
    text('model-status', label(payload.models.availability));
    text('model-detail', `${label(payload.models.source)} — ${payload.models.scope}`);
    byId('models').replaceChildren(...payload.models.data.map(model => {
      const item = document.createElement('li');
      item.textContent = `${model.id}${model.simulated ? ' · simulated' : ''}${model.context_length ? ` · ${model.context_length} context` : ''}`;
      return item;
    }));
    text('processing-status', label(payload.processing.status));
    text('processing-detail', payload.processing.reason);
    text('next-detail', payload.next.instruction);
    const link = byId('open-studio');
    link.classList.toggle('disabled', !payload.next.studio_ready);
    link.setAttribute('aria-disabled', String(!payload.next.studio_ready));
  } catch (error) {
    apiKey = '';
    text('error', error.message);
    text('gateway-status', 'Unavailable');
    text('gateway-detail', 'Confirm the local gateway is running and use its current key.');
  } finally {
    byId('connect').disabled = false;
  }
}

byId('connect').addEventListener('click', connect);
byId('open-studio').addEventListener('click', event => {
  if (event.currentTarget.getAttribute('aria-disabled') === 'true') event.preventDefault();
});
