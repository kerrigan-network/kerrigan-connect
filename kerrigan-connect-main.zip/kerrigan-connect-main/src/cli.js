#!/usr/bin/env node
import { readFileSync, writeFileSync, mkdirSync, renameSync } from 'node:fs';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseArgs } from 'node:util';
import { once } from 'node:events';
import { Ledger } from './ledger.js';
import { Gateway } from './gateway.js';
import { DemoProvider, DemoPayments, DEMO_MODEL } from './demo.js';
import { CoordinatorClient } from './coordinator.js';
import { ConnectClient } from './client.js';
import { createGatewayServer } from './server.js';
import { readConfig, httpsOrigin } from './config.js';
import { acquireLock } from './lock.js';
import { parseCsv, exportCsv, processCatalogue, DEFAULT_TAXONOMY } from './catalogue.js';
import { evaluate, validateDataset, renderReport } from './evaluation.js';
import { createReview, validateReview, renderReview, exportReviewed } from './review.js';
import { compareReviews, renderReviewDiff } from './review-diff.js';
import { assessReadiness } from './readiness.js';
import { runQuickstart } from './quickstart.js';
import { planWorkload, renderPlan, readPlanJson } from './planner.js';
import { runTaskPack, createTaskReview, decideTask, exportApprovedTasks } from './task-packs.js';
import { assessGpuPreflight, collectLocalNvidiaInventory, renderGpuPreflight, validateGpuInventory } from './gpu-preflight.js';
import { captureCapabilitySnapshot, diffCapabilitySnapshots, normalizeCapabilitySnapshot, renderCapabilityDiff, renderCapabilityDiffHtml, renderCapabilitySnapshot, renderCapabilitySnapshotHtml } from './capability-tracker.js';
import { aggregateAdoptionEvents, appendAdoptionEvent, readAdoptionJsonl, renderAdoptionSummary, renderAdoptionSummaryHtml, serializeAdoptionEvents } from './adoption.js';
import { fingerprint } from './validation.js';
import { assertSupportedRuntime } from './runtime.js';

assertSupportedRuntime();

const VERSION = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')).version;
const root = fileURLToPath(new URL('../', import.meta.url));
const defaultBudgets = { dailyBudgetSats: 10_000_000, jobBudgetSats: 1_000_000, maxNetworkFeeSats: 10_000 };

function saveReview(base, rows, options) {
  const session = createReview(rows, options);
  atomicWrite(`${base}.review.json`, `${JSON.stringify(session, null, 2)}\n`);
  atomicWrite(`${base}.review.html`, renderReview(session));
}

function atomicWrite(path, content) {
  mkdirSync(dirname(path), { recursive: true, mode: 0o700 });
  const temporary = `${path}.tmp-${process.pid}`;
  writeFileSync(temporary, content, { mode: 0o600 });
  renameSync(temporary, path);
}

async function main() {
  process.umask(0o077);
  const { positionals, values } = parseArgs({
    allowPositionals: true,
    options: {
      baseline: { type: 'string' }, input: { type: 'string' }, output: { type: 'string' }, url: { type: 'string' },
      model: { type: 'string' }, taxonomy: { type: 'string' }, 'run-id': { type: 'string' }, 'min-accuracy': { type: 'string' },
      days: { type: 'string' }, help: { type: 'boolean', short: 'h' },
      workload: { type: 'string' },
      fixture: { type: 'boolean' }, 'case-id': { type: 'string' }, decision: { type: 'string' },
      reviewer: { type: 'string' }, notes: { type: 'string' },
      local: { type: 'boolean' }, models: { type: 'string' },
      attempts: { type: 'string' },
    },
  });
  const command = values.help ? 'help' : positionals[0] || 'help';
  if (command === 'adoption-record') {
    if (!values.input || !values.output) throw new Error('adoption-record requires --input event.json and --output local-events.jsonl.');
    if (resolve(values.input) === resolve(values.output)) throw new Error('Input and output must be different files.');
    const event = readPlanJson(resolve(values.input));
    const existing = readAdoptionJsonl(resolve(values.output), { allowMissing: true });
    const result = appendAdoptionEvent(existing, event);
    atomicWrite(resolve(values.output), serializeAdoptionEvents(result.events));
    console.log(JSON.stringify({ outcome: result.outcome, unique_events: result.events.length, output: resolve(values.output) }, null, 2));
    return;
  }
  if (command === 'adoption-report') {
    if (!values.input || !values.output) throw new Error('adoption-report requires --input local-events.jsonl and --output summary.json.');
    const destinations = [resolve(values.output), resolve(`${values.output}.md`), resolve(`${values.output}.html`)];
    if (destinations.includes(resolve(values.input))) throw new Error('Input and output must be different files.');
    const report = aggregateAdoptionEvents(readAdoptionJsonl(resolve(values.input)));
    atomicWrite(destinations[0], `${JSON.stringify(report, null, 2)}\n`);
    atomicWrite(destinations[1], renderAdoptionSummary(report));
    atomicWrite(destinations[2], renderAdoptionSummaryHtml(report));
    console.log(JSON.stringify({ unique_events: report.records.unique_events, journeys_observed: report.journeys_observed,
      supplied_verified_live_events: report.verified_live_evidence.supplied_events, output: destinations[0] }, null, 2));
    return;
  }
  if (command === 'snapshot') {
    if (!values.output) throw new Error('snapshot requires --output snapshot.json; optionally use --input saved-probe.json for offline normalisation.');
    const destinations = [resolve(values.output), resolve(`${values.output}.md`), resolve(`${values.output}.html`)];
    if (values.input && destinations.includes(resolve(values.input))) throw new Error('Input and output must be different files.');
    if (values.input && values.attempts) throw new Error('--attempts applies to live GET capture only.');
    let snapshot;
    if (values.input) snapshot = normalizeCapabilitySnapshot(readPlanJson(resolve(values.input)));
    else {
      const attempts = Number(values.attempts ?? 2);
      if (!Number.isInteger(attempts) || attempts < 1 || attempts > 3) throw new Error('--attempts must be an integer from 1 to 3.');
      const provider = new CoordinatorClient({
        coordinatorUrl: httpsOrigin(process.env.KCONNECT_COORDINATOR_URL || 'https://coordinator.jskitty.com', 'Coordinator URL'),
        explorerUrl: httpsOrigin(process.env.KCONNECT_EXPLORER_URL || 'https://explorer.kerrigan.network', 'Explorer URL'),
      });
      snapshot = await captureCapabilitySnapshot(() => provider.probe(), { maxAttempts: attempts });
    }
    atomicWrite(destinations[0], `${JSON.stringify(snapshot, null, 2)}\n`);
    atomicWrite(destinations[1], renderCapabilitySnapshot(snapshot));
    atomicWrite(destinations[2], renderCapabilitySnapshotHtml(snapshot));
    console.log(JSON.stringify({ freshness: snapshot.freshness.state, endpoints: Object.fromEntries(Object.entries(snapshot.endpoints).map(([key, value]) => [key, value.state])), models: snapshot.models.length, output: destinations[0] }, null, 2));
    if (snapshot.freshness.state !== 'fresh' || Object.values(snapshot.endpoints).some(endpoint => endpoint.state !== 'observed')) process.exitCode = 2;
    return;
  }
  if (command === 'snapshot-diff') {
    if (!values.baseline || !values.input || !values.output) throw new Error('snapshot-diff requires --baseline previous.json, --input current.json and --output diff.json.');
    const destinations = [resolve(values.output), resolve(`${values.output}.md`), resolve(`${values.output}.html`)];
    if ([values.baseline, values.input].some(path => destinations.includes(resolve(path)))) throw new Error('Inputs and output must be different files.');
    const report = diffCapabilitySnapshots(readPlanJson(resolve(values.baseline)), readPlanJson(resolve(values.input)));
    atomicWrite(destinations[0], `${JSON.stringify(report, null, 2)}\n`);
    atomicWrite(destinations[1], renderCapabilityDiff(report));
    atomicWrite(destinations[2], renderCapabilityDiffHtml(report));
    console.log(JSON.stringify({ comparison_state: report.comparison_state, changes: Object.fromEntries(Object.entries(report.changes).map(([key, value]) => [key, value.length])), output: destinations[0] }, null, 2));
    if (!['comparable', 'recovered_from_empty_advertised_list'].includes(report.comparison_state)) process.exitCode = 2;
    return;
  }
  if (command === 'gpu-preflight') {
    if ((!values.input && !values.local) || (values.input && values.local) || !values.output) throw new Error('gpu-preflight requires exactly one of --input inventory.json or --local, plus --output report.json.');
    const destinations = [resolve(values.output), resolve(`${values.output}.md`)];
    if ([values.input, values.models].filter(Boolean).some(path => destinations.includes(resolve(path)))) throw new Error('Input and output must be different files.');
    const inventory = values.local ? collectLocalNvidiaInventory() : validateGpuInventory(readPlanJson(resolve(values.input)));
    const report = assessGpuPreflight(inventory, { modelSnapshot: values.models ? readPlanJson(resolve(values.models)) : null });
    atomicWrite(destinations[0], `${JSON.stringify(report, null, 2)}\n`);
    atomicWrite(destinations[1], renderGpuPreflight(report));
    console.log(JSON.stringify({ diagnostic_status: report.diagnostic_status, gpus: report.inventory.gpus.length,
      model_checks: report.checks.model_memory.length, output: destinations[0] }, null, 2));
    if (report.diagnostic_status === 'blocked') process.exitCode = 2;
    return;
  }
  if (command === 'task-run') {
    if (!values.input || !values.output || !values['run-id']) throw new Error('task-run requires --input, --output and a persistent --run-id.');
    if (resolve(values.input) === resolve(values.output)) throw new Error('Input and output must be different files.');
    if (!values.fixture && (!values.url || !values.model)) throw new Error('Endpoint mode requires explicit --url and --model. Use --fixture for labelled local outputs.');
    if (values.fixture && (values.url || values.model)) throw new Error('Fixture mode does not accept --url or --model; no endpoint is used.');
    const dataset = readPlanJson(resolve(values.input));
    const client = values.fixture ? null : new ConnectClient({ baseUrl: values.url, apiKey: process.env.KCONNECT_API_KEY });
    const report = await runTaskPack({ dataset, client, model: values.model || null, runId: values['run-id'], mode: values.fixture ? 'fixture' : 'endpoint' });
    atomicWrite(resolve(values.output), `${JSON.stringify(report, null, 2)}\n`);
    console.log(JSON.stringify({ pack: report.pack, execution: report.execution, rows: report.rows.length,
      accepted: report.rows.filter(r => r.validation.accepted).length, output: resolve(values.output) }, null, 2));
    if (report.rows.some(r => !r.validation.accepted)) process.exitCode = 2;
    return;
  }
  if (command === 'task-review') {
    if (!values.input || !values.output || resolve(values.input) === resolve(values.output)) throw new Error('task-review requires separate --input and --output files.');
    const review = createTaskReview(readPlanJson(resolve(values.input)));
    atomicWrite(resolve(values.output), `${JSON.stringify(review, null, 2)}\n`);
    console.log(`Created ${review.cases.length} pending decisions. No output is approved automatically.`);
    return;
  }
  if (command === 'task-decide') {
    if (!values.input || !values.output || resolve(values.input) === resolve(values.output) || !values['case-id'] || !values.decision || !values.reviewer) throw new Error('task-decide requires separate --input/--output, --case-id, --decision and --reviewer.');
    const review = decideTask(readPlanJson(resolve(values.input)), values['case-id'], { decision: values.decision, reviewer: values.reviewer, notes: values.notes || '' });
    atomicWrite(resolve(values.output), `${JSON.stringify(review, null, 2)}\n`);
    console.log(`Recorded ${values.decision} for ${values['case-id']}.`);
    return;
  }
  if (command === 'task-export') {
    if (!values.input || !values.output || resolve(values.input) === resolve(values.output)) throw new Error('task-export requires separate --input and --output files.');
    const content = exportApprovedTasks(readPlanJson(resolve(values.input)));
    atomicWrite(resolve(values.output), content);
    console.log(`Exported ${content.trimEnd().split('\n').length} explicitly approved result(s); pending and rejected cases were excluded.`);
    return;
  }
  if (command === 'plan') {
    if (!values.input || !values.workload) throw new Error('plan requires --input probe.json and --workload workload.json. No live discovery is performed.');
    const outputs = values.output ? [resolve(values.output), resolve(`${values.output}.md`)] : [];
    if ([values.input, values.workload].some(p => outputs.includes(resolve(p)))) throw new Error('Input and output must be different files.');
    const report = planWorkload(readPlanJson(resolve(values.input)), readPlanJson(resolve(values.workload)), { model: values.model || null });
    if (outputs.length) {
      atomicWrite(outputs[0], `${JSON.stringify(report, null, 2)}\n`);
      atomicWrite(outputs[1], renderPlan(report));
    }
    console.log(JSON.stringify(report, null, 2));
    if (!report.advertised_fits.length) process.exitCode = 2;
    return;
  }
  if (command === 'quickstart') {
    const report = await runQuickstart();
    if (values.output) atomicWrite(resolve(values.output), `${JSON.stringify(report, null, 2)}\n`);
    console.log(JSON.stringify(report, null, 2));
    if (!report.passed) process.exitCode = 1;
    return;
  }
  if (command === 'serve') {
    const config = readConfig();
    const release = acquireLock(config.dataDir);
    let ledger;
    try {
      ledger = new Ledger(join(config.dataDir, 'ledger.sqlite'), { mode: config.mode });
      const provider = config.mode === 'demo' ? new DemoProvider() : new CoordinatorClient(config);
      const gateway = new Gateway({ ledger, provider, payments: config.mode === 'demo' ? new DemoPayments() : null, mode: config.mode, budgets: config });
      const server = createGatewayServer(gateway, { apiKey: config.apiKey });
      server.listen(config.port, config.host); await once(server, 'listening');
      console.log(`Kerrigan Connect v${VERSION} · ${config.mode} · http://${config.host === '::1' ? '[::1]' : config.host}:${config.port}`);
      console.log(config.mode === 'demo' ? 'SIMULATED provider and payments. No GPU or real KRGN is used.' : 'Read-only live discovery. Paid inference is disabled.');
      console.log(`Catalogue Studio: http://${config.host === '::1' ? '[::1]' : config.host}:${config.port}/studio`);
      console.log(`First-use guide: http://${config.host === '::1' ? '[::1]' : config.host}:${config.port}/start`);
      console.log(`Operator console: http://${config.host === '::1' ? '[::1]' : config.host}:${config.port}/operator`);
      console.log('Press Ctrl+C to stop. Prompts and outputs are retained locally for resumable jobs.');
      let stopping = false;
      const shutdown = async () => {
        if (stopping) return; stopping = true;
        server.close();
        await gateway.stop();
        server.closeAllConnections();
        ledger.close(); release();
      };
      process.once('SIGINT', shutdown); process.once('SIGTERM', shutdown);
      return;
    } catch (error) { if (ledger) ledger.close(); release(); throw error; }
  }
  if (command === 'probe' || command === 'doctor') {
    const provider = new CoordinatorClient({
      coordinatorUrl: httpsOrigin(process.env.KCONNECT_COORDINATOR_URL || 'https://coordinator.jskitty.com', 'Coordinator URL'),
      explorerUrl: httpsOrigin(process.env.KCONNECT_EXPLORER_URL || 'https://explorer.kerrigan.network', 'Explorer URL'),
    });
    if (values.input && values.output && resolve(values.input) === resolve(values.output)) throw new Error('Input and output must be different files.');
    if (values.input && command !== 'doctor') throw new Error('--input snapshots are supported by doctor only.');
    const observation = values.input ? JSON.parse(readFileSync(resolve(values.input), 'utf8')) : await provider.probe();
    const report = command === 'doctor' ? assessReadiness(observation, { model: values.model, snapshot: !!values.input }) : observation;
    if (values.output) atomicWrite(resolve(values.output), `${JSON.stringify(report, null, 2)}\n`);
    console.log(JSON.stringify(report, null, 2));
    if (command === 'doctor' ? !report.discovery_ready : report.errors.length) process.exitCode = 1;
    return;
  }
  if (command === 'demo' || command === 'review-demo') {
    const ledger = new Ledger();
    const gateway = new Gateway({ ledger, provider: new DemoProvider(), payments: new DemoPayments(), budgets: defaultBudgets });
    try {
      const products = parseCsv(readFileSync(join(root, 'examples/catalogue.csv'), 'utf8'));
      const client = { submit: async (body, key) => gateway.submit(body, key).job, wait: id => gateway.wait(id) };
      const rows = await processCatalogue({ products, client, model: DEMO_MODEL, runId: 'built-in-demo-v1' });
      console.table(rows.map(({ id, category, status, net_cost_sats }) => ({ id, category, status, simulated_sats: net_cost_sats })));
      console.log('SIMULATION: deterministic rules, estimated tokens, fake payments/refunds. This is not a model-quality benchmark.');
      console.log(JSON.stringify({ accepted: rows.filter(r => r.status === 'accepted').length, rows: rows.length, simulated_accounting: ledger.budget() }, null, 2));
      if (command === 'review-demo') {
        const out = resolve(values.output || 'output/catalogue');
        saveReview(out, rows, { runId: 'built-in-demo-v1', model: DEMO_MODEL, taxonomy: DEFAULT_TAXONOMY });
        console.log(`Open ${out}.review.html in your browser. No server or account required.`);
      } else if (values.output) atomicWrite(resolve(values.output), exportCsv(rows));
    } finally { await gateway.stop(); ledger.close(); }
    return;
  }
  if (command === 'benchmark') {
    const dataset = validateDataset(JSON.parse(readFileSync(values.input ? resolve(values.input) : join(root, 'examples/catalogue-benchmark.json'), 'utf8')));
    const threshold = values['min-accuracy'] === undefined ? null : Number(values['min-accuracy']);
    if (threshold !== null && (!values['min-accuracy'].trim() || !Number.isFinite(threshold) || threshold < 0 || threshold > 1)) throw new Error('--min-accuracy must be a number between 0 and 1.');
    if (values.url && !values.model) throw new Error('A gateway benchmark requires an explicit --model.');
    if (!values.url && values.model && values.model !== DEMO_MODEL) throw new Error('A real model requires --url pointing at a configured gateway.');
    const model = values.model || DEMO_MODEL;
    const runId = values['run-id'] || `benchmark:${fingerprint({ dataset, model })}`;
    const out = resolve(values.output || 'output/benchmark.json');
    const outputPaths = [out, `${out}.html`, `${out}.csv`, `${out}.review.json`, `${out}.review.html`];
    if (values.input && outputPaths.includes(resolve(values.input))) throw new Error('Input and output must be different files.');
    let gateway, ledger;
    try {
      let client;
      if (values.url) client = new ConnectClient({ baseUrl: values.url, apiKey: process.env.KCONNECT_API_KEY });
      else {
        ledger = new Ledger();
        gateway = new Gateway({ ledger, provider: new DemoProvider(), payments: new DemoPayments(), budgets: defaultBudgets });
        client = { submit: async (body, key) => gateway.submit(body, key).job, wait: id => gateway.wait(id) };
      }
      const rows = await processCatalogue({ products: dataset.cases.map(({ id, description }) => ({ id, description })),
        client, model, taxonomy: dataset.taxonomy, runId,
        onRow: async (_, partial) => atomicWrite(`${out}.csv`, exportCsv(partial)) });
      const report = evaluate(dataset, rows, { model, runId });
      report.quality_gate = { metric: 'category_accuracy', threshold, passed: threshold === null ? null : report.metrics.category_accuracy.rate >= threshold };
      atomicWrite(out, `${JSON.stringify(report, null, 2)}\n`);
      atomicWrite(`${out}.html`, renderReport(report));
      saveReview(out, rows, { runId, model, taxonomy: dataset.taxonomy });
      console.log(JSON.stringify({ execution: report.execution, metrics: report.metrics, quality_gate: report.quality_gate, output: out }, null, 2));
      if (report.quality_gate.passed === false || rows.some(r => r.status !== 'accepted')) process.exitCode = 2;
    } finally { if (gateway) await gateway.stop(); if (ledger) ledger.close(); }
    return;
  }
  if (command === 'catalogue') {
    if (!values.input || !values.output) throw new Error('catalogue requires --input and --output.');
    const destinations = [values.output, `${values.output}.report.json`, `${values.output}.review.json`, `${values.output}.review.html`].map(p => resolve(p));
    if ([values.input, values.taxonomy].filter(Boolean).some(p => destinations.includes(resolve(p)))) throw new Error('Input and output must be different files.');
    const products = parseCsv(readFileSync(resolve(values.input), 'utf8'));
    const taxonomy = values.taxonomy ? JSON.parse(readFileSync(resolve(values.taxonomy), 'utf8')) : DEFAULT_TAXONOMY;
    const model = values.model || DEMO_MODEL;
    const runId = values['run-id'] || fingerprint({ products, taxonomy, model });
    const client = new ConnectClient({ baseUrl: values.url || 'http://127.0.0.1:8787', apiKey: process.env.KCONNECT_API_KEY });
    const out = resolve(values.output);
    console.log(`Run ${runId}. Reuse this run ID to resume without creating duplicate jobs.`);
    const rows = await processCatalogue({
      products, taxonomy, client, model, runId,
      onRow: async (row, partial) => {
        atomicWrite(out, exportCsv(partial));
        console.log(`${partial.length}/${products.length} · ${row.status} · ${row.job_id || 'not submitted'}`);
      },
    });
    const report = {
      run_id: runId, model, completed_at: new Date().toISOString(), rows: rows.length,
      accepted: rows.filter(r => r.status === 'accepted').length,
      review_required: rows.filter(r => r.status !== 'accepted').length,
      net_cost_sats: rows.reduce((n, r) => n + (r.net_cost_sats || 0), 0),
      unknown_cost_rows: rows.filter(r => !Number.isSafeInteger(r.net_cost_sats)).length,
      cost_note: 'Known job costs, including replayed jobs; not incremental spending. Unknown costs are excluded.',
      simulated: rows.every(r => r.simulated === true),
      note: 'Schema and literal-evidence checks only. Classification accuracy requires labelled evaluation.',
    };
    atomicWrite(`${out}.report.json`, `${JSON.stringify(report, null, 2)}\n`);
    saveReview(out, rows, { runId, model, taxonomy });
    console.log(JSON.stringify(report, null, 2));
    if (report.review_required) process.exitCode = 2;
    return;
  }
  if (command === 'review-diff') {
    if (!values.baseline || !values.input || !values.output) throw new Error('review-diff requires --baseline, --input and --output.');
    const outputs = [resolve(values.output), resolve(`${values.output}.md`)];
    if ([values.baseline, values.input].some(p => outputs.includes(resolve(p)))) throw new Error('Input and output must be different files.');
    const loadReview = path => {
      const bytes = readFileSync(resolve(path));
      if (bytes.length > 20_000_000) throw new Error('Review checkpoint must be at most 20 MB.');
      return JSON.parse(bytes.toString('utf8'));
    };
    const report = compareReviews(loadReview(values.baseline), loadReview(values.input));
    atomicWrite(outputs[0], `${JSON.stringify(report, null, 2)}\n`);
    atomicWrite(outputs[1], renderReviewDiff(report));
    console.log(JSON.stringify(report.summary, null, 2));
    if (report.summary.approval_warnings) process.exitCode = 2;
    return;
  }
  if (command === 'review' || command === 'export-reviewed') {
    if (!values.input || !values.output) throw new Error(`${command} requires --input and --output.`);
    if (resolve(values.input) === resolve(values.output)) throw new Error('Input and output must be different files.');
    const raw = readFileSync(resolve(values.input));
    if (raw.length > 20_000_000) throw new Error('Review checkpoint must be at most 20 MB.');
    const session = validateReview(JSON.parse(raw.toString('utf8')));
    if (command === 'review') {
      atomicWrite(resolve(values.output), renderReview(session));
      console.log(`Open ${resolve(values.output)} in your browser to review this batch.`);
    } else {
      const count = session.decisions.filter(d => d.state === 'approved').length;
      if (!count) throw new Error('No approved rows. Review and approve products first.');
      atomicWrite(resolve(values.output), exportReviewed(session));
      console.log(`Exported ${count} approved rows. Pending and rejected products were excluded.`);
    }
    return;
  }
  if (command === 'purge') {
    const config = readConfig();
    const release = acquireLock(config.dataDir);
    let ledger;
    try {
      ledger = new Ledger(join(config.dataDir, 'ledger.sqlite'), { mode: config.mode });
      console.log(`Removed retained input/output content from ${ledger.purgeContent(Number(values.days || 7))} terminal jobs. Accounting and idempotency records remain.`);
    } finally { if (ledger) ledger.close(); release(); }
    return;
  }
  if (command !== 'help') throw new Error(`Unknown command: ${command}`);
  console.log(`Kerrigan Connect v${VERSION} (Node 24.14+)\n
  npm run quickstart                   Verify your first local integration in one command
  npm run demo                         Run the offline catalogue simulation
  npm start                            Start the local gateway (API key required)
  npm run probe                        Read live model/chain status; never spends
  npm run doctor                       Assess live discovery and integration blockers
  npm run plan -- --input probe.json --workload examples/workload.json --output output/plan.json
  npm run task:fixture -- --input examples/task-packs/support-triage.json --output output/support.json --run-id support-demo-v1
  npm run gpu-preflight -- --input examples/gpu-inventory.json --models examples/gpu-model-snapshot.json --output output/gpu-preflight.json
  npm run gpu-preflight -- --local --output output/gpu-preflight-local.json
  npm run snapshot -- --output output/capability-snapshot.json
  npm run snapshot-diff -- --baseline previous.json --input current.json --output output/capability-diff.json
  npm run adoption:record -- --input event.json --output data/pilot-events.jsonl
  npm run adoption:report -- --input data/pilot-events.jsonl --output output/adoption-summary.json
  node src/cli.js task-run --input cases.json --output results.json --run-id stable-run --url http://127.0.0.1:8787 --model MODEL
  node src/cli.js task-review --input results.json --output review.json
  node src/cli.js task-decide --input review.json --output reviewed.json --case-id CASE --decision approved --reviewer NAME
  node src/cli.js task-export --input reviewed.json --output approved.jsonl
  npm run benchmark                    Evaluate offline rules against labelled cases
  npm run review-demo                  Generate an offline review workspace
  node src/cli.js review --input decisions.json --output review.html
  node src/cli.js export-reviewed --input decisions.json --output approved.csv
  node src/cli.js review-diff --baseline original.review.json --input decisions.json --output changes.json
  node src/cli.js catalogue --input examples/catalogue.csv --output output/results.csv
  node src/cli.js purge --days 7        Remove old retained content (gateway stopped)

  Catalogue options: --url --model --taxonomy --run-id
  Benchmark options: --input --output --url --model --run-id --min-accuracy (0..1)
  Doctor options: --model --output --input (a previously saved probe snapshot)
  Doctor exit 0 means discovery ready only; live spending remains disabled.
  GPU preflight exit 0 means a report was generated, not that the host is provider-ready; exit 2 means a known blocker.
  Snapshot options: --output, optional --input saved-probe.json, live-only --attempts 1..3.
  Snapshot exit 2 preserves a stale, empty, zero or failed observation; diff exit 2 means removals were suppressed as unsafe.
  Adoption commands are local and opt-in; they reject prompt/device/personal fields and never transmit telemetry.
  Demo/probe options: --output
  Modes: KCONNECT_MODE=demo | read-only. Live spending is not implemented.`);
}

main().catch(error => {
  // Do not print stack traces, HTTP payloads, prompts, tokens or private keys.
  console.error(`${error.code || 'error'}: ${error.message}`);
  process.exitCode = 1;
});
