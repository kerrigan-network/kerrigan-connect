import { closeSync, fstatSync, openSync, readSync } from 'node:fs';
import { requireThat } from './errors.js';
import { canonical, fingerprint } from './validation.js';

export const ADOPTION_STAGES = Object.freeze([
  'first_run_pass',
  'first_useful_workflow',
  'return_workflow',
  'verified_live_request',
]);

const ACTIVITIES = Object.freeze(['simulated', 'local_only', 'live']);
const EVIDENCE_KINDS = Object.freeze({
  first_run_pass: ['quickstart_receipt'],
  first_useful_workflow: ['reviewed_workflow', 'local_workflow_receipt'],
  return_workflow: ['return_workflow_receipt'],
  verified_live_request: ['live_receipt_hash'],
});
const MAX_EVENTS = 50_000;
const MAX_LOG_BYTES = 20_000_000;
const exactKeys = (value, keys) => value && typeof value === 'object' && !Array.isArray(value)
  && Object.keys(value).length === keys.length && Object.keys(value).every(key => keys.includes(key));

function safeId(value, field) {
  requireThat(typeof value === 'string' && /^[A-Za-z0-9._:-]{8,120}$/.test(value), 'invalid_adoption_event', `${field} must be 8–120 safe characters.`);
  return value;
}

function timestamp(value) {
  requireThat(typeof value === 'string' && /^\d{4}-\d\d-\d\dT.*(?:Z|[+-]\d\d:\d\d)$/.test(value)
    && !Number.isNaN(Date.parse(value)), 'invalid_adoption_event', 'occurred_at must be an ISO timestamp with timezone.');
  return new Date(value).toISOString();
}

export function validateAdoptionEvent(value) {
  requireThat(exactKeys(value, ['format_version', 'event_id', 'journey_id', 'occurred_at', 'stage', 'activity', 'evidence'])
    && value.format_version === 1, 'invalid_adoption_event', 'Event fields are invalid. Prompt, device, network, wallet and personal data are not accepted.');
  const stage = value.stage;
  requireThat(ADOPTION_STAGES.includes(stage), 'invalid_adoption_event', 'Unknown adoption stage.');
  requireThat(ACTIVITIES.includes(value.activity), 'invalid_adoption_event', 'Activity must be simulated, local_only or live.');
  requireThat(exactKeys(value.evidence, ['kind', 'reference'])
    && EVIDENCE_KINDS[stage].includes(value.evidence.kind)
    && typeof value.evidence.reference === 'string'
    && /^sha256:[a-f0-9]{64}$/.test(value.evidence.reference), 'invalid_adoption_event', 'Evidence must be an allowed kind and a SHA-256 reference.');
  requireThat(stage !== 'verified_live_request' || value.activity === 'live', 'invalid_adoption_event', 'A verified_live_request must be explicitly live.');
  requireThat(stage === 'verified_live_request' || value.evidence.kind !== 'live_receipt_hash', 'invalid_adoption_event', 'Live receipt evidence is reserved for verified_live_request.');
  return {
    format_version: 1,
    event_id: safeId(value.event_id, 'event_id'),
    journey_id: safeId(value.journey_id, 'journey_id'),
    occurred_at: timestamp(value.occurred_at),
    stage,
    activity: value.activity,
    evidence: { kind: value.evidence.kind, reference: value.evidence.reference },
  };
}

function sorted(events) {
  return [...events].sort((a, b) => a.occurred_at.localeCompare(b.occurred_at) || a.event_id.localeCompare(b.event_id));
}

export function deduplicateAdoptionEvents(input) {
  requireThat(Array.isArray(input) && input.length > 0 && input.length <= MAX_EVENTS, 'invalid_adoption_log', `Supply 1–${MAX_EVENTS} adoption events.`);
  const byId = new Map();
  let exactDuplicates = 0;
  for (const raw of input) {
    const event = validateAdoptionEvent(raw);
    const previous = byId.get(event.event_id);
    if (!previous) byId.set(event.event_id, event);
    else if (canonical(previous) === canonical(event)) exactDuplicates += 1;
    else requireThat(false, 'adoption_event_conflict', `Event ${event.event_id} was reused with different evidence.`);
  }
  return { events: sorted(byId.values()), exact_duplicates: exactDuplicates };
}

export function appendAdoptionEvent(existing, candidate) {
  const event = validateAdoptionEvent(candidate);
  if (!existing.length) return { events: [event], outcome: 'added' };
  const normalized = deduplicateAdoptionEvents(existing);
  const previous = normalized.events.find(item => item.event_id === event.event_id);
  if (previous) {
    requireThat(canonical(previous) === canonical(event), 'adoption_event_conflict', `Event ${event.event_id} was reused with different evidence.`);
    return { events: normalized.events, outcome: 'duplicate' };
  }
  requireThat(normalized.events.length < MAX_EVENTS, 'invalid_adoption_log', `At most ${MAX_EVENTS} unique events are supported.`);
  return { events: sorted([...normalized.events, event]), outcome: 'added' };
}

export function parseAdoptionJsonl(text) {
  requireThat(typeof text === 'string' && Buffer.byteLength(text) <= MAX_LOG_BYTES, 'invalid_adoption_log', 'Adoption log must be at most 20 MB.');
  const lines = text.split(/\r?\n/).filter(line => line.trim().length > 0);
  requireThat(lines.length > 0 && lines.length <= MAX_EVENTS, 'invalid_adoption_log', `Adoption log must contain 1–${MAX_EVENTS} records.`);
  return lines.map((line, index) => {
    try { return JSON.parse(line); } catch { requireThat(false, 'invalid_adoption_log', `Adoption log line ${index + 1} is not valid JSON.`); }
  });
}

export function readAdoptionJsonl(path, { allowMissing = false } = {}) {
  let fd;
  try { fd = openSync(path, 'r'); } catch (error) {
    if (allowMissing && error?.code === 'ENOENT') return [];
    throw error;
  }
  try {
    const info = fstatSync(fd);
    requireThat(info.isFile() && info.size <= MAX_LOG_BYTES, 'invalid_adoption_log', 'Adoption log must be a regular file of at most 20 MB.');
    const buffer = Buffer.alloc(MAX_LOG_BYTES + 1);
    let offset = 0, count;
    while (offset < buffer.length && (count = readSync(fd, buffer, offset, buffer.length - offset, null)) > 0) offset += count;
    requireThat(offset <= MAX_LOG_BYTES, 'invalid_adoption_log', 'Adoption log exceeds 20 MB.');
    if (offset === 0 && allowMissing) return [];
    return parseAdoptionJsonl(buffer.subarray(0, offset).toString('utf8'));
  } finally { closeSync(fd); }
}

export function serializeAdoptionEvents(events) {
  const normalized = deduplicateAdoptionEvents(events);
  return `${normalized.events.map(event => JSON.stringify(event)).join('\n')}\n`;
}

export function aggregateAdoptionEvents(input, { generatedAt = new Date().toISOString() } = {}) {
  const normalized = deduplicateAdoptionEvents(input);
  const events = normalized.events;
  const journeys = new Map();
  for (const event of events) {
    if (!journeys.has(event.journey_id)) journeys.set(event.journey_id, []);
    journeys.get(event.journey_id).push(event);
  }
  const byStage = Object.fromEntries(ADOPTION_STAGES.map(stage => {
    const matching = events.filter(event => event.stage === stage);
    return [stage, {
      events: matching.length,
      journeys: new Set(matching.map(event => event.journey_id)).size,
      activity: Object.fromEntries(ACTIVITIES.map(activity => [activity, matching.filter(event => event.activity === activity).length])),
    }];
  }));
  const activity = Object.fromEntries(ACTIVITIES.map(kind => [kind, events.filter(event => event.activity === kind).length]));
  let sequenceGaps = 0;
  for (const journeyEvents of journeys.values()) {
    const firstIndex = Object.fromEntries(ADOPTION_STAGES.map(stage => [stage, journeyEvents.findIndex(event => event.stage === stage)]));
    const missingOrLater = (required, stage) => firstIndex[stage] >= 0 && (firstIndex[required] < 0 || firstIndex[required] > firstIndex[stage]);
    if (missingOrLater('first_run_pass', 'first_useful_workflow')
      || missingOrLater('first_useful_workflow', 'return_workflow')
      || missingOrLater('first_run_pass', 'verified_live_request')) sequenceGaps += 1;
  }
  const first = events[0].occurred_at;
  const last = events[events.length - 1].occurred_at;
  return {
    format_version: 1,
    kind: 'kerrigan-local-adoption-summary',
    generated_at: new Date(generatedAt).toISOString(),
    source_fingerprint: fingerprint(events),
    observation_window: { first_event_at: first, last_event_at: last },
    records: { received: input.length, unique_events: events.length, exact_duplicates: normalized.exact_duplicates },
    journeys_observed: journeys.size,
    activity,
    stages: byStage,
    quality: { journeys_with_sequence_gaps: sequenceGaps },
    verified_live_evidence: {
      supplied_events: byStage.verified_live_request.events,
      interpretation: 'Counts locally supplied live-receipt hashes only; this report does not validate a request, invoice, payment or chain transaction.',
    },
    claims: {
      measured_adoption: false,
      conversion_lift: null,
      unique_people: null,
      note: 'Counts describe supplied opt-in local records, not users, market adoption or conversion lift.',
    },
    privacy: {
      transmitted: false,
      prompt_content_collected: false,
      device_fingerprint_collected: false,
      identifiers_exported: false,
      note: 'Journey IDs, event IDs and evidence references are consumed locally but omitted from this aggregate.',
    },
  };
}

function md(value) { return String(value).replace(/[\\`|<>*_{}\[\]#]/g, '\\$&'); }
function html(value) { return String(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]); }

export function renderAdoptionSummary(report) {
  const stages = ADOPTION_STAGES.map(stage => `| ${md(stage)} | ${report.stages[stage].events} | ${report.stages[stage].journeys} | ${report.stages[stage].activity.simulated} | ${report.stages[stage].activity.local_only} | ${report.stages[stage].activity.live} |`).join('\n');
  return `# Kerrigan local pilot evidence summary\n\nGenerated: ${report.generated_at}  \nWindow: ${report.observation_window.first_event_at} to ${report.observation_window.last_event_at}  \nSource fingerprint: \`${report.source_fingerprint}\`\n\n| Stage | Events | Journeys | Simulated | Local only | Live |\n| --- | ---: | ---: | ---: | ---: | ---: |\n${stages}\n\n- Records: ${report.records.unique_events} unique; ${report.records.exact_duplicates} exact duplicates ignored\n- Journeys observed: ${report.journeys_observed}\n- Sequence-gap journeys: ${report.quality.journeys_with_sequence_gaps}\n- Supplied verified-live evidence events: ${report.verified_live_evidence.supplied_events}\n\n## Interpretation boundary\n\n${md(report.claims.note)} ${md(report.verified_live_evidence.interpretation)} No prompt content or device fingerprint was collected or transmitted.\n`;
}

export function renderAdoptionSummaryHtml(report) {
  const rows = ADOPTION_STAGES.map(stage => `<tr><td><code>${html(stage)}</code></td><td>${report.stages[stage].events}</td><td>${report.stages[stage].journeys}</td><td>${report.stages[stage].activity.simulated}</td><td>${report.stages[stage].activity.local_only}</td><td>${report.stages[stage].activity.live}</td></tr>`).join('');
  return `<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Kerrigan local pilot evidence summary</title><style>body{font:16px/1.5 system-ui,sans-serif;max-width:900px;margin:2rem auto;padding:0 1rem;color:#17212b}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ccd3da;padding:.45rem;text-align:left}code{background:#eef2f5;padding:.1rem .25rem}small{color:#53606c}</style></head><body><h1>Kerrigan local pilot evidence summary</h1><p><strong>Generated:</strong> ${html(report.generated_at)}<br><strong>Window:</strong> ${html(report.observation_window.first_event_at)} to ${html(report.observation_window.last_event_at)}<br><strong>Source fingerprint:</strong> <code>${html(report.source_fingerprint)}</code></p><table><thead><tr><th>Stage</th><th>Events</th><th>Journeys</th><th>Simulated</th><th>Local only</th><th>Live</th></tr></thead><tbody>${rows}</tbody></table><ul><li>${report.records.unique_events} unique records; ${report.records.exact_duplicates} exact duplicates ignored</li><li>${report.journeys_observed} journeys observed</li><li>${report.quality.journeys_with_sequence_gaps} sequence-gap journeys</li><li>${report.verified_live_evidence.supplied_events} supplied verified-live evidence events</li></ul><h2>Interpretation boundary</h2><p><small>${html(report.claims.note)} ${html(report.verified_live_evidence.interpretation)} No prompt content or device fingerprint was collected or transmitted.</small></p></body></html>\n`;
}
