import { createHash } from 'node:crypto';
import { requireThat } from './errors.js';

export function sats(value, field = 'amount') {
  requireThat((typeof value === 'number' || typeof value === 'string') && /^\d+$/.test(String(value)), 'invalid_amount', `${field} must be integer KRGN satoshis.`);
  const result = Number(value);
  requireThat(Number.isSafeInteger(result) && result >= 0 && result <= 1_000_000_000_000, 'invalid_amount', `${field} exceeds the supported range.`);
  return result;
}

export function canonical(value) {
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`;
  return JSON.stringify(value);
}

export function fingerprint(value) {
  return createHash('sha256').update(canonical(value)).digest('hex');
}

export function idempotencyKey(value) {
  requireThat(typeof value === 'string' && /^[A-Za-z0-9._:-]{8,160}$/.test(value), 'invalid_idempotency_key', 'Idempotency-Key must be 8–160 letters, numbers, dots, underscores, colons or hyphens.');
  return value;
}

export function normalizeRequest(body) {
  requireThat(body && typeof body === 'object' && !Array.isArray(body), 'invalid_request', 'A JSON object is required.');
  const allowed = new Set(['model', 'messages', 'max_tokens', 'max_completion_tokens', 'temperature', 'top_p', 'seed', 'stream', 'budget_sats']);
  for (const key of Object.keys(body)) requireThat(allowed.has(key), 'unsupported_parameter', `Parameter ${key.slice(0,60)} is not supported in this milestone.`);
  requireThat(typeof body.model === 'string' && /^[A-Za-z0-9_.:/-]{1,180}$/.test(body.model), 'invalid_model', 'A supported model identifier is required.');
  requireThat(Array.isArray(body.messages) && body.messages.length > 0 && body.messages.length <= 64, 'invalid_messages', 'Provide 1–64 text messages.');
  const messages = body.messages.map(message => {
    requireThat(message && typeof message === 'object' && Object.keys(message).every(k => ['role', 'content'].includes(k))
      && ['system', 'user', 'assistant'].includes(message.role) && typeof message.content === 'string', 'invalid_messages', 'Messages require role and text content; tools and multimodal content are not supported.');
    return { role: message.role, content: message.content };
  });
  requireThat(messages.some(m => m.role === 'user'), 'invalid_messages', 'At least one user message is required.');
  requireThat(Buffer.byteLength(JSON.stringify(messages)) <= 100_000, 'request_too_large', 'Messages exceed 100 KB.', 413);
  requireThat(!(body.max_tokens !== undefined && body.max_completion_tokens !== undefined), 'invalid_request', 'Use only one output token limit.');
  const max_tokens = body.max_tokens ?? body.max_completion_tokens ?? 512;
  requireThat(Number.isInteger(max_tokens) && max_tokens > 0 && max_tokens <= 16_384, 'invalid_request', 'max_tokens must be 1–16384.');
  const temperature = body.temperature ?? 0.7;
  const top_p = body.top_p ?? 0.9;
  const seed = body.seed ?? 42;
  requireThat(typeof temperature === 'number' && Number.isFinite(temperature) && temperature >= 0 && temperature <= 2, 'invalid_request', 'temperature must be 0–2.');
  requireThat(typeof top_p === 'number' && Number.isFinite(top_p) && top_p > 0 && top_p <= 1, 'invalid_request', 'top_p must be greater than 0 and at most 1.');
  requireThat(Number.isSafeInteger(seed) && seed >= 0, 'invalid_request', 'seed must be a non-negative safe integer.');
  requireThat(body.stream === undefined || typeof body.stream === 'boolean', 'invalid_request', 'stream must be a boolean.');
  return {
    model: body.model, messages, max_tokens, temperature, top_p, seed, k: 16,
    ...(body.budget_sats !== undefined ? { budget_sats: sats(body.budget_sats, 'budget_sats') } : {}),
  };
}

export function formatKrgn(value) {
  return `${Math.floor(value / 100_000_000)}.${String(value % 100_000_000).padStart(8, '0')}`;
}
