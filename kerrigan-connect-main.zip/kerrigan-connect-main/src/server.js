import { createServer } from 'node:http';
import { timingSafeEqual, randomUUID } from 'node:crypto';
import { ConnectError, requireThat, publicError } from './errors.js';
import { serveStudio, prepareStudioBatch, studioReview } from './studio.js';
import { serveFirstUse, firstUseStatus } from './first-use.js';
import { serveOperatorConsole, operatorReport } from './operator-console.js';

function send(res, status, body, extra = {}) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', ...extra });
  res.end(JSON.stringify(body));
}

async function readBody(req, limit = 200_000) {
  requireThat(/^application\/json(?:\s*;|$)/i.test(req.headers['content-type'] || ''), 'unsupported_media_type', 'Use Content-Type: application/json.', 415);
  const chunks = [];
  let bytes = 0;
  for await (const chunk of req) {
    bytes += chunk.length;
    requireThat(bytes <= limit, 'request_too_large', `Request body exceeds ${limit} bytes.`, 413);
    chunks.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { throw new ConnectError('invalid_json', 'Request body is not valid JSON.'); }
}

function authorised(req, key) {
  const actual = Buffer.from(req.headers.authorization || '');
  const expected = Buffer.from(`Bearer ${key}`);
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

async function writeSse(res, payload) {
  if (res.destroyed) throw new Error('Client disconnected.');
  if (!res.write(`data: ${typeof payload === 'string' ? payload : JSON.stringify(payload)}\n\n`)) {
    await new Promise((resolve, reject) => {
      const cleanup = () => { res.off('drain', drained); res.off('close', closed); };
      const drained = () => { cleanup(); resolve(); };
      const closed = () => { cleanup(); reject(new Error('Client disconnected.')); };
      res.once('drain', drained); res.once('close', closed);
    });
  }
}

export function createGatewayServer(gateway, { apiKey, chatTimeoutMs = 120_000 } = {}) {
  requireThat(typeof apiKey === 'string' && apiKey.length >= 24, 'invalid_config', 'A gateway API key of at least 24 characters is required.');
  const server = createServer(async (req, res) => {
    let jobId = null;
    try {
      const host = req.headers.host || '';
      requireThat(/^(?:localhost|127\.0\.0\.1|\[::1\])(?::\d+)?$/.test(host), 'invalid_host', 'Only localhost requests are accepted.', 403);
      requireThat(!req.headers.origin || ['http://localhost', 'http://127.0.0.1', 'http://[::1]'].some(origin => {
        try { return new URL(req.headers.origin).origin === origin || new URL(req.headers.origin).origin.startsWith(`${origin}:`); } catch { return false; }
      }), 'origin_rejected', 'Cross-origin browser requests are disabled.', 403);
      const url = new URL(req.url, 'http://localhost');
      const path = url.pathname;
      if (req.method === 'GET' && serveFirstUse(path, res)) return;
      if (req.method === 'GET' && serveStudio(path, res)) return;
      if (req.method === 'GET' && serveOperatorConsole(path, res)) return;
      if (req.method === 'GET' && path === '/healthz') {
        send(res, gateway.workerError ? 503 : 200, { status: gateway.workerError ? 'degraded' : 'ok', mode: gateway.mode, live_spending: false }); return;
      }
      requireThat(authorised(req, apiKey), 'unauthorized', 'A valid Bearer API key is required.', 401);
      if (req.method === 'GET' && path === '/connect/first-use') {
        send(res, 200, await firstUseStatus(gateway)); return;
      }
      if (req.method === 'GET' && path === '/connect/operator') {
        send(res, 200, await operatorReport(gateway)); return;
      }
      if (req.method === 'POST' && path === '/operator/api/supplied') {
        send(res, 200, await operatorReport(gateway, { supplied: await readBody(req, 200_000) })); return;
      }
      if (req.method === 'POST' && path === '/studio/api/prepare') {
        send(res, 200, prepareStudioBatch(await readBody(req, 12_000_000))); return;
      }
      if (req.method === 'POST' && path === '/studio/api/review') {
        send(res, 200, studioReview(gateway, await readBody(req, 12_000_000))); return;
      }
      if (req.method === 'GET' && path === '/v1/models') { send(res, 200, await gateway.models()); return; }
      if (req.method === 'GET' && path === '/connect/status') {
        send(res, 200, {
          mode: gateway.mode, simulated: gateway.mode === 'demo', live_spending: false,
          accounting: gateway.ledger.budget(), limits: gateway.budgets,
          privacy: 'Job messages and outputs are stored locally in SQLite. The database is not encrypted by this application.',
        }); return;
      }
      if (req.method === 'GET' && path === '/connect/jobs') {
        send(res, 200, { jobs: gateway.ledger.list() }); return;
      }
      const jobMatch = path.match(/^\/connect\/jobs\/(job_[a-f0-9-]{36})(?:\/(retry|cancel))?$/);
      if (jobMatch) {
        const [, id, action] = jobMatch;
        if (req.method === 'GET' && !action) { send(res, 200, gateway.ledger.view(id)); return; }
        if (req.method === 'POST' && action === 'retry') { send(res, 202, gateway.retry(id)); return; }
        if (req.method === 'POST' && action === 'cancel') {
          gateway.ledger.cancel(id); send(res, 200, gateway.ledger.view(id)); return;
        }
      }
      if (req.method === 'POST' && ['/connect/jobs', '/v1/chat/completions'].includes(path)) {
        const body = await readBody(req);
        // Generic chat clients may omit this header. Such requests receive a
        // key, but retries across lost responses are safe only with a caller key.
        const key = req.headers['idempotency-key'] || (path === '/v1/chat/completions' ? randomUUID() : undefined);
        const { job, created } = gateway.submit(body, key);
        jobId = job.id;
        res.setHeader('Idempotency-Key', key);
        res.setHeader('X-Kerrigan-Job-Id', job.id);
        res.setHeader('Location', `/connect/jobs/${job.id}`);
        if (path === '/connect/jobs') { send(res, created ? 202 : 200, job); return; }
        const complete = await gateway.wait(job.id, chatTimeoutMs);
        requireThat(complete.status === 'completed', complete.error?.code || 'job_failed', complete.error?.message || 'The job did not complete.', complete.status === 'needs_reconciliation' ? 409 : 422);
        const completion = gateway.completion(complete);
        if (!body.stream) { send(res, 200, completion); return; }
        // Buffered SSE compatibility only. This is not time-to-first-token
        // streaming and never displays a partial response as a completed job.
        res.writeHead(200, {
          'content-type': 'text/event-stream; charset=utf-8', 'cache-control': 'no-store',
          'x-content-type-options': 'nosniff', 'x-kerrigan-stream-mode': 'buffered',
        });
        const base = { id: completion.id, object: 'chat.completion.chunk', created: completion.created, model: completion.model };
        await writeSse(res, { ...base, choices: [{ index: 0, delta: { role: 'assistant', content: completion.choices[0].message.content }, finish_reason: null }] });
        await writeSse(res, { ...base, choices: [{ index: 0, delta: {}, finish_reason: completion.choices[0].finish_reason }], usage: completion.usage, x_kerrigan: completion.x_kerrigan });
        await writeSse(res, '[DONE]'); res.end(); return;
      }
      throw new ConnectError('not_found', 'Route not found.', 404);
    } catch (error) {
      if (res.headersSent) { res.destroy(); return; }
      send(res, error instanceof ConnectError ? error.status : 500, { error: { ...publicError(error), type: 'kerrigan_connect_error', ...(jobId ? { job_id: jobId } : {}) } });
    }
  });
  server.requestTimeout = 30_000;
  server.headersTimeout = 10_000;
  server.keepAliveTimeout = 5000;
  server.maxHeadersCount = 50;
  return server;
}
