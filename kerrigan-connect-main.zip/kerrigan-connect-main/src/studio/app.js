import { browserApp } from './review-browser.js';
import { reviewLogic } from './review-core.js';

const $ = id => document.getElementById(id);
const terminal = new Set(['completed', 'failed', 'cancelled', 'needs_reconciliation']);
let apiKey = '', mode = '', csv = '', batch = null, busy = false, paused = false, saved = false, reviewOpened = false;
let jobs = [], fileRevision = 0;
const error = value => { $('studio-error').textContent = value ? value.message || String(value) : ''; };

async function api(path, body, headers = {}) {
  const response = await fetch(path, {
    method: body === undefined ? 'GET' : 'POST', cache: 'no-store', credentials: 'omit',
    headers: { Authorization: `Bearer ${apiKey}`, ...(body === undefined ? {} : { 'Content-Type': 'application/json' }), ...headers },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: AbortSignal.timeout(30_000),
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error?.message || `Gateway returned HTTP ${response.status}.`);
  return result;
}
function download(name, value) {
  const url = URL.createObjectURL(new Blob([JSON.stringify(value, null, 2) + '\n'], { type: 'application/json' }));
  const link = document.createElement('a'); link.href = url; link.download = name; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function controls() {
  $('process').disabled = busy || !saved || mode !== 'demo' || reviewOpened;
  $('pause').disabled = !busy || paused;
  $('open-review').disabled = busy || reviewOpened || !batch || jobs.filter(j => j && terminal.has(j.status)).length !== batch.products.length;
}
function progress() {
  $('progress-rows').replaceChildren();
  batch.products.forEach((product, i) => {
    const job = jobs[i], tr = document.createElement('tr');
    const cost = job && terminal.has(job.status) && job.status !== 'needs_reconciliation' ? `${job.net_cost_sats} sats${mode === 'demo' ? ' · simulated' : ''}` : 'Unknown';
    for (const text of [product.id, job?.status || 'Not submitted', cost]) {
      const td = document.createElement('td'); td.textContent = text; tr.append(td);
    }
    $('progress-rows').append(tr);
  });
  $('progress').value = jobs.filter(j => j && terminal.has(j.status)).length;
  controls();
}
async function prepare(checkpoint, restoring = false) {
  const prepared = await api('/studio/api/prepare', checkpoint);
  batch = prepared; jobs = []; saved = restoring;
  $('batch-inputs').disabled = true;
  $('processing').hidden = false;
  $('progress').max = batch.products.length;
  $('batch-identity').textContent = `${batch.products.length} products · ${checkpoint.model} · Batch ${checkpoint.run_id}`;
  $('batch-status').textContent = 'Batch prepared. Source and request identities are fixed for this run.';
  $('progress-status').textContent = restoring ? 'Batch restored. Resume to recover existing receipts and continue remaining products.' : 'Save a batch checkpoint to enable processing.';
  $('accounting').textContent = mode === 'demo' ? 'Demo accounting is simulated. No KRGN is spent.' : 'This Connect gateway is read-only; processing is not enabled here.';
  progress();
}

$('connect').addEventListener('click', async () => {
  error(''); $('connect').disabled = true;
  try {
    apiKey = $('gateway-key').value.trim();
    if (!apiKey) throw new Error('Enter the local gateway API key.');
    const [status, models] = await Promise.all([api('/connect/status'), api('/v1/models')]);
    mode = status.mode;
    $('model-select').replaceChildren();
    for (const model of models.data) {
      const option = document.createElement('option'); option.value = model.id; option.textContent = model.id; $('model-select').append(option);
    }
    $('gateway-key').value = ''; $('gateway-key').disabled = true;
    $('connect').textContent = 'Connected';
    $('connection-status').textContent = mode === 'demo' ? 'Connected · simulated demo · no KRGN spend.' : 'Connected · read-only discovery. Processing is not enabled in this Connect mode.';
    $('batch-inputs').disabled = false;
    $('batch-status').textContent = models.data.length ? 'Choose a file or use the sample.' : 'No models advertised. Discovery does not establish live availability.';
  } catch (e) { apiKey = ''; error(e); $('connect').disabled = false; }
});
$('csv-file').addEventListener('change', async e => {
  const revision = ++fileRevision; csv = ''; $('prepare').disabled = true;
  try {
    const file = e.target.files[0]; if (!file) return;
    if (file.size > 2_000_000) throw new Error('CSV must be at most 2 MB.');
    const text = await file.text();
    if (revision !== fileRevision || batch) return;
    csv = text; $('file-status').textContent = `${file.name} · ${file.size.toLocaleString()} bytes`; error('');
  } catch (e) { if (revision === fileRevision) error(e); }
  finally { if (revision === fileRevision) $('prepare').disabled = false; }
});
$('sample').addEventListener('click', () => {
  fileRevision++; $('prepare').disabled = false; $('csv-file').value = '';
  csv = 'id,description\ntee-01,Blue cotton t-shirt size M\nmug-02,White ceramic mug 350 ml\nheadphones-03,Black wireless headphones\nmat-04,Green yoga mat\nshirt-05,Red cotton shirt size L\nunknown-06,Mystery item\n';
  $('file-status').textContent = 'Six sample products selected.'; error('');
});
$('prepare').addEventListener('click', async () => {
  error(''); $('batch-inputs').disabled = true;
  try {
    if (!csv) throw new Error('Choose a CSV or load the sample first.');
    await prepare({ format: 'kconnect-studio-batch', version: 1, run_id: `studio-${crypto.randomUUID()}`, model: $('model-select').value,
      taxonomy: $('taxonomy').value.split('\n').map(s => s.trim()).filter(Boolean), csv });
  } catch (e) { error(e); $('batch-inputs').disabled = false; }
});
$('batch-restore').addEventListener('change', async e => {
  const revision = ++fileRevision; error(''); $('batch-inputs').disabled = true;
  try {
    const file = e.target.files[0]; if (!file) { $('batch-inputs').disabled = false; return; }
    if (file.size > 12_000_000) throw new Error('Batch checkpoint must be at most 12 MB.');
    const text = await file.text();
    if (revision !== fileRevision || batch) return;
    await prepare(JSON.parse(text), true);
  } catch (e) { error(e); $('batch-inputs').disabled = false; }
});
$('batch-save').addEventListener('click', () => {
  download('kerrigan-studio-batch.json', batch.checkpoint); saved = true; controls();
  $('progress-status').textContent = 'Batch download started. Keep the file to resume after a restart.';
});
$('pause').addEventListener('click', () => {
  paused = true; controls(); $('progress-status').textContent = 'Pausing after the current product. Already submitted work continues in the gateway.';
});
$('process').addEventListener('click', async () => {
  if (busy || reviewOpened) return;
  busy = true; paused = false; error(''); controls();
  try {
    for (let i = 0; i < batch.intents.length && !paused; i++) {
      if (jobs[i] && terminal.has(jobs[i].status)) continue;
      const intent = batch.intents[i];
      $('progress-status').textContent = `Processing ${i + 1} of ${batch.intents.length}: ${intent.product_id}`;
      // Deliberately no automatic POST retry. Resume uses this same saved key.
      jobs[i] = await api('/connect/jobs', intent.request, { 'Idempotency-Key': intent.key }); progress();
      const started = Date.now();
      while (!terminal.has(jobs[i].status)) {
        if (Date.now() - started > 120_000) throw new Error('Waiting timed out. The gateway may still be working. Resume this batch to recover the same job.');
        await new Promise(resolve => setTimeout(resolve, 500));
        jobs[i] = await api(`/connect/jobs/${jobs[i].id}`); progress();
      }
    }
    $('progress-status').textContent = paused ? 'Paused. Resume uses the same job identities.' : 'All products have receipts. Open review to check the results and approve exports.';
  } catch (e) {
    error(e); $('progress-status').textContent = 'Stopped. A lost response does not prove the request failed. Keep this batch and use Resume to recover the same intent.';
  } finally { busy = false; $('process').textContent = 'Resume batch'; controls(); }
});
$('open-review').addEventListener('click', async () => {
  error(''); $('open-review').disabled = true;
  try {
    const { session, accounting } = await api('/studio/api/review', { checkpoint: batch.checkpoint, job_ids: jobs.map(job => job.id) });
    reviewLogic().validate(session);
    $('review-host').append($('review-template').content.cloneNode(true));
    browserApp(session, reviewLogic()); reviewOpened = true;
    $('accounting').textContent = `${accounting.simulated ? 'Simulated recorded total' : 'Recorded total'}: ${accounting.recorded_sats} sats. ${accounting.unknown_rows} rows have unknown final cost.`;
    $('review-host').scrollIntoView({ behavior: 'smooth', block: 'start' }); controls();
  } catch (e) { error(e); controls(); }
});
addEventListener('beforeunload', e => { if (busy) { e.preventDefault(); e.returnValue = ''; } });
