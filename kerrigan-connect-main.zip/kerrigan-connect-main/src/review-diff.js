import { validateReview } from './review.js';
import { fingerprint } from './validation.js';
import { requireThat } from './errors.js';

/** Compare two explicit snapshots. This does not imply an authenticated audit log. */
export function compareReviews(baseline, current) {
  validateReview(baseline); validateReview(current);
  requireThat(baseline.source_hash === current.source_hash, 'different_review_source', 'Both checkpoints must refer to the exact same source batch.');
  const previous = new Map(baseline.decisions.map(d => [d.id, d]));
  const counts = decisions => Object.fromEntries(['pending','approved','rejected'].map(state => [state, decisions.filter(d => d.state === state).length]));
  const changes = current.decisions.flatMap(next => {
    const before = previous.get(next.id);
    const fields = ['category','colour','material','size'].flatMap(field => before.values[field] !== next.values[field] ? [{ field, before: before.values[field], after: next.values[field] }] : []);
    if (before.note !== next.note) fields.push({ field: 'note', before: before.note, after: next.note });
    if (!fields.length && before.state === next.state && before.reviewed_at === next.reviewed_at) return [];
    return [{ id: next.id, previous_state: before.state, next_state: next.state, fields,
      reviewed_at_before: before.reviewed_at, reviewed_at_after: next.reviewed_at,
      approval_timestamp_unchanged_after_edit: fields.length > 0 && before.state === 'approved' && next.state === 'approved' && before.reviewed_at === next.reviewed_at }];
  });
  return {
    format_version: 1, generated_at: new Date().toISOString(), source_hash: current.source_hash,
    run_id: current.source.run_id, model: current.source.model,
    baseline_checkpoint_sha256: fingerprint(baseline), current_checkpoint_sha256: fingerprint(current),
    summary: { total_products: current.source.rows.length, changed_products: changes.length,
      unchanged_products: current.source.rows.length - changes.length,
      newly_approved: changes.filter(c => c.previous_state !== 'approved' && c.next_state === 'approved').length,
      approval_removed: changes.filter(c => c.previous_state === 'approved' && c.next_state !== 'approved').length,
      edited_products: changes.filter(c => c.fields.length).length,
      approval_warnings: changes.filter(c => c.approval_timestamp_unchanged_after_edit).length,
      before: counts(baseline.decisions), after: counts(current.decisions) },
    changes,
    note: 'Snapshot comparison only: intermediate actions and reviewer identity are unknown. Files and timestamps can be edited manually. Fingerprints are not signatures. No network calls or new inference are performed.',
  };
}
const md = value => String(value ?? '—').replace(/([\\*_\[\]#!])/g, '\\$1').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\|/g, '&#124;').replace(/`/g, '&#96;').replace(/[\r\n]+/g, ' ');
export function renderReviewDiff(report) {
  const lines = ['# Catalogue review changes', '', `Run: ${md(report.run_id)}`, `Model: ${md(report.model)}`, '', report.note, '',
    '| Products | Changed | Newly approved | Approval removed | Approval warnings |', '| --- | --- | --- | --- | --- |',
    `| ${report.summary.total_products} | ${report.summary.changed_products} | ${report.summary.newly_approved} | ${report.summary.approval_removed} | ${report.summary.approval_warnings} |`, '',
    '| State | Before | After |', '| --- | --- | --- |',
    ...['pending','approved','rejected'].map(s => `| ${s} | ${report.summary.before[s]} | ${report.summary.after[s]} |`), '',
    '| Product | Previous state | Current state | Field | Before | After |', '| --- | --- | --- | --- | --- | --- |',
    ...report.changes.flatMap(c => (c.fields.length ? c.fields : [{ field: '(decision/timestamp)', before: c.reviewed_at_before, after: c.reviewed_at_after }]).map(f =>
      `| ${md(c.id)} | ${c.previous_state} | ${c.next_state}${c.approval_timestamp_unchanged_after_edit ? ' — CHECK TIMESTAMP' : ''} | ${f.field} | ${md(f.before)} | ${md(f.after)} |`)), '',
    `Source: ${report.source_hash}`, `Baseline checkpoint: ${report.baseline_checkpoint_sha256}`, `Current checkpoint: ${report.current_checkpoint_sha256}`, ''];
  if (!report.changes.length) lines.push('No differences between these checkpoints.', '');
  return lines.join('\n');
}
