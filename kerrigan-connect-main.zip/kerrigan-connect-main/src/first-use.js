import { readFileSync } from 'node:fs';

const assets = new Map([
  ['/start', ['first-use/index.html', 'text/html']],
  ['/start/', ['first-use/index.html', 'text/html']],
  ['/start/app.js', ['first-use/app.js', 'text/javascript']],
  ['/start/style.css', ['first-use/style.css', 'text/css']],
].map(([route, [file, type]]) => [route, { type, content: readFileSync(new URL(file, import.meta.url), 'utf8') }]));

export function serveFirstUse(path, res) {
  if (path === '/') {
    res.writeHead(302, { location: '/start', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
    res.end();
    return true;
  }
  const asset = assets.get(path);
  if (!asset) return false;
  res.writeHead(200, {
    'content-type': `${asset.type}; charset=utf-8`, 'cache-control': 'no-store',
    'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer',
    'content-security-policy': "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'",
  });
  res.end(asset.content);
  return true;
}

function publicModel(model) {
  return {
    id: model.id,
    simulated: model.x_kerrigan?.simulated === true,
    context_length: Number.isSafeInteger(model.x_kerrigan?.context_length) ? model.x_kerrigan.context_length : null,
  };
}

export async function firstUseStatus(gateway) {
  const observedAt = new Date().toISOString();
  const failed = Boolean(gateway.workerError);
  let models = [];
  let availability = 'unknown';
  let discoveryError = null;
  try {
    const result = await gateway.models();
    models = Array.isArray(result?.data) ? result.data.map(publicModel) : [];
    availability = models.length ? 'available' : 'empty';
  } catch {
    discoveryError = { code: 'discovery_unavailable', message: 'Model discovery could not be completed. Retry without changing the run identity.' };
  }
  const demo = gateway.mode === 'demo';
  const processStatus = failed ? 'unavailable' : demo ? 'available_simulated' : 'unavailable';
  return {
    format_version: 1,
    observed_at: observedAt,
    gateway: {
      status: failed ? 'degraded' : 'available',
      mode: gateway.mode,
      live_spending: false,
    },
    models: {
      source: demo ? 'supplied_demo' : 'observed_get',
      scope: demo ? 'Bundled deterministic sample model.' : 'Current response from the configured Coordinator; not a whole-network census.',
      availability,
      data: models,
      ...(discoveryError ? { error: discoveryError } : {}),
    },
    processing: {
      status: processStatus,
      simulated: demo,
      reason: failed ? 'The local worker is degraded.' : demo
        ? 'The guided sample is local and deterministic; it uses no GPU and spends no KRGN.'
        : 'Read-only mode permits discovery but has no wallet or paid inference route.',
    },
    next: {
      studio_path: '/studio',
      studio_ready: processStatus === 'available_simulated' && availability === 'available',
      instruction: 'Open Catalogue Studio, enter the same key again, choose the six-product sample, then prepare, process, review and export.',
    },
  };
}
