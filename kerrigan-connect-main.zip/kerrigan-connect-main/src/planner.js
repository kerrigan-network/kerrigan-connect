import { readSync, openSync, closeSync, fstatSync } from 'node:fs';
import { requireThat } from './errors.js';

const CAPABILITIES = ['chat', 'tools', 'embeddings', 'vision', 'structured_output', 'streaming', 'confidentiality'];
const object = v => v !== null && typeof v === 'object' && !Array.isArray(v);
const integer = (v, min = 0) => Number.isSafeInteger(v) && v >= min;
const modelId = v => typeof v === 'string' && /^[A-Za-z0-9_.:/-]{1,180}$/.test(v);
function check(ok, message) { requireThat(ok, 'invalid_plan_input', message); }
function amount(v) {
  if (integer(v)) return BigInt(v);
  if (typeof v === 'string' && /^(0|[1-9][0-9]{0,29})$/.test(v)) return BigInt(v);
  return null;
}
function rate(value, observed) {
  const n = amount(value);
  // Older probe versions defaulted absent input prices to zero. Do not trust legacy zero.
  return observed === false || n === null || (n === 0n && observed !== true) ? null : n;
}
const money = n => n === null ? null : n.toString();
const krgn = n => n === null ? null : `${n / 100_000_000n}.${String(n % 100_000_000n).padStart(8, '0')}`;

/** Read at most 2 MB; reject directories and avoid unbounded file reads. */
export function readPlanJson(path) {
  const fd = openSync(path, 'r');
  try {
    const info = fstatSync(fd);
    check(info.isFile() && info.size <= 2_000_000, 'Plan input must be a regular JSON file of at most 2 MB.');
    const buffer = Buffer.alloc(2_000_001);
    let size = 0, bytes;
    while (size < buffer.length && (bytes = readSync(fd, buffer, size, buffer.length - size, null)) > 0) size += bytes;
    check(size <= 2_000_000, 'Plan input exceeds 2 MB.');
    const text = buffer.subarray(0, size).toString('utf8');
    try { return JSON.parse(text); } catch { check(false, 'Plan input is not valid JSON.'); }
  } finally { closeSync(fd); }
}

export function planWorkload(probe, workload, { now = Date.now(), model = null } = {}) {
  check(object(probe) && object(workload), 'Supply probe and workload objects.');
  const fields = ['input_tokens', 'output_tokens', 'context_overhead_tokens', 'jobs', 'required_capabilities', 'max_advertised_compute_sats'];
  check(Object.keys(workload).every(k => fields.includes(k)), 'Unknown workload field.');
  const { input_tokens, output_tokens, context_overhead_tokens = 0, jobs = 1, required_capabilities = [], max_advertised_compute_sats = null } = workload;
  check(integer(input_tokens, 1) && integer(output_tokens, 1) && integer(context_overhead_tokens) && integer(jobs, 1), 'Token estimates and job count must be safe integers; input, output and jobs must be positive.');
  check(Array.isArray(required_capabilities) && required_capabilities.length <= CAPABILITIES.length
    && required_capabilities.every(c => CAPABILITIES.includes(c)) && new Set(required_capabilities).size === required_capabilities.length, 'Unknown or duplicate required capability.');
  const cap = max_advertised_compute_sats === null ? null : amount(max_advertised_compute_sats);
  check(max_advertised_compute_sats === null || cap !== null, 'Compute ceiling must be nonnegative integer satoshis.');
  check(integer(now) && Number.isFinite(new Date(now).getTime()), 'Invalid evaluation time.');
  check(model === null || modelId(model), 'Invalid requested model.');
  let coordinator;
  try {
    const url = new URL(probe.coordinator);
    check(url.protocol === 'https:' && !url.username && !url.password && !url.search && !url.hash && url.pathname === '/', 'Coordinator must be an HTTPS origin without credentials.');
    coordinator = url.origin;
  } catch { check(false, 'Coordinator must be an HTTPS origin without credentials.'); }
  const observed = typeof probe.observed_at === 'string' && /^\d{4}-\d\d-\d\dT.*(?:Z|[+-]\d\d:\d\d)$/.test(probe.observed_at) ? Date.parse(probe.observed_at) : NaN;
  const age = now - observed;
  const freshness = !Number.isFinite(age) ? 'invalid_timestamp' : age < 0 ? 'future_timestamp' : age > 300_000 ? 'stale' : 'fresh';
  check(probe.models === null || (Array.isArray(probe.models) && probe.models.length <= 1000), 'Probe models must be a list of at most 1000 models or null.');
  check(probe.errors === undefined || (Array.isArray(probe.errors) && probe.errors.every(object)), 'Invalid probe errors.');
  const modelError = (probe.errors || []).some(e => e.source === 'models');
  const catalogue = probe.models === null || modelError ? 'unavailable' : probe.models.length === 0 ? 'empty' : 'observed';
  const input = BigInt(input_tokens) + BigInt(context_overhead_tokens);
  const output = BigInt(output_tokens);
  const total = input + output;
  const count = BigInt(jobs);
  const seen = new Set();
  for (const m of probe.models || []) {
    check(object(m) && modelId(m.id) && !seen.has(m.id) && object(m.x_kerrigan), 'Malformed or duplicate model.');
    seen.add(m.id);
  }
  const candidates = (probe.models || []).filter(m => model === null || m.id === model).map(m => {
    const x = m.x_kerrigan;
    const reasons = [];
    const add = (code, status) => reasons.push({ code, status });
    if (freshness !== 'fresh') add(freshness, 'unknown');
    if (catalogue === 'unavailable') add('model_discovery_failed', 'unknown');
    if (x.simulated !== false) add('not_live_advertisement', 'unknown');
    const context = integer(x.context_length, 1) ? x.context_length : null;
    const contextFits = context === null ? null : total <= BigInt(context);
    if (contextFits === null) add('context_unknown', 'unknown');
    else if (!contextFits) add('context_exceeded', 'blocked');
    const drones = Array.isArray(x.drones) && x.drones.length <= 10000 && x.drones.every(d => typeof d === 'string' && /^[a-f0-9]{40}$/.test(d)) ? new Set(x.drones).size : null;
    if (drones === null) add('providers_unknown', 'unknown');
    else if (drones === 0) add('no_advertised_provider', 'blocked');
    const capabilities = Object.fromEntries(required_capabilities.map(c => {
      const v = x.advertised_capabilities?.[c];
      // Even a boolean advertisement cannot establish prompt confidentiality.
      const state = c === 'confidentiality' ? 'unknown' : v === true ? 'advertised' : v === false ? 'unsupported' : 'unknown';
      if (state !== 'advertised') add(`${c}_${state}`, state === 'unsupported' ? 'blocked' : 'unknown');
      return [c, state];
    }));
    const inRate = rate(x.in_rate_sat_per_token, x.rates_observed?.input);
    const outRate = rate(x.rate_sat_per_token, x.rates_observed?.output);
    const scenarios = [25, 50, 100].map(percent => {
      const tokens = (output * BigInt(percent) + 99n) / 100n;
      const inCost = inRate === null ? null : input * inRate;
      const outCost = outRate === null ? null : tokens * outRate;
      const perJob = inCost === null || outCost === null ? null : inCost + outCost;
      const batch = perJob === null ? null : perJob * count;
      return { output_limit_percent: percent, output_tokens: tokens.toString(), input_sats_per_job: money(inCost), output_sats_per_job: money(outCost),
        advertised_compute_sats_per_job: money(perJob), advertised_compute_sats_batch: money(batch), advertised_compute_krgn_batch: krgn(batch),
        fees_sats: null, final_invoice_sats: null, within_compute_ceiling: cap === null || batch === null ? null : batch <= cap };
    });
    const maximum = scenarios[2];
    if (cap !== null && maximum.within_compute_ceiling === null) add('compute_ceiling_unconfirmed', 'unknown');
    if (maximum.within_compute_ceiling === false) add('compute_ceiling_exceeded', 'blocked');
    return { id: m.id, status: reasons.some(r => r.status === 'blocked') ? 'blocked' : reasons.length ? 'unknown' : 'advertised_fit', reasons,
      context_length: context, required_context_tokens: total.toString(), context_fits: contextFits,
      advertised_providers: drones, required_capabilities: capabilities,
      price_status: inRate === null || outRate === null ? 'unknown' : 'advertised',
      input_sats_per_token: money(inRate), output_sats_per_token: money(outRate), scenarios };
  }).sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  const fits = candidates.filter(c => c.status === 'advertised_fit').map(c => c.id);
  return { format_version: 1, generated_at: new Date(now).toISOString(), observed_at: Number.isFinite(observed) ? new Date(observed).toISOString() : null,
    coordinator, scope: 'One supplied coordinator observation; not a whole-network census.', freshness, max_age_seconds: 300, catalogue,
    workload: { input_tokens, output_tokens, context_overhead_tokens, jobs, required_capabilities, max_advertised_compute_sats: money(cap) },
    requested_model: model, advertised_fits: fits,
    outcome: fits.length ? 'advertised_candidates' : 'no_confirmed_candidate',
    explanation: fits.length ? 'Numerical/context and explicitly requested advertised requirements fit; this is not verified serving or model quality.' : model && !seen.has(model) ? 'Requested model was not observed.' : 'No candidate meets all requested checks in a fresh successful observation. See candidate reasons and catalogue state.',
    candidates, spending_enabled: false, live_inference_ready: false,
    assumptions: ['Caller token estimates, not tokenisation; include full conversation, instructions and template overhead.', 'Scenarios are arithmetic at 25%, 50% and 100% of the requested output ceiling, not predicted output or probabilities.', 'Advertised rates only; no cache discount, fee, refund, final invoice, latency, throughput or confidentiality is confirmed.', 'Jobs use identical estimates; batch arithmetic does not establish concurrent capacity.', 'Legacy zero prices without explicit observation provenance are unknown. No network requests or prompts are sent by this planner.'] };
}

function escape(value) { return String(value ?? 'unknown').replace(/[&<>|`\[\]\\*_\r\n]/g, c => `&#${c.charCodeAt(0)};`); }
export function renderPlan(report) {
  const w = report.workload;
  const lines = ['# Kerrigan workload plan', '', `Observation: ${escape(report.observed_at)} — ${escape(report.freshness)}.`, '',
    `Source: ${escape(report.coordinator)}. ${escape(report.scope)}`, '',
    `Workload: ${w.jobs} job(s), ${w.input_tokens} input tokens + ${w.context_overhead_tokens} overhead, ${w.output_tokens} output ceiling per job.`, '',
    `Required capabilities: ${w.required_capabilities.map(escape).join(', ') || 'none; numerical/context screening only'}. Batch compute-only ceiling: ${w.max_advertised_compute_sats ?? 'not supplied'} satoshis.`, '', escape(report.explanation), '',
    '| Model | Fit | Context needed / advertised | Providers | Price | Reasons |', '| --- | --- | --- | --- | --- | --- |'];
  for (const m of report.candidates) lines.push(`| ${escape(m.id)} | ${m.status} | ${m.required_context_tokens} / ${m.context_length ?? 'unknown'} | ${m.advertised_providers ?? 'unknown'} | ${m.price_status} | ${m.reasons.map(r => escape(r.code)).join(', ') || 'none'} |`);
  lines.push('', '## Advertised compute scenarios — not invoices', '', '| Model | Output ceiling used | Sats / job | Sats / batch | KRGN / batch | Fees | Final invoice |', '| --- | --- | --- | --- | --- | --- | --- |');
  for (const m of report.candidates) for (const s of m.scenarios) lines.push(`| ${escape(m.id)} | ${s.output_limit_percent}% | ${s.advertised_compute_sats_per_job ?? 'unknown'} | ${s.advertised_compute_sats_batch ?? 'unknown'} | ${s.advertised_compute_krgn_batch ?? 'unknown'} | unknown | unknown |`);
  lines.push('', '## Limits', '', ...report.assumptions.map(a => `- ${a}`), '', 'Live inference and spending remain disabled.', '');
  return lines.join('\n');
}
