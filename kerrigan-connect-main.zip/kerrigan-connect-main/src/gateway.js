import { setTimeout as delay } from 'node:timers/promises';
import { ConnectError, requireThat, publicError } from './errors.js';
import { normalizeRequest, idempotencyKey, sats } from './validation.js';
import { TERMINAL } from './ledger.js';

export class Gateway {
  constructor({ ledger, provider, payments = null, mode = 'demo', budgets, autoStart = true }) {
    this.ledger = ledger; this.provider = provider; this.payments = payments;
    this.mode = mode;
    this.budgets = Object.fromEntries(['dailyBudgetSats', 'jobBudgetSats', 'maxNetworkFeeSats'].map(name => {
      const value = sats(budgets?.[name], name);
      requireThat(value > 0, 'invalid_config', `${name} must be positive.`);
      return [name, value];
    }));
    this.active = null; this.closed = false;
    requireThat(['demo', 'read-only'].includes(mode), 'live_spending_disabled', 'A production payment backend is not enabled in this milestone.', 503);
    this.ledger.recover();
    if (autoStart) this.kick();
  }
  async models() { return { object: 'list', data: await this.provider.models() }; }
  submit(body, key) {
    requireThat(!this.closed, 'shutting_down', 'Gateway is shutting down.', 503);
    requireThat(this.mode === 'demo' && this.payments, 'live_spending_disabled', 'Read-only mode supports discovery only. No wallet is connected and no paid requests can run.', 503);
    const { job, created } = this.ledger.create(idempotencyKey(key), normalizeRequest(body));
    this.kick();
    return { job: this.ledger.view(job.id), created };
  }
  kick() {
    if (this.closed || this.active || this.mode !== 'demo') return;
    // One worker per ledger. The CLI also holds an exclusive process lock.
    this.active = new Promise(resolve => setImmediate(resolve)).then(async () => {
      while (!this.closed) {
        const id = this.ledger.runnable()[0];
        if (!id) break;
        await this.process(id);
      }
    }).finally(() => { this.active = null; });
    // Errors escaping ledger I/O are fatal and observable through workerError.
    this.active.catch(error => { this.workerError = error; this.closed = true; });
  }
  async process(id) {
    try {
      let job = this.ledger.get(id);
      if (job.status === 'queued') {
        const invoice = await this.provider.quote(job.request);
        // Cancellation may happen while an invoice request is in flight.
        if (this.ledger.get(id).status === 'cancelled') return;
        this.ledger.reserve(id, invoice, this.budgets);
        this.ledger.beginPayment(id);
        const receipt = await this.payments.pay({ jobId: id, invoice, request: job.request, maxFeeSats: this.budgets.maxNetworkFeeSats });
        this.ledger.recordPayment(id, receipt);
        job = this.ledger.get(id);
      }
      if (job.status !== 'paid') return;
      this.ledger.beginInference(id);
      const result = await this.provider.infer(job.request, job.invoice, job.payment_txid);
      requireThat(result && typeof result.content === 'string' && Buffer.byteLength(result.content) <= 1_000_000,
        'invalid_output', 'Provider response is missing text or exceeds the output limit.', 502);
      // Demo refunds exercise accounting, not chain verification. Failure to
      // collect a refund does not discard a successfully received response.
      let refundError = null;
      if (this.payments.refund) {
        try {
          const refund = await this.payments.refund({ jobId: id, invoice: job.invoice, result, paymentTxid: job.payment_txid });
          if (refund) this.ledger.confirmRefund(id, refund);
        } catch { refundError = 'refund_pending_review'; }
      }
      this.ledger.complete(id, { ...result, verification: 'not_performed', ...(refundError ? { refund_status: refundError } : {}) });
    } catch (error) {
      this.ledger.fail(id, publicError(error));
    }
  }
  retry(id) {
    requireThat(!this.closed && this.mode === 'demo', 'live_spending_disabled', 'Retries are available only in the demo worker.', 503);
    this.ledger.retryPaid(id); this.kick();
    return this.ledger.view(id);
  }
  async wait(id, timeoutMs = 120_000) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const job = this.ledger.view(id);
      if (TERMINAL.has(job.status)) return job;
      if (this.workerError) throw new ConnectError('worker_failed', 'The worker stopped. Inspect the job before retrying.', 503);
      await delay(10);
    }
    throw new ConnectError('job_still_running', `Job ${id} is still running. Poll its status or repeat with the same idempotency key.`, 504);
  }
  completion(job) {
    requireThat(job.status === 'completed' && job.result, 'job_not_complete', 'The job has no retained completed output.', 409);
    const result = job.result;
    return {
      id: `chatcmpl-${job.id}`, object: 'chat.completion', created: Math.floor(Date.parse(job.created_at) / 1000), model: job.model,
      choices: [{ index: 0, message: { role: 'assistant', content: result.content }, finish_reason: result.finish_reason || 'stop' }],
      ...(result.usage ? { usage: result.usage } : {}),
      x_kerrigan: {
        job_id: job.id, simulated: this.mode === 'demo', verification: 'not_performed',
        payment_txid: job.payment_txid, paid_sats: job.paid_sats, network_fee_sats: job.network_fee_sats,
        refunded_sats: job.refunded_sats, net_cost_sats: job.net_cost_sats,
        usage_estimated: result.usage_estimated ?? false,
      },
    };
  }
  async stop() { this.closed = true; if (this.active) await this.active; }
}
