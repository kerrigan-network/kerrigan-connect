/** Interpret observations, never infer payment safety from a healthy endpoint. */
export function assessReadiness(probe, { model, now = Date.now(), snapshot = false } = {}) {
  const age = now - Date.parse(probe.observed_at);
  const fresh = Number.isFinite(age) && age >= -60_000 && age <= 300_000;
  const models = Array.isArray(probe.models) ? probe.models : [];
  const candidates = model ? models.filter(m => m.id === model) : models;
  const available = candidates.filter(m => Array.isArray(m.x_kerrigan?.drones) && m.x_kerrigan.drones.length > 0);
  const checks = [
    { id: 'observation', status: fresh ? 'pass' : 'unknown', detail: fresh ? 'Observation is within five minutes.' : 'Observation is stale or has an invalid timestamp; refresh before use.' },
    { id: 'model', status: !Array.isArray(probe.models) ? 'unknown' : available.length ? 'pass' : 'blocked', detail: available.length ? 'Requested model scope has an advertised provider.' : 'No available model provider was confirmed in the requested scope.' },
    { id: 'coordinator', status: Number.isSafeInteger(probe.connected_drones) && probe.connected_drones > 0 ? 'pass' : probe.connected_drones === 0 ? 'blocked' : 'unknown', detail: 'Reported connected Drones on this coordinator only.' },
    { id: 'chain', status: Number.isSafeInteger(probe.chain?.height) && probe.chain.height > 0 ? 'pass' : 'unknown', detail: 'Explorer reachability does not verify invoice expiry or transaction finality.' },
    { id: 'wallet', status: 'blocked', detail: 'Live signing, broadcasting and reconciliation are not implemented in Connect.' },
    { id: 'paid_pilot', status: 'blocked', detail: 'Real inference and refunds have not been verified end to end.' },
    { id: 'confidentiality', status: 'unknown', detail: 'No verified confidential-inference guarantee. Public-source prompt path uses HTTPS to the coordinator.' },
  ];
  return { format_version: 1, generated_at: new Date(now).toISOString(), observed_at: probe.observed_at,
    source: snapshot ? 'supplied_snapshot' : 'live_get', coordinator: probe.coordinator, scope: probe.scope,
    requested_model: model || null, discovery_ready: checks.slice(0, 4).every(c => c.status === 'pass'),
    live_inference_ready: false, spending_enabled: false, checks,
    models: available.map(m => ({ id: m.id, providers: m.x_kerrigan.drones.length, context_length: m.x_kerrigan.context_length,
      output_sats_per_token: m.x_kerrigan.rate_sat_per_token ?? null, input_sats_per_token: m.x_kerrigan.in_rate_sat_per_token ?? null })),
    drone_block_payout_active: probe.chain?.drone_payout_active ?? null,
    note: 'Drone block payouts are distinct from per-request inference payments. Advertised rates are not an invoice or a final cost. No POST requests or payments are made.',
    errors: Array.isArray(probe.errors) ? probe.errors : [],
  };
}
