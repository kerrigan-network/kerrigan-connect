import { openSync, readFileSync, writeFileSync, unlinkSync, closeSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
import { ConnectError } from './errors.js';

/** One worker process per data directory. Existing locks always fail closed.
 * Automatic stale-lock deletion has a check/unlink race; recovery is explicit. */
export function acquireLock(directory) {
  mkdirSync(directory, { recursive: true, mode: 0o700 });
  const path = join(directory, 'gateway.lock');
  const token = randomUUID();
  const attempt = () => {
    const fd = openSync(path, 'wx', 0o600);
    try { writeFileSync(fd, JSON.stringify({ pid: process.pid, token })); } finally { closeSync(fd); }
  };
  try { attempt(); }
  catch (error) {
    if (error.code !== 'EEXIST') throw error;
    let owner;
    try { owner = JSON.parse(readFileSync(path, 'utf8')); } catch { throw new ConnectError('ledger_locked', 'Unreadable gateway lock; inspect it manually before proceeding.', 409); }
    if (!Number.isInteger(owner.pid) || owner.pid <= 0) throw new ConnectError('ledger_locked', 'Invalid gateway lock; inspect it manually.', 409);
    throw new ConnectError('ledger_locked', `A gateway lock exists for PID ${owner.pid}. If it crashed, confirm no worker is running before manually removing gateway.lock.`, 409);
  }
  return release;
  function release() {
    try { if (JSON.parse(readFileSync(path, 'utf8')).token === token) unlinkSync(path); } catch { /* already released */ }
  }
}
