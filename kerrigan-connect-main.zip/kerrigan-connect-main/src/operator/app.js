const el = id => document.getElementById(id);
let apiKey = '';
const set = (id, value) => { el(id).textContent = value; };
const label = value => String(value ?? 'unknown').replaceAll('_', ' ');

function render(report) {
  set('gateway', label(report.local_gateway.status));
  set('gateway-detail', `${label(report.local_gateway.mode)} · live spending disabled`);
  set('compatibility', label(report.compatibility.registration_contract));
  set('compatibility-detail', report.compatibility.reason);
  set('models', label(report.models.state));
  set('models-detail', `${report.models.data.length} model(s) · ${label(report.models.source)}`);
  set('problems', report.local_jobs.problems.length);
  set('problems-detail', `${report.local_jobs.observed} bounded local jobs observed`);
  set('utilisation', report.observed_utilisation.jobs_observed);
  set('utilisation-detail', `${report.observed_utilisation.attempts} attempts · cost ${label(report.observed_utilisation.cost_kind)}`);
  set('mining', label(report.readiness.mining));
  el('jobs').replaceChildren(...(report.local_jobs.problems.length ? report.local_jobs.problems : [{ id: 'None observed', status: '—', model: '—', error_code: '—' }]).map(job => {
    const row = document.createElement('tr');
    for (const value of [job.id, label(job.status), job.model, job.error_code]) { const cell = document.createElement('td'); cell.textContent = value; row.append(cell); }
    return row;
  }));
}

async function request(supplied) {
  const candidate = el('key').value;
  if (candidate) { apiKey = candidate; el('key').value = ''; }
  if (!apiKey) throw new Error('Enter the current local gateway key.');
  const response = await fetch(supplied ? '/operator/api/supplied' : '/connect/operator', {
    method: supplied ? 'POST' : 'GET', headers: { Authorization: `Bearer ${apiKey}`, ...(supplied ? { 'Content-Type': 'application/json' } : {}) },
    ...(supplied ? { body: JSON.stringify(supplied) } : {}),
  });
  const body = await response.json();
  if (!response.ok) throw new Error(body.error?.message || `Diagnostic request failed (${response.status}).`);
  render(body);
}

el('refresh').addEventListener('click', async () => { set('error', ''); try { await request(null); } catch (error) { set('error', error.message); } });
el('file').addEventListener('change', async event => {
  set('error', '');
  try {
    const file = event.target.files[0];
    if (!file) return;
    if (file.size > 200000) throw new Error('Diagnostic file exceeds 200 KB.');
    await request(JSON.parse(await file.text()));
  } catch (error) { set('error', error.message); }
  finally { event.target.value = ''; }
});
