/** Pure review rules shared verbatim by Node and the standalone browser page. */
export function reviewLogic() {
  const fields = ['category', 'colour', 'material', 'size'];
  const normal = s => s.toLowerCase().trim().replace(/\s+/g, ' ');
  const string = (s, max) => typeof s === 'string' && s.length <= max;
  const assert = (ok, message) => { if (!ok) throw new Error(message); };
  const canonical = v => JSON.stringify(v && typeof v === 'object' ? Array.isArray(v) ? v.map(x => JSON.parse(canonical(x))) : Object.fromEntries(Object.keys(v).sort().map(k => [k, JSON.parse(canonical(v[k]))])) : v);
  function errors(row, values, taxonomy) {
    const result = [];
    if (!taxonomy.includes(values.category)) result.push('Choose a category from the taxonomy.');
    for (const k of fields.slice(1)) {
      if (!string(values[k], 200)) result.push(`${k} must be text of at most 200 characters.`);
      else if (values[k].trim() && !normal(row.description).includes(normal(values[k]))) result.push(`${k} needs literal evidence in the source description; leave blank if unknown.`);
    }
    return result;
  }
  function validate(session) {
    assert(session?.format === 'kconnect-review' && session.version === 1 && /^[a-f0-9]{64}$/.test(session.source_hash), 'Invalid review file format.');
    const s = session.source;
    assert(s && string(s.run_id, 200) && s.run_id.trim() && string(s.model, 180) && s.model.trim(), 'Invalid run or model.');
    assert(Array.isArray(s.taxonomy) && s.taxonomy.length > 0 && s.taxonomy.length <= 100 && s.taxonomy.includes('Uncategorised') && new Set(s.taxonomy).size === s.taxonomy.length && s.taxonomy.every(t => string(t, 100) && t.trim()), 'Invalid taxonomy.');
    assert(Array.isArray(s.rows) && s.rows.length > 0 && s.rows.length <= 1000 && Array.isArray(session.decisions) && session.decisions.length === s.rows.length, 'Review requires 1–1000 rows and one decision per row.');
    const ids = new Set();
    const decisions = new Map(session.decisions.map(d => [d?.id, d]));
    assert(decisions.size === s.rows.length, 'Duplicate review decisions.');
    for (const row of s.rows) {
      assert(row && string(row.id, 200) && row.id.trim() && !ids.has(row.id) && string(row.description, 10000) && row.description.trim(), 'Invalid or duplicate source row.');
      ids.add(row.id);
      assert(fields.every(k => string(row[k], 200)) && string(row.flags, 6000) && string(row.error, 200) && string(row.job_id, 200) && ['accepted','review_required'].includes(row.status)
        && [true,false,null].includes(row.simulated) && (row.net_cost_sats === null || Number.isSafeInteger(row.net_cost_sats) && row.net_cost_sats >= 0), 'Invalid source metadata.');
      const d = decisions.get(row.id);
      assert(d && ['pending','approved','rejected'].includes(d.state) && d.values && fields.every(k => string(d.values[k], 200)) && string(d.note, 2000), 'Invalid review decision.');
      assert(d.state === 'pending' ? d.reviewed_at === null : string(d.reviewed_at, 40) && Number.isFinite(Date.parse(d.reviewed_at)), 'Invalid decision timestamp.');
      if (d.state === 'approved') assert(errors(row, d.values, s.taxonomy).length === 0, 'An approved row contains unsupported values.');
    }
    return session;
  }
  function update(session, id, values, note) {
    validate(session);
    const d = session.decisions.find(d => d.id === id);
    assert(d, 'Unknown product ID.');
    assert(values && fields.every(k => string(values[k], 200)) && string(note, 2000), 'Invalid edited values.');
    if (fields.some(k => values[k] !== d.values[k]) || note !== d.note) {
      d.values = Object.fromEntries(fields.map(k => [k, values[k]])); d.note = note; d.state = 'pending'; d.reviewed_at = null;
    }
    return d;
  }
  function decide(session, id, state, now = new Date().toISOString()) {
    validate(session);
    assert(['pending','approved','rejected'].includes(state), 'Unknown review decision.');
    const d = session.decisions.find(d => d.id === id), row = session.source.rows.find(r => r.id === id);
    assert(d && row, 'Unknown product ID.');
    if (state === 'approved') { const issues = errors(row, d.values, session.source.taxonomy); assert(!issues.length, issues.join(' ')); }
    assert(string(now, 40) && Number.isFinite(Date.parse(now)), 'Invalid decision timestamp.');
    d.state = state; d.reviewed_at = state === 'pending' ? null : now;
    return d;
  }
  function restore(current, incoming) {
    validate(current); validate(incoming);
    assert(current.source_hash === incoming.source_hash && canonical(current.source) === canonical(incoming.source), 'This checkpoint belongs to a different source batch.');
    current.decisions = structuredClone(incoming.decisions);
    return current;
  }
  function csv(session) {
    validate(session);
    const header = ['id','description','category','colour','material','size','review_status','review_note','reviewed_at','job_id','net_cost_sats','simulated','source_hash'];
    const cell = v => { let s = String(v ?? ''); if (/^[\s]*[=+@-]/.test(s) || /^[\t\r]/.test(s)) s = `'${s}`; return `"${s.replaceAll('"','""')}"`; };
    const rows = session.source.rows.flatMap(row => {
      const d = session.decisions.find(d => d.id === row.id);
      return d.state === 'approved' ? [{ ...row, ...d.values, review_status: d.state, review_note: d.note, reviewed_at: d.reviewed_at, source_hash: session.source_hash }] : [];
    });
    return [header, ...rows.map(r => header.map(k => r[k]))].map(r => r.map(cell).join(',')).join('\r\n') + '\r\n';
  }
  return { validate, errors, update, decide, restore, csv };
}
