import { readFileSync } from 'node:fs';
import { requireThat } from './errors.js';

const assets = new Map([
  ['/operator', ['operator/index.html', 'text/html']],
  ['/operator/', ['operator/index.html', 'text/html']],
  ['/operator/app.js', ['operator/app.js', 'text/javascript']],
  ['/operator/style.css', ['operator/style.css', 'text/css']],
].map(([route, [file, type]]) => [route, { type, content: readFileSync(new URL(file, import.meta.url), 'utf8') }]));

const SOURCE = Object.freeze({
  observed_at: '2026-09-26T20:58:00.000Z',
  core: {
    repository: 'kerrigan-network/kerrigan',
    commit: '7c4d3e5fa11525827f8152d168c6ca7a127e16bf',
    contract: 'CDroneRegTx v1; Core v1.3.0 special transaction registration',
    path: 'src/evo/inference_wire.h',
  },
  sdk: {
    repository: 'kerrigan-network/kerrigan-sdk',
    commit: 'ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29',
  },
});

function exactKeys(value, allowed, field) {
  requireThat(value && typeof value === 'object' && !Array.isArray(value), 'invalid_operator_diagnostic', `${field} must be an object.`);
  requireThat(Object.keys(value).every(key => allowed.has(key)), 'invalid_operator_diagnostic', `${field} contains an unsupported field.`);
}

function nullableText(value, field, max = 160) {
  if (value == null) return null;
  requireThat(typeof value === 'string' && value.length > 0 && value.length <= max && !/[\u0000-\u001f\u007f]/.test(value), 'invalid_operator_diagnostic', `${field} is invalid.`);
  return value;
}

function nullableInteger(value, field, max = 1_000_000_000) {
  if (value == null) return null;
  requireThat(Number.isSafeInteger(value) && value >= 0 && value <= max, 'invalid_operator_diagnostic', `${field} is invalid.`);
  return value;
}

export function validateOperatorDiagnostic(input) {
  exactKeys(input, new Set(['format_version', 'observed_at', 'source', 'drone']), 'diagnostic');
  requireThat(input.format_version === 1 && input.source === 'supplied', 'invalid_operator_diagnostic', 'Expected a version 1 supplied diagnostic.');
  requireThat(typeof input.observed_at === 'string' && !Number.isNaN(Date.parse(input.observed_at)), 'invalid_operator_diagnostic', 'observed_at must be an ISO timestamp.');
  const drone = input.drone;
  exactKeys(drone, new Set(['version', 'installation', 'health', 'models', 'utilisation', 'mining_detected']), 'drone');
  exactKeys(drone.installation, new Set(['os', 'arch', 'channel']), 'drone.installation');
  exactKeys(drone.health, new Set(['service', 'coordinator']), 'drone.health');
  exactKeys(drone.utilisation, new Set(['window_minutes', 'jobs_completed', 'jobs_failed', 'gpu_busy_percent']), 'drone.utilisation');
  requireThat(['healthy', 'degraded', 'unavailable', 'unknown'].includes(drone.health.service), 'invalid_operator_diagnostic', 'Service health is invalid.');
  requireThat(['connected', 'disconnected', 'unknown'].includes(drone.health.coordinator), 'invalid_operator_diagnostic', 'Coordinator health is invalid.');
  requireThat(Array.isArray(drone.models) && drone.models.length <= 100 && drone.models.every(value => typeof value === 'string' && /^[A-Za-z0-9_.:/-]{1,180}$/.test(value)), 'invalid_operator_diagnostic', 'Model observations are invalid.');
  requireThat(drone.mining_detected == null || typeof drone.mining_detected === 'boolean', 'invalid_operator_diagnostic', 'mining_detected must be boolean or null.');
  return {
    format_version: 1,
    observed_at: new Date(input.observed_at).toISOString(),
    source: 'supplied',
    drone: {
      version: nullableText(drone.version, 'drone.version', 80),
      installation: {
        os: nullableText(drone.installation.os, 'drone.installation.os', 80),
        arch: nullableText(drone.installation.arch, 'drone.installation.arch', 80),
        channel: nullableText(drone.installation.channel, 'drone.installation.channel', 80),
      },
      health: { service: drone.health.service, coordinator: drone.health.coordinator },
      models: [...new Set(drone.models)].sort(),
      utilisation: {
        window_minutes: nullableInteger(drone.utilisation.window_minutes, 'drone.utilisation.window_minutes', 525_600),
        jobs_completed: nullableInteger(drone.utilisation.jobs_completed, 'drone.utilisation.jobs_completed'),
        jobs_failed: nullableInteger(drone.utilisation.jobs_failed, 'drone.utilisation.jobs_failed'),
        gpu_busy_percent: nullableInteger(drone.utilisation.gpu_busy_percent, 'drone.utilisation.gpu_busy_percent', 100),
      },
      mining_detected: drone.mining_detected ?? null,
    },
  };
}

export function serveOperatorConsole(path, res) {
  const asset = assets.get(path);
  if (!asset) return false;
  res.writeHead(200, {
    'content-type': `${asset.type}; charset=utf-8`, 'cache-control': 'no-store',
    'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer',
    'content-security-policy': "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'",
  });
  res.end(asset.content);
  return true;
}

function safeModel(model) {
  return { id: model.id, simulated: model.x_kerrigan?.simulated === true, context_length: Number.isSafeInteger(model.x_kerrigan?.context_length) ? model.x_kerrigan.context_length : null };
}

export async function operatorReport(gateway, { supplied = null } = {}) {
  const jobs = gateway.ledger.list(200);
  let models = [], modelState = 'unknown', modelError = null;
  try {
    const result = await gateway.models();
    models = Array.isArray(result?.data) ? result.data.slice(0, 1000).map(safeModel) : [];
    modelState = models.length ? 'observed' : 'empty_advertised_list';
  } catch {
    modelError = 'discovery_unavailable';
  }
  const counts = {};
  for (const job of jobs) counts[job.status] = (counts[job.status] || 0) + 1;
  const problemJobs = jobs.filter(job => ['failed', 'needs_reconciliation'].includes(job.status)).slice(0, 25).map(job => ({
    id: job.id, status: job.status, model: job.model, updated_at: job.updated_at,
    attempts: job.attempts, error_code: typeof job.error?.code === 'string' ? job.error.code : 'unknown',
  }));
  const suppliedDiagnostic = supplied ? validateOperatorDiagnostic(supplied) : null;
  return {
    format_version: 1,
    observed_at: new Date().toISOString(),
    scope: 'One local Connect ledger and its configured model source; not a network census or provider-control plane.',
    local_gateway: { status: gateway.workerError ? 'degraded' : 'available', mode: gateway.mode, live_spending: false },
    compatibility: {
      runtime_version: 'unknown',
      install_compatibility: 'unknown',
      registration_contract: 'known_mismatch',
      reason: 'Maintained Core says the SDK and Coordinator registration path still use the replaced OP_RETURN form. Current maintained Drone runtime/installer source was unavailable, so no runtime version is declared compatible.',
      source: SOURCE,
    },
    models: { state: modelState, source: gateway.mode === 'demo' ? 'supplied_demo' : 'live_get', data: models, ...(modelError ? { error_code: modelError } : {}) },
    local_jobs: {
      observed: jobs.length, status_counts: counts, problems: problemJobs,
      truncated: jobs.length === 200 || problemJobs.length === 25,
    },
    observed_utilisation: {
      scope: 'Local Connect ledger only',
      jobs_observed: jobs.length,
      attempts: jobs.reduce((sum, job) => sum + job.attempts, 0),
      net_cost_sats: gateway.mode === 'demo' ? jobs.reduce((sum, job) => sum + job.net_cost_sats, 0) : null,
      cost_kind: gateway.mode === 'demo' ? 'simulated' : 'unknown',
      gpu_utilisation_percent: null,
    },
    supplied_diagnostic: suppliedDiagnostic,
    readiness: {
      inference_service: gateway.mode === 'demo' ? 'simulated_only' : suppliedDiagnostic ? 'supplied_unverified' : 'unknown',
      mining: suppliedDiagnostic?.drone.mining_detected == null ? 'unknown' : suppliedDiagnostic.drone.mining_detected ? 'observed_supplied' : 'not_observed_supplied',
      mining_does_not_establish_inference_readiness: true,
    },
    controls: { provider_registration: false, service_mutation: false, wallet_operations: false, browser_shell: false },
  };
}
