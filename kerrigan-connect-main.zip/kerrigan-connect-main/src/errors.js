export class ConnectError extends Error {
  constructor(code, message, status = 400) {
    super(message);
    this.name = 'ConnectError';
    this.code = code;
    this.status = status;
  }
}

export function requireThat(condition, code, message, status = 400) {
  if (!condition) throw new ConnectError(code, message, status);
}

export function publicError(error) {
  return error instanceof ConnectError
    ? { code: error.code, message: error.message }
    : { code: 'internal_error', message: 'An internal operation failed. Inspect the job state before retrying.' };
}
