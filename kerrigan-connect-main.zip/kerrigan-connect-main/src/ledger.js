import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, chmodSync } from 'node:fs';
import { dirname } from 'node:path';
import { randomUUID } from 'node:crypto';
import { requireThat } from './errors.js';
import { canonical, fingerprint, sats } from './validation.js';

export const TERMINAL = new Set(['completed', 'failed', 'cancelled', 'needs_reconciliation']);

export class Ledger {
  constructor(path = ':memory:', { now = () => new Date(), mode = 'demo' } = {}) {
    this.now = now;
    if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true, mode: 0o700 });
    this.db = new DatabaseSync(path, { timeout: 5000 });
    if (path !== ':memory:') chmodSync(path, 0o600);
    this.db.exec(`
      PRAGMA journal_mode = WAL;
      PRAGMA synchronous = FULL;
      PRAGMA foreign_keys = ON;
      CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL) STRICT;
      CREATE TABLE IF NOT EXISTS jobs (
        id TEXT PRIMARY KEY, idem_key TEXT NOT NULL UNIQUE, request_hash TEXT NOT NULL,
        request_json TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
        invoice_json TEXT, payment_txid TEXT UNIQUE, result_json TEXT, error_json TEXT,
        reserved_sats INTEGER NOT NULL DEFAULT 0 CHECK(reserved_sats >= 0),
        paid_sats INTEGER NOT NULL DEFAULT 0 CHECK(paid_sats >= 0),
        fee_sats INTEGER NOT NULL DEFAULT 0 CHECK(fee_sats >= 0),
        refunded_sats INTEGER NOT NULL DEFAULT 0 CHECK(refunded_sats >= 0),
        paid_at TEXT, attempts INTEGER NOT NULL DEFAULT 0
      ) STRICT;
      CREATE TABLE IF NOT EXISTS events (
        seq INTEGER PRIMARY KEY, job_id TEXT NOT NULL REFERENCES jobs(id) ON DELETE CASCADE,
        at TEXT NOT NULL, status TEXT NOT NULL, detail TEXT NOT NULL
      ) STRICT;
      CREATE TABLE IF NOT EXISTS refunds (
        txid TEXT PRIMARY KEY, job_id TEXT NOT NULL REFERENCES jobs(id),
        amount_sats INTEGER NOT NULL CHECK(amount_sats >= 0), confirmed_at TEXT NOT NULL
      ) STRICT;
      CREATE TABLE IF NOT EXISTS prepared_payments (
        job_id TEXT PRIMARY KEY REFERENCES jobs(id), txid TEXT NOT NULL UNIQUE,
        tx_hex TEXT NOT NULL, fee_sats INTEGER NOT NULL,
        spent_json TEXT NOT NULL, request_hash TEXT NOT NULL, invoice_hash TEXT NOT NULL,
        broadcast_started INTEGER NOT NULL DEFAULT 0 CHECK(broadcast_started IN (0,1))
      ) STRICT;
      CREATE TABLE IF NOT EXISTS prepared_inputs (
        txid TEXT NOT NULL, vout INTEGER NOT NULL,
        job_id TEXT NOT NULL REFERENCES prepared_payments(job_id),
        PRIMARY KEY(txid, vout)
      ) STRICT;
    `);
    this.db.prepare('INSERT OR IGNORE INTO metadata VALUES (?, ?)').run('schema_version', '1');
    requireThat(this.db.prepare('SELECT value FROM metadata WHERE key=?').get('schema_version').value === '1',
      'unsupported_schema', 'Unsupported ledger version.');
    this.db.prepare('INSERT OR IGNORE INTO metadata VALUES (?, ?)').run('mode', mode);
    requireThat(this.db.prepare('SELECT value FROM metadata WHERE key=?').get('mode').value === mode,
      'mode_mismatch', 'Use a separate data directory for each mode; simulated accounting must not mix with live observations.');
  }

  timestamp() { return this.now().toISOString(); }
  atomic(fn) {
    this.db.exec('BEGIN IMMEDIATE');
    try { const result = fn(); this.db.exec('COMMIT'); return result; }
    catch (error) { this.db.exec('ROLLBACK'); throw error; }
  }
  event(id, status, detail) {
    this.db.prepare('INSERT INTO events(job_id, at, status, detail) VALUES (?, ?, ?, ?)').run(id, this.timestamp(), status, detail);
  }
  get(id) {
    const row = this.db.prepare('SELECT * FROM jobs WHERE id=?').get(id);
    requireThat(row, 'job_not_found', 'Job not found.', 404);
    return {
      ...row, request: JSON.parse(row.request_json),
      invoice: row.invoice_json ? JSON.parse(row.invoice_json) : null,
      result: row.result_json ? JSON.parse(row.result_json) : null,
      error: row.error_json ? JSON.parse(row.error_json) : null,
    };
  }
  create(key, request) {
    return this.atomic(() => {
      const hash = fingerprint(request);
      const previous = this.db.prepare('SELECT id, request_hash FROM jobs WHERE idem_key=?').get(key);
      if (previous) {
        requireThat(previous.request_hash === hash, 'idempotency_conflict', 'This idempotency key belongs to a different request.', 409);
        return { job: this.get(previous.id), created: false };
      }
      const id = `job_${randomUUID()}`;
      const at = this.timestamp();
      this.db.prepare(`INSERT INTO jobs(id, idem_key, request_hash, request_json, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, 'queued', ?, ?)`).run(id, key, hash, canonical(request), at, at);
      this.event(id, 'queued', 'Request accepted.');
      return { job: this.get(id), created: true };
    });
  }
  reserve(id, invoice, { dailyBudgetSats, jobBudgetSats, maxNetworkFeeSats }) {
    return this.atomic(() => {
      const job = this.get(id);
      requireThat(job.status === 'queued', 'invalid_state', 'Only queued jobs may reserve a budget.', 409);
      const amount = sats(invoice.amount_sat, 'Invoice amount');
      const reserve = amount + maxNetworkFeeSats;
      const jobLimit = Math.min(jobBudgetSats, job.request.budget_sats ?? jobBudgetSats);
      requireThat(reserve <= jobLimit, 'job_budget_exceeded', 'The invoice plus maximum network fee exceeds the job budget.', 402);
      requireThat(this.budget().daily_committed_sats + reserve <= dailyBudgetSats,
        'daily_budget_exceeded', 'The invoice exceeds the remaining daily budget.', 402);
      this.db.prepare(`UPDATE jobs SET status='quoted', invoice_json=?, reserved_sats=?, updated_at=? WHERE id=?`)
        .run(JSON.stringify(invoice), reserve, this.timestamp(), id);
      this.event(id, 'quoted', 'Invoice and maximum network fee reserved atomically.');
      return this.get(id);
    });
  }
  beginPayment(id) {
    return this.atomic(() => {
      requireThat(this.get(id).status === 'quoted', 'invalid_state', 'Payment requires a reserved quote.', 409);
      this.db.prepare("UPDATE jobs SET status='payment_pending', updated_at=? WHERE id=?").run(this.timestamp(), id);
      this.event(id, 'payment_pending', 'Durable payment intent recorded before calling the payment backend.');
    });
  }
  recordPayment(id, receipt) {
    return this.atomic(() => {
      return this.#recordPaymentInsideTransaction(id, receipt);
    });
  }
  #recordPaymentInsideTransaction(id, receipt) {
      const job = this.get(id);
      requireThat(job.status === 'payment_pending', 'invalid_state', 'Payment intent is not pending.', 409);
      requireThat(typeof receipt.txid === 'string' && /^[a-f0-9]{64}$/.test(receipt.txid), 'invalid_receipt', 'Payment backend returned an invalid transaction identifier.', 502);
      const amount = sats(receipt.amount_sats, 'Paid amount');
      const fee = sats(receipt.fee_sats, 'Payment fee');
      const prepared = this.preparedPayment(id);
      requireThat(!prepared || (prepared.broadcast_started && prepared.txid === receipt.txid && prepared.fee_sats === fee),
        'invalid_receipt', 'Receipt differs from the saved transaction.', 502);
      requireThat(amount === job.invoice.amount_sat && amount + fee <= job.reserved_sats,
        'invalid_receipt', 'Payment receipt does not match the authorised invoice and fee ceiling.', 502);
      this.db.prepare(`UPDATE jobs SET status='paid', payment_txid=?, paid_sats=?, fee_sats=?, reserved_sats=0,
        paid_at=?, updated_at=? WHERE id=?`).run(receipt.txid, amount, fee, this.timestamp(), this.timestamp(), id);
      this.event(id, 'paid', 'Payment transaction recorded. This job will never create another payment.');
  }
  preparedPayment(id) {
    const row = this.db.prepare('SELECT * FROM prepared_payments WHERE job_id=?').get(id);
    return row ? { ...row, spent_utxos: JSON.parse(row.spent_json) } : null;
  }
  stagePayment(id, signed) {
    // Accept the maintained SDK output shape. This validates bounds/consistency,
    // not signatures, transaction semantics or chain inclusion.
    return this.atomic(() => {
      const job = this.get(id);
      requireThat(job.status === 'payment_pending', 'invalid_state', 'Prepare only a pending payment.', 409);
      requireThat(signed && typeof signed.txid === 'string' && /^[a-f0-9]{64}$/.test(signed.txid)
        && typeof signed.tx_hex === 'string' && /^(?:[a-f0-9]{2}){1,100000}$/.test(signed.tx_hex)
        && Array.isArray(signed.spent_utxos) && signed.spent_utxos.length > 0 && signed.spent_utxos.length <= 1000
        && signed.spent_utxos.every(x => Array.isArray(x) && x.length === 2 && typeof x[0] === 'string'
          && /^[a-f0-9]{64}$/.test(x[0]) && Number.isInteger(x[1]) && x[1] >= 0 && x[1] <= 0xffffffff)
        && new Set(signed.spent_utxos.map(x => x.join(':'))).size === signed.spent_utxos.length,
        'invalid_prepared_payment', 'Invalid SDK payment output.');
      const fee = sats(signed.fee, 'Prepared fee');
      requireThat(job.invoice.amount_sat + fee <= job.reserved_sats,
        'invalid_prepared_payment', 'Prepared payment exceeds its fee reservation.');
      const values = [signed.txid, signed.tx_hex, fee, canonical(signed.spent_utxos), job.request_hash, fingerprint(job.invoice)];
      const old = this.preparedPayment(id);
      if (old) {
        requireThat(canonical(values) === canonical([old.txid, old.tx_hex, old.fee_sats, old.spent_json, old.request_hash, old.invoice_hash]),
          'prepared_payment_conflict', 'A different payment is already prepared for this job.', 409);
        return old;
      }
      this.db.prepare('INSERT INTO prepared_payments(job_id,txid,tx_hex,fee_sats,spent_json,request_hash,invoice_hash) VALUES (?,?,?,?,?,?,?)').run(id, ...values);
      for (const [txid, vout] of signed.spent_utxos) {
        requireThat(!this.db.prepare('SELECT 1 FROM prepared_inputs WHERE txid=? AND vout=?').get(txid, vout),
          'payment_input_reserved', 'A prepared payment already reserves this input.', 409);
        this.db.prepare('INSERT INTO prepared_inputs VALUES (?,?,?)').run(txid, vout, id);
      }
      this.event(id, 'payment_pending', 'Exact prepared transaction saved before broadcast.');
      return this.preparedPayment(id);
    });
  }
  beginPreparedBroadcast(id) {
    return this.atomic(() => {
      const job = this.get(id), saved = this.preparedPayment(id);
      requireThat(job.status === 'payment_pending' && saved && !saved.broadcast_started,
        'reconciliation_required', 'Broadcast may already have started; look up the saved transaction instead.', 409);
      requireThat(saved.request_hash === job.request_hash && saved.invoice_hash === fingerprint(job.invoice),
        'prepared_payment_conflict', 'Prepared payment no longer matches the job.', 409);
      this.db.prepare('UPDATE prepared_payments SET broadcast_started=1 WHERE job_id=?').run(id);
      this.event(id, 'payment_pending', 'Broadcast attempt recorded durably; automatic rebroadcast is disabled.');
      return saved;
    });
  }
  reconcilePreparedPayment(id, observedHex) {
    // Internal seam for a trusted transaction reader, never an HTTP receipt API.
    // Matching bytes prove only that the configured reader returned those bytes.
    return this.atomic(() => {
      const job = this.get(id), saved = this.preparedPayment(id);
      requireThat(saved && saved.broadcast_started && ['payment_pending', 'needs_reconciliation'].includes(job.status)
        && !job.payment_txid, 'invalid_state', 'No unresolved prepared broadcast to reconcile.', 409);
      requireThat(typeof observedHex === 'string' && observedHex === saved.tx_hex,
        'payment_not_observed', 'Lookup did not return the exact prepared transaction; reservation retained.', 409);
      requireThat(saved.request_hash === job.request_hash && saved.invoice_hash === fingerprint(job.invoice),
        'prepared_payment_conflict', 'Prepared payment no longer matches the job.', 409);
      this.db.prepare("UPDATE jobs SET status='payment_pending', error_json=NULL WHERE id=?").run(id);
      this.#recordPaymentInsideTransaction(id, { txid: saved.txid, amount_sats: job.invoice.amount_sat, fee_sats: saved.fee_sats });
      this.event(id, 'paid', 'Configured reader returned the exact saved bytes; confirmations and execution are not verified.');
      return this.get(id);
    });
  }
  beginInference(id) {
    return this.atomic(() => {
      requireThat(this.get(id).status === 'paid', 'invalid_state', 'Inference requires an existing payment.', 409);
      this.db.prepare("UPDATE jobs SET status='running', attempts=attempts+1, updated_at=? WHERE id=?").run(this.timestamp(), id);
      this.event(id, 'running', 'Submitting inference with the stored payment transaction.');
    });
  }
  complete(id, result) {
    return this.atomic(() => {
      requireThat(this.get(id).status === 'running', 'invalid_state', 'Only a running job can complete.', 409);
      this.db.prepare("UPDATE jobs SET status='completed', result_json=?, error_json=NULL, updated_at=? WHERE id=?")
        .run(JSON.stringify(result), this.timestamp(), id);
      this.event(id, 'completed', 'Output received; verification status is reported separately.');
    });
  }
  fail(id, error) {
    return this.atomic(() => {
      const job = this.get(id);
      if (TERMINAL.has(job.status)) return;
      const ambiguous = ['payment_pending', 'paid', 'running'].includes(job.status);
      const status = ambiguous ? 'needs_reconciliation' : 'failed';
      this.db.prepare('UPDATE jobs SET status=?, error_json=?, reserved_sats=?, updated_at=? WHERE id=?')
        .run(status, JSON.stringify(error), ambiguous ? job.reserved_sats : 0, this.timestamp(), id);
      this.event(id, status, ambiguous ? 'Payment or execution outcome needs review; automatic repayment is prohibited.' : 'Request failed before payment. Reservation released.');
    });
  }
  retryPaid(id) {
    return this.atomic(() => {
      const job = this.get(id);
      requireThat(job.status === 'needs_reconciliation' && job.payment_txid, 'reconciliation_required',
        'Only jobs with a recorded payment can retry inference. An unknown payment outcome requires wallet reconciliation.', 409);
      this.db.prepare("UPDATE jobs SET status='paid', error_json=NULL, updated_at=? WHERE id=?").run(this.timestamp(), id);
      this.event(id, 'paid', 'Explicit inference retry; the existing payment transaction is reused.');
    });
  }
  cancel(id) {
    return this.atomic(() => {
      const job = this.get(id);
      requireThat(job.status === 'queued', 'cannot_cancel', 'Only queued, unpaid jobs can be cancelled.', 409);
      this.db.prepare("UPDATE jobs SET status='cancelled', updated_at=? WHERE id=?").run(this.timestamp(), id);
      this.event(id, 'cancelled', 'Cancelled before payment.');
    });
  }
  confirmRefund(id, receipt) {
    // Internal only. A future live implementation must supply a chain-verified
    // receipt, never accept a user/provider assertion as confirmation.
    return this.atomic(() => {
      const job = this.get(id);
      requireThat(job.payment_txid, 'invalid_state', 'Refunds require a recorded payment.', 409);
      requireThat(typeof receipt.txid === 'string' && /^[a-f0-9]{64}$/.test(receipt.txid), 'invalid_refund', 'Invalid refund transaction.');
      const amount = sats(receipt.amount_sats, 'Refund amount');
      const old = this.db.prepare('SELECT * FROM refunds WHERE txid=?').get(receipt.txid);
      if (old) {
        requireThat(old.job_id === id && old.amount_sats === amount, 'refund_conflict', 'Refund transaction already belongs to another receipt.', 409);
        return;
      }
      requireThat(amount > 0 && job.refunded_sats + amount <= job.paid_sats, 'invalid_refund', 'Refund would exceed the amount paid.');
      this.db.prepare('INSERT INTO refunds VALUES (?, ?, ?, ?)').run(receipt.txid, id, amount, this.timestamp());
      this.db.prepare('UPDATE jobs SET refunded_sats=refunded_sats+?, updated_at=? WHERE id=?').run(amount, this.timestamp(), id);
      this.event(id, job.status, 'Refund recorded from the payment backend; gross daily spending capacity is not replenished.');
    });
  }
  recover() {
    return this.atomic(() => {
      for (const row of this.db.prepare("SELECT id, status FROM jobs WHERE status IN ('quoted','payment_pending','running')").all()) {
        if (row.status === 'quoted') {
          this.db.prepare("UPDATE jobs SET status='queued', invoice_json=NULL, reserved_sats=0, updated_at=? WHERE id=?").run(this.timestamp(), row.id);
          this.event(row.id, 'queued', 'Restart before payment intent; discard the old quote and obtain a fresh one.');
        } else if (row.status === 'payment_pending') {
          this.db.prepare("UPDATE jobs SET status='needs_reconciliation', error_json=?, updated_at=? WHERE id=?")
            .run(JSON.stringify({ code: 'payment_outcome_unknown', message: 'Restart during payment. Reconcile the wallet before proceeding.' }), this.timestamp(), row.id);
          this.event(row.id, 'needs_reconciliation', 'Unknown payment outcome after restart; reservation retained.');
        } else {
          this.db.prepare("UPDATE jobs SET status='paid', updated_at=? WHERE id=?").run(this.timestamp(), row.id);
          this.event(row.id, 'paid', 'Restart during inference; resume using the original payment transaction.');
        }
      }
    });
  }
  runnable() { return this.db.prepare("SELECT id FROM jobs WHERE status IN ('queued','paid') ORDER BY created_at, rowid").all().map(r => r.id); }
  list(limit = 50) { return this.db.prepare('SELECT id FROM jobs ORDER BY created_at DESC, rowid DESC LIMIT ?').all(limit).map(r => this.view(r.id)); }
  view(id) {
    const j = this.get(id);
    return {
      id: j.id, status: j.status, model: j.request.model, created_at: j.created_at, updated_at: j.updated_at,
      payment_txid: j.payment_txid, reserved_sats: j.reserved_sats, paid_sats: j.paid_sats,
      network_fee_sats: j.fee_sats, refunded_sats: j.refunded_sats,
      net_cost_sats: j.paid_sats + j.fee_sats - j.refunded_sats,
      attempts: j.attempts, result: j.result, error: j.error,
      events: this.db.prepare('SELECT at, status, detail FROM events WHERE job_id=? ORDER BY seq').all(id),
    };
  }
  budget() {
    const today = this.timestamp().slice(0, 10);
    const row = this.db.prepare(`SELECT COALESCE(SUM(reserved_sats),0) AS reserved_sats,
      COALESCE(SUM(CASE WHEN substr(paid_at,1,10)=? THEN paid_sats+fee_sats ELSE 0 END),0) AS today_paid_sats,
      COALESCE(SUM(paid_sats+fee_sats),0) AS total_paid_sats, COALESCE(SUM(refunded_sats),0) AS total_refunded_sats FROM jobs`).get(today);
    return { ...row, day_utc: today, daily_committed_sats: row.reserved_sats + row.today_paid_sats };
  }
  purgeContent(days = 7) {
    requireThat(Number.isInteger(days) && days >= 1, 'invalid_retention', 'Retention must be at least one day.');
    const cutoff = new Date(this.now().getTime() - days * 86400000).toISOString();
    // Keep hashes, accounting, idempotency tombstones and events. Do not remove
    // unresolved payloads or today's receipts from budget calculations.
    return this.atomic(() => {
      let count = 0;
      for (const row of this.db.prepare("SELECT id FROM jobs WHERE status IN ('completed','failed','cancelled') AND updated_at<?").all(cutoff)) {
        const j = this.get(row.id);
        if (j.request.purged) continue;
        this.db.prepare('UPDATE jobs SET request_json=?, result_json=NULL WHERE id=?')
          .run(JSON.stringify({ model: j.request.model, purged: true }), j.id);
        count++;
      }
      return count;
    });
  }
  close() { this.db.close(); }
}
