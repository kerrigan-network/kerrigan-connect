// Explicit development integration surface. Live spending remains disabled in
// the CLI/Gateway; embedding software must provide its own owner-controlled
// signing session and the restricted transport described in the documentation.
export { CoordinatorClient } from './coordinator.js';
export { LoopbackPaymentBridge, PreparedPaymentRecovery } from './payment-recovery.js';
export { KERRIGAN_SDK_REVISION, MaintainedSdkPaymentPreparer } from './sdk-payment.js';
