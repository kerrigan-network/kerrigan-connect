import { spawnSync } from 'node:child_process';
import { requireThat } from './errors.js';

const SDK_MODELS_SOURCE = 'https://github.com/kerrigan-network/kerrigan-sdk/blob/ae6ca83e0b365a3bb6315cf03954d3fda5dc6a29/webwallet/src/network.js';
const MAX_GPUS = 64;

function exactKeys(value, allowed, field) {
  requireThat(value && typeof value === 'object' && !Array.isArray(value), 'invalid_gpu_inventory', `${field} must be an object.`);
  for (const key of Object.keys(value)) requireThat(allowed.has(key), 'invalid_gpu_inventory', `${field} contains unsupported field ${key.slice(0, 60)}.`);
}

function text(value, field, pattern = /^[\x20-\x7e]+$/, max = 120) {
  requireThat(typeof value === 'string' && value.length > 0 && value.length <= max && pattern.test(value), 'invalid_gpu_inventory', `${field} is invalid.`);
  return value;
}

function optionalVersion(value, field) {
  if (value == null) return null;
  return text(value, field, /^[A-Za-z0-9._+ -]+$/, 64);
}

function positiveMemory(value, field) {
  requireThat(Number.isInteger(value) && value > 0 && value <= 1_000_000, 'invalid_gpu_inventory', `${field} must be an integer from 1 to 1000000 MB.`);
  return value;
}

export function validateGpuInventory(raw) {
  exactKeys(raw, new Set(['format_version', 'collected_at', 'source', 'os', 'arch', 'tooling', 'gpus']), 'inventory');
  requireThat(raw.format_version === 1, 'invalid_gpu_inventory', 'Inventory format_version must be 1.');
  requireThat(typeof raw.collected_at === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(raw.collected_at) && !Number.isNaN(Date.parse(raw.collected_at)), 'invalid_gpu_inventory', 'Inventory collected_at must be an ISO timestamp.');
  requireThat(['supplied', 'local_nvidia_smi'].includes(raw.source), 'invalid_gpu_inventory', 'Inventory source is unsupported.');
  const os = text(raw.os, 'inventory.os', /^[a-z0-9._-]+$/i, 40);
  const arch = text(raw.arch, 'inventory.arch', /^[a-z0-9._-]+$/i, 40);
  exactKeys(raw.tooling, new Set(['nvidia_smi']), 'inventory.tooling');
  requireThat(['present', 'absent', 'error', 'not_checked'].includes(raw.tooling.nvidia_smi), 'invalid_gpu_inventory', 'inventory.tooling.nvidia_smi is invalid.');
  requireThat(Array.isArray(raw.gpus) && raw.gpus.length <= MAX_GPUS, 'invalid_gpu_inventory', `Inventory supports at most ${MAX_GPUS} GPUs.`);
  const indexes = new Set();
  const gpus = raw.gpus.map((gpu, position) => {
    exactKeys(gpu, new Set(['index', 'vendor', 'product_name', 'memory_total_mb', 'driver_version']), `inventory.gpus[${position}]`);
    requireThat(Number.isInteger(gpu.index) && gpu.index >= 0 && gpu.index < MAX_GPUS && !indexes.has(gpu.index), 'invalid_gpu_inventory', 'GPU indexes must be unique integers from 0 to 63.');
    indexes.add(gpu.index);
    requireThat(['nvidia', 'amd', 'intel', 'unknown'].includes(gpu.vendor), 'invalid_gpu_inventory', `inventory.gpus[${position}].vendor is invalid.`);
    return {
      index: gpu.index,
      vendor: gpu.vendor,
      product_name: text(gpu.product_name, `inventory.gpus[${position}].product_name`, /^[A-Za-z0-9][A-Za-z0-9 ._()+/-]*$/, 120),
      memory_total_mb: positiveMemory(gpu.memory_total_mb, `inventory.gpus[${position}].memory_total_mb`),
      driver_version: optionalVersion(gpu.driver_version, `inventory.gpus[${position}].driver_version`),
    };
  });
  return { format_version: 1, collected_at: new Date(raw.collected_at).toISOString(), source: raw.source, os, arch,
    tooling: { nvidia_smi: raw.tooling.nvidia_smi }, gpus };
}

export function parseNvidiaSmi(stdout, { collectedAt = new Date().toISOString(), os = process.platform, arch = process.arch } = {}) {
  requireThat(typeof stdout === 'string' && Buffer.byteLength(stdout) <= 1_000_000, 'invalid_gpu_inventory', 'nvidia-smi output is invalid or too large.');
  const lines = stdout.split(/\r?\n/).filter(line => line.trim());
  requireThat(lines.length > 0 && lines.length <= MAX_GPUS, 'invalid_gpu_inventory', 'nvidia-smi returned no GPU rows or too many rows.');
  const gpus = lines.map((line, position) => {
    const fields = line.split(',').map(value => value.trim());
    requireThat(fields.length === 4 && /^\d+$/.test(fields[0]) && /^\d+$/.test(fields[2]), 'invalid_gpu_inventory', `nvidia-smi row ${position + 1} is malformed.`);
    return { index: Number(fields[0]), vendor: 'nvidia', product_name: fields[1], memory_total_mb: Number(fields[2]), driver_version: fields[3] };
  });
  return validateGpuInventory({ format_version: 1, collected_at: collectedAt, source: 'local_nvidia_smi', os, arch,
    tooling: { nvidia_smi: 'present' }, gpus });
}

export function collectLocalNvidiaInventory({ spawn = spawnSync, collectedAt = new Date().toISOString(), os = process.platform, arch = process.arch } = {}) {
  const args = ['--query-gpu=index,name,memory.total,driver_version', '--format=csv,noheader,nounits'];
  const result = spawn('nvidia-smi', args, { encoding: 'utf8', timeout: 5_000, maxBuffer: 1_000_000, shell: false, windowsHide: true });
  if (result.error?.code === 'ENOENT') return validateGpuInventory({ format_version: 1, collected_at: collectedAt, source: 'local_nvidia_smi', os, arch,
    tooling: { nvidia_smi: 'absent' }, gpus: [] });
  if (result.error || result.status !== 0) return validateGpuInventory({ format_version: 1, collected_at: collectedAt, source: 'local_nvidia_smi', os, arch,
    tooling: { nvidia_smi: 'error' }, gpus: [] });
  return parseNvidiaSmi(result.stdout, { collectedAt, os, arch });
}

export function advertisedModelRequirements(snapshot) {
  requireThat(snapshot && typeof snapshot === 'object' && !Array.isArray(snapshot), 'invalid_model_snapshot', 'Model snapshot must be an object.');
  requireThat(Array.isArray(snapshot.models) && snapshot.models.length <= 1000, 'invalid_model_snapshot', 'Model snapshot requires at most 1000 models.');
  const observedAt = typeof snapshot.observed_at === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(snapshot.observed_at) && !Number.isNaN(Date.parse(snapshot.observed_at)) ? new Date(snapshot.observed_at).toISOString() : null;
  return snapshot.models.map((model, position) => {
    requireThat(model && typeof model === 'object' && typeof model.id === 'string' && /^[A-Za-z0-9_.:/-]{1,180}$/.test(model.id), 'invalid_model_snapshot', `Model ${position + 1} has an invalid id.`);
    const value = model.x_kerrigan?.vram_required_mb ?? model.vram_required_mb ?? null;
    if (value != null) positiveMemory(value, `models[${position}].vram_required_mb`);
    return { model_id: model.id, advertised_vram_required_mb: value, observed_at: observedAt, source: SDK_MODELS_SOURCE };
  });
}

const OPERATIONAL_UNKNOWNS = [
  ['driver', 'A maintained inference-provider driver/version requirement was not available in the public sources reviewed.'],
  ['runtime', 'A maintained CUDA, ROCm or other inference-runtime requirement was not available in the public sources reviewed.'],
  ['service', 'A maintained provider service, port and health-check contract was not available in the public sources reviewed.'],
  ['registration', 'Registration, staking, wallet and payout prerequisites require the maintained upstream provider guide.'],
].map(([id, reason]) => ({ id, status: 'unknown', reason }));

export function assessGpuPreflight(inventoryInput, { modelSnapshot = null, generatedAt = new Date().toISOString() } = {}) {
  const inventory = validateGpuInventory(inventoryInput);
  const requirements = modelSnapshot ? advertisedModelRequirements(modelSnapshot) : [];
  const knownAbsent = inventory.source === 'supplied' && inventory.gpus.length === 0;
  const inventoryStatus = inventory.gpus.length ? 'observed' : knownAbsent ? 'blocked' : 'unknown';
  const modelMemory = requirements.map(requirement => {
    const fits = requirement.advertised_vram_required_mb == null ? [] : inventory.gpus.filter(gpu => gpu.memory_total_mb >= requirement.advertised_vram_required_mb).map(gpu => gpu.index);
    return { ...requirement, status: requirement.advertised_vram_required_mb == null ? 'unknown' : fits.length ? 'meets_advertised_memory' : inventory.gpus.length ? 'blocked' : inventoryStatus,
      matching_gpu_indexes: fits,
      note: requirement.advertised_vram_required_mb == null ? 'No advertised per-model VRAM value was present in the saved model snapshot.' : 'Memory comparison only; it does not establish runtime or provider compatibility.' };
  });
  const everyKnownModelBlocked = modelMemory.length > 0 && modelMemory.every(item => item.status === 'blocked');
  const diagnosticStatus = knownAbsent || everyKnownModelBlocked ? 'blocked' : 'unknown';
  const actions = [];
  if (inventory.tooling.nvidia_smi === 'absent') actions.push('Supply a redacted inventory file, or install the vendor-supported diagnostic tool under the operator’s own change process; this command installs nothing.');
  if (inventory.tooling.nvidia_smi === 'error') actions.push('Run nvidia-smi manually and resolve its local driver/tool error before repeating the diagnostic.');
  if (knownAbsent) actions.push('Add a supported GPU or run the preflight on the intended provider host.');
  if (everyKnownModelBlocked) actions.push('Select a model whose advertised VRAM requirement fits an observed GPU, or use a host with more VRAM.');
  actions.push('Obtain the maintained Kerrigan inference-provider guide before installing runtimes, opening ports, registering, staking or configuring a wallet.');
  return {
    format_version: 1,
    generated_at: new Date(generatedAt).toISOString(),
    diagnostic_status: diagnosticStatus,
    scope: 'Local diagnostic only. It does not register a provider, prove serving readiness, predict earnings or inspect the wider network.',
    inventory,
    checks: { gpu_inventory: { status: inventoryStatus, observed_count: inventory.gpus.length }, model_memory: modelMemory, operational_compatibility: OPERATIONAL_UNKNOWNS },
    actions,
    redaction: { included: ['OS family', 'architecture', 'diagnostic-tool status', 'GPU ordinal', 'vendor', 'product name', 'total memory MB', 'driver version'], excluded: ['hostname', 'public or private IP', 'GPU UUID or serial', 'PCI bus ID', 'wallet data', 'environment variables', 'filesystem paths', 'command stderr'] },
    evidence: {
      model_metadata_contract: SDK_MODELS_SOURCE,
      reviewed_on: '2026-09-25',
      note: 'The public SDK model catalogue defines vram_required_mb. Public mining hardware guidance is not treated as an inference-provider requirement.',
    },
  };
}

export function renderGpuPreflight(report) {
  const rows = report.inventory.gpus.length ? report.inventory.gpus.map(gpu => `| ${gpu.index} | ${gpu.vendor} | ${gpu.product_name} | ${gpu.memory_total_mb} | ${gpu.driver_version ?? 'unknown'} |`).join('\n') : '| — | — | No GPU recorded | — | — |';
  const models = report.checks.model_memory.length ? report.checks.model_memory.map(model => `| ${model.model_id} | ${model.advertised_vram_required_mb ?? 'unknown'} | ${model.status} |`).join('\n') : '| — | unknown | No model snapshot supplied |';
  return `# Kerrigan GPU provider preflight\n\nGenerated: ${report.generated_at}\n\n**Diagnostic status: ${report.diagnostic_status}.** This is not proof of provider readiness or registration.\n\n## Redacted inventory\n\n| Index | Vendor | Product | Total MB | Driver |\n| ---: | --- | --- | ---: | --- |\n${rows}\n\n## Advertised model-memory checks\n\n| Model | Required MB | Result |\n| --- | ---: | --- |\n${models}\n\n## Operational requirements\n\n${report.checks.operational_compatibility.map(item => `- **${item.id}: unknown.** ${item.reason}`).join('\n')}\n\n## Actions\n\n${report.actions.map(action => `- ${action}`).join('\n')}\n\n## Export boundary\n\nIncluded: ${report.redaction.included.join(', ')}.\n\nExcluded: ${report.redaction.excluded.join(', ')}.\n`;
}
