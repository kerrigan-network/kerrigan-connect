import { resolve } from 'node:path';
import { requireThat } from './errors.js';

export function positiveInteger(value, name, max = 1_000_000_000_000) {
  const text = String(value);
  requireThat(/^\d+$/.test(text), 'invalid_config', `${name} must be a positive integer.`);
  const n = Number(text);
  requireThat(Number.isSafeInteger(n) && n > 0 && n <= max, 'invalid_config', `${name} is outside the supported range.`);
  return n;
}

export function httpsOrigin(value, name) {
  let url;
  try { url = new URL(value); } catch { requireThat(false, 'invalid_config', `${name} must be an HTTPS origin.`); }
  requireThat(url.protocol === 'https:' && !url.username && !url.password && url.pathname === '/' && !url.search && !url.hash,
    'invalid_config', `${name} must be an HTTPS origin without a path or credentials.`);
  return url.origin;
}

export function readConfig(env = process.env) {
  const mode = env.KCONNECT_MODE || 'demo';
  requireThat(['demo', 'read-only'].includes(mode), 'invalid_config', 'Only demo and read-only modes are available. Live spending is not implemented.');
  const host = env.KCONNECT_HOST || '127.0.0.1';
  // This milestone is single-user and local. A reverse proxy and access review
  // are required before changing the network exposure policy.
  requireThat(['127.0.0.1', '::1'].includes(host), 'invalid_config', 'The gateway currently binds to loopback only.');
  const apiKey = env.KCONNECT_API_KEY || '';
  requireThat(apiKey.length >= 24 && apiKey.length <= 256 && /^[\x21-\x7e]+$/.test(apiKey)
    && !apiKey.startsWith('replace-'), 'invalid_config', 'Set KCONNECT_API_KEY to 24–256 random printable characters.');
  return {
    mode, host, apiKey,
    port: positiveInteger(env.KCONNECT_PORT || 8787, 'KCONNECT_PORT', 65535),
    dataDir: resolve(env.KCONNECT_DATA_DIR || './data'),
    dailyBudgetSats: positiveInteger(env.KCONNECT_DAILY_BUDGET_SATS || 10_000_000, 'Daily budget'),
    jobBudgetSats: positiveInteger(env.KCONNECT_JOB_BUDGET_SATS || 1_000_000, 'Job budget'),
    maxNetworkFeeSats: positiveInteger(env.KCONNECT_MAX_NETWORK_FEE_SATS || 10_000, 'Network fee ceiling'),
    coordinatorUrl: httpsOrigin(env.KCONNECT_COORDINATOR_URL || 'https://coordinator.jskitty.com', 'Coordinator URL'),
    explorerUrl: httpsOrigin(env.KCONNECT_EXPLORER_URL || 'https://explorer.kerrigan.network', 'Explorer URL'),
  };
}
